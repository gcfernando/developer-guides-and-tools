# OpenAI Codex agent team files

These files define lead, developer, qa-tester and devops roles.
Read the matching HTML guide before copying them to a project.

1. Copy hidden folders too. Merge existing files; do not replace customizations.
2. Edit .agent-team/project.md for your actual commands and folder ownership.
   Review language-specific skill/role examples, build files and dependencies too.
3. Open a terminal at the project root and run: codex -s workspace-write -a on-request
4. Give the lead a normal feature, fix, test or build request.
5. Inspect actual specialist tasks and results.

The bundled configuration explicitly selects GPT-6.1 Sol with medium reasoning for the lead and specialists.
Check account/client availability before starting. Choose an available model
when necessary, and keep the displayed guide and local files consistent.
Recovery limits live only in .agent-team/recovery.md; these are behavioral
instructions, not guaranteed client-enforced runtime retries.

For a new C# practice project, run the companion setup-practice script instead.

.codex/config.toml contains model/reasoning, workspace-write/on-request and
[agents] enabled=true with three concurrent specialists (excluding the lead).
Each .codex/agents/*.toml contains an explicit model and reasoning effort.
The team-plan skill includes agents/openai.yaml for display/invocation policy.

Verification status (27 November 2026): local content and example checks are
separate from authenticated operation. A signed-in team run, actual
specialist models, concurrency and live recovery remain NOT RUN here.
Follow the guide's real-run checklist and keep actual task evidence.
