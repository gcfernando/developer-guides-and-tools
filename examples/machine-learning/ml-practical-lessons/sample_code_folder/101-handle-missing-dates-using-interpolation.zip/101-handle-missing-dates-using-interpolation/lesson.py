"""
Handle missing dates using interpolation

Estimate a missing time-series reading from the readings on either side.

Run: python lesson.py
Try changing day from 2025-02-01 to 2025-02-04 in sample.csv. Compare the new output.
"""

from pathlib import Path
import pandas as pd

input_path = Path(__file__).resolve().with_name("sample.csv")


# 1. Read the CSV and check its inputs, including day, orders.
data = pd.read_csv(input_path, parse_dates=["day"])
daily = data.set_index("day")["orders"].asfreq("D")
# 2. Print the result next to the input values so you can compare them.
print(
    pd.DataFrame({"observed": daily, "interpolated": daily.interpolate(method="time")})
)
