# Handle missing dates using interpolation

**Practice**

Estimate a missing time-series reading from the readings on either side.

## ▶️ Run it

From the extracted lesson folder, run the two commands below. You only need to install its packages once.

```bash
python -m pip install -r requirements.txt
python lesson.py
```

## ✅ Expected result

Look for `observed  interpolated` in the output excerpt below. Match it to the supplied CSV before changing any values.

```text
observed  interpolated
day
2025-02-01      10.0          10.0
```

[See the full example output](expected-output.txt).

If the result differs on your first run, restore the original CSVs, run from the extracted lesson folder, and read the first error message if Python stops.

## 🧪 Try one change

Try changing day from 2025-02-01 to 2025-02-04 in sample.csv. Compare the new output.

[Open the Python script](lesson.py) · [Open sample.csv](sample.csv)

## What the code does

1. Read the CSV and check its inputs, including day, orders.
2. Print the result next to the input values so you can compare them.

## 📋 Sample data

| day | orders |
| --- | --- |
| 2025-02-01 | 10 |
| 2025-02-03 | 16 |
| 2025-02-04 | 19 |
