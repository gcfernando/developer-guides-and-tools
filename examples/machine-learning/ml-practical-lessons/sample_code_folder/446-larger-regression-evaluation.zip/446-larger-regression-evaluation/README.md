# Evaluate delivery errors by route, weight and zone

**Core**

Compare a delivery model to a median baseline on a larger batch of future deliveries.

## ▶️ Run it

Extract this ZIP and open a terminal in the lesson folder.

```bash
python -m pip install -r requirements.txt
python lesson.py
```

## ✅ Expected result

On 180 later deliveries, model MAE is 2.89 minutes and the median baseline is 23.70. The Missing weight group has 12 orders and 6.39 minutes MAE.

```text
Test deliveries: 180. First test day: 2025-02-24.
  Method  MAE (min)  RMSE (min)  R squared
baseline      23.70       28.43      -0.00
   model       2.89        3.73       0.98

```

[Full run output](expected-output.txt) · [Python script](lesson.py) · [Sample CSV](sample.csv) · [Inputs to change](new_inputs.csv)

## 🧪 Try a change

Change short_route_max_km from 25 to 20. The route-group counts should change while the overall model MAE stays the same.
