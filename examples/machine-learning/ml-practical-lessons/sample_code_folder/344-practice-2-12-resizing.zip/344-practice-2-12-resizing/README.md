# Resizing

**Practice**

Resize one clothing drawing and check its dimensions and pixel count.

## ▶️ Run it

Extract this ZIP and open a terminal in the lesson folder.

```bash
python -m pip install -r requirements.txt
python lesson.py
```

## ✅ Expected result

Find the original 5 by 5 picture and the resized 8 by 8 picture. The count goes from 25 to 64 pixels.

```text
Original picture: 5 columns by 5 rows.
Resized picture: 8 columns by 8 rows.
Pixel count: 25 before, 64 after.
```

[Full run output](expected-output.txt) · [Python script](lesson.py) · [Sample CSV](sample.csv) · [Inputs to change](new_inputs.csv)

## 🧪 Try a change

Change side from 8 to 10. The resized picture should be 10 by 10 and have 100 pixels.
