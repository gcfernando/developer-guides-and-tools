# Bayesian Optimization

**Practice** · Shared code with lesson 190

Use scores from earlier trials to choose another setting to try.

## ▶️ Run it

From the extracted lesson folder, run the two commands below. You only need to install its packages once.

```bash
python -m pip install -r requirements.txt
python lesson.py
```

## ✅ Expected result

Look for `GridSearchCV 1 MAE 0.81` in the output excerpt below. Match it to the supplied CSV before changing any values.

```text
GridSearchCV 1 MAE 0.81
RandomizedSearchCV 0.062 MAE 0.837
Bayesian 1.585 MAE 0.802
```

[See the full example output](expected-output.txt).

If the result differs on your first run, restore the original CSVs, run from the extracted lesson folder, and read the first error message if Python stops.

## 🧪 Try one change

Edit new_inputs.csv and rerun the script. Change an input and its known answer consistently in sample.csv. Rerun the comparison and check what changes.

[Open the Python script](lesson.py) · [Open sample.csv](sample.csv) · [Open new_inputs.csv](new_inputs.csv)

## What the code does

1. Read the CSV and check its inputs, including input_1, input_2, input_3.
2. Give each method the same practice data so you can compare the results.
3. Apply the fitted model to the new CSV rows and print a result for each row.

## 📋 Sample data

| input_1 | input_2 | input_3 | answer |
| --- | --- | --- | --- |
| 0.5003818664186679 | 1.588855203878302 | 1.102742760980774 | 1.7477369467801798 |
| -1.0991712400376326 | -0.7993348603550983 | 1.4942137815850476 | -10.313014425497869 |
| -1.978938781737701 | 1.2849136735310651 | 1.188277715008185 | -8.160788361954944 |
| -0.1282601886251169 | -0.7878702927227459 | -0.8862975515969067 | -1.2744124194033088 |
| -0.9805216493835016 | -0.2196947764694137 | 0.018193035831813198 | -3.421428943002779 |
| 0.21398940829796986 | 1.9820011337375707 | 1.1706476768550123 | -0.34883361965989845 |
| 0.48871691776465065 | 1.9558405907275396 | -1.1387652070576042 | 6.9672297602438125 |
| -1.3591518645686218 | 0.4501584170921231 | -1.8242319681544665 | -1.2070338972886316 |

Showing the first 8 of 42 rows. The CSV has the full sample.

## 📩 Supplied new inputs

| input_1 | input_2 | input_3 |
| --- | --- | --- |
| 1 | 0 | -1 |
| 0 | 0 | 0 |
| -1 | 1 | 2 |

These scores compare settings on validation folds. Use an independent test set for the final score after you choose a model.
