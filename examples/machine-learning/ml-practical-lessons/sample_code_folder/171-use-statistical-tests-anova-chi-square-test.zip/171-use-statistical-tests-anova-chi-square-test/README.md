# Use statistical tests (ANOVA, Chi-square test)

**Lesson 171 · Practice**

## Your goal

Compare ANOVA and chi-square to see which input each method chooses.

## Before you start

Distinguish a measurement, an ID and a known answer.

Use the [learning path](../../LEARNING-PATH.md) to find the earlier skill, the [word list](../../GLOSSARY.md) for a term, and [Setup](../../SETUP.md) for computer steps. Extra-topic prerequisites and bridges are in [Extra topics](../../ELECTIVES.md). In an extracted ZIP, open README.html for the browser links and keep this folder directly inside the complete course folder.

## The idea in simple words

Feature selection chooses a subset of inputs using a stated rule.

**Why and when.** Use it to remove unusable/redundant fields or compare a smaller representation, while learning selection inside training.

**A worked example to follow.** The script excludes id and duplicate_minutes. ANOVA compares class-related variation in candidate inputs. The chi-square example uses the nonnegative keyword indicator; mere positivity does not make every measurement suitable for that test.

**Input and output.** The supplied sample fields are `id`, `minutes`, `duplicate_minutes`, `keyword`, `review`. In that field order, one original row is:

```text
0 | 2 | 2 | 0 | 0
```

`(missing)` means a blank, not zero. The result table below belongs to the original supplied files.

**Follow the Python.** Open the complete [lesson.py](lesson.py) beside these instructions. Keep inputs apart from measured answers. Follow this script’s split and fit, then trace the saved preparation into the held-back result and any new request. A request must not supply its own training answer. The [requirements file](requirements.txt) lists its packages. The next section gives exact run commands; use the same course Python to install and run.

## Guess first

An ID column changes when records are sorted. Should its statistical association automatically make it a good input? Write a reason before running or opening the answer.

## Run one step at a time

1. Extract this ZIP. Open folders until you see `lesson.py`.
2. Open a terminal in that folder. Activate the course environment as shown in Setup. Every `python` below means that environment's Python.
3. The main path uses the common course packages. If this lesson needs more, use the same Python to install `requirements.txt` with the course constraint file. See Setup step 8. Do not install optional media packages just to read a lesson.
4. Run these lines one at a time. Wait for each to finish.

```bash
python lesson.py
```

## Check the result

Read the column names and units before the numbers. The original files produced this example. Your deliberate data edits may change it.

```text
ANOVA selected: ['minutes']
Held-out labels: [0, 1]
Chi-square selected: ['keyword']
Held-out labels: [0, 1]
```

[See the complete expected output](expected-output.txt). Explain one row aloud. A matching number is a check of the calculation, not proof of real-world quality.

## Change one thing

In sample.csv, change one keyword indicator from 0 to 1. Keep the recorded review answer. Compare which field is selected. Changing id alone should not affect the model.

Open the named CSV in a plain text editor. Keep its column names and commas. Save the same file name before running again. If you invent a request by changing its inputs, clear its old measured answer. Only score it after you have a real outcome for that new case.

## If you get stuck

If a file is missing, list the files with `dir` or `ls` and enter the folder holding the script. If a column or value is wrong, compare it with a fresh extracted CSV. Use a new folder to start over; keep your edited copy if useful. Use Setup for package or terminal errors.

## Explain the result

**Common mistakes and limits.** A high score is not causality. Selecting from the full dataset before cross-validation leaks check information. Respect assumptions and check whether selection improves actual validation behavior.

<details markdown="1">
<summary>Check your choice and reason</summary>

No. Investigate how it was assigned and whether its apparent relationship will exist at prediction time. An accidental identifier association can fail on later records.

</details>

After the guided file change above, close the notes and explain the same decision for a different supplied row. State one condition that makes this method unsuitable. If you cannot explain the reason, repeat the small worked example before adding more code.

## 📋 Sample data

| id | minutes | duplicate_minutes | keyword | review |
| --- | --- | --- | --- | --- |
| 0 | 2 | 2 | 0 | 0 |
| 1 | 18 | 18 | 1 | 1 |
| 2 | 3 | 3 | 0 | 0 |
| 3 | 20 | 20 | 1 | 1 |
| 4 | 4 | 4 | 1 | 0 |
| 5 | 23 | 23 | 0 | 1 |
| 6 | 5 | 5 | 0 | 0 |
| 7 | 24 | 24 | 1 | 1 |

<!-- teaching-note:start -->
<!-- teaching-profile:feature_selection -->
<!-- teaching-note:end -->
