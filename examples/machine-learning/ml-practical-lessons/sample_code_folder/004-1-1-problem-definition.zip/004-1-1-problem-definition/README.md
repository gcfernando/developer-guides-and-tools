# 1.1 Problem Definition

**Practice** · Shared code with lesson 006

Decide what question the model should answer and how you will judge its answers.

## ▶️ Run it

From the extracted lesson folder, run the two commands below. You only need to install its packages once.

```bash
python -m pip install -r requirements.txt
python lesson.py
```

## ✅ Expected result

Look for `Route support messages classification` in the output excerpt below. Match it to the supplied CSV before changing any values.

```text
Route support messages classification
Group shoppers     clustering
First decision: Estimate delivery time
```

[See the full example output](expected-output.txt).

If the result differs on your first run, restore the original CSVs, run from the extracted lesson folder, and read the first error message if Python stops.

## 🧪 Try one change

Add one task to sample.csv with a decision, objective, metric, domain check and constraint. Look for it in the printed table.

[Open the Python script](lesson.py) · [Open sample.csv](sample.csv)

## What the code does

1. Read the project brief. Each row lists one example project.
2. Print the result next to the input values so you can compare them.

## 📋 Sample data

| use_case | objective | metric | domain_check | constraint |
| --- | --- | --- | --- | --- |
| Estimate delivery time | regression | RMSE | Distance is in km | One laptop |
| Route support messages | classification | F1 | Negation changes meaning | Review missed items |
| Group shoppers | clustering | Silhouette | Income and scores use different units | Groups must be interpretable |

## 📊 Read the visual

![Ask a question. How long will the delivery take? → List known inputs. Distance in km. Parcel weight in kg. → Check the answer. Compare predicted minutes with measured minutes.](problem-definition-steps.png)

**👀 Read the visual.** Decide what a useful result looks like before picking an algorithm.

**👉 What to do.** If the app predicts **minutes**, start with an error measured in minutes, such as MAE.
