# 1.2 Data Collection

**Practice** · Shared code family (see lesson 011 for the same script)

Read orders from a CSV, a small database, a local API, and a sample web page.

## ▶️ Run it

From the extracted lesson folder, run the two commands below. You only need to install its packages once.

```bash
python -m pip install -r requirements.txt
python lesson.py
```

## ✅ Expected result

Look for `Rows from the CSV and database: 3 3` in the output excerpt below. Match it to the supplied CSV before changing any values.

```text
Rows from the CSV and database: 3 3
Orders returned by the local API
order_id  zone
```

[See the full example output](expected-output.txt).

If the result differs on your first run, restore the original CSVs, run from the extracted lesson folder, and read the first error message if Python stops.

## 🧪 Try one change

Add order_id 4 with zone west in sample.csv. Look for it in the database, API or page output.

[Open the Python script](lesson.py) · [Open sample.csv](sample.csv)

## What the code does

1. Read the order IDs and the zone for each order.
2. Send a practice request and read the response code and body.

## 📋 Sample data

| order_id | zone |
| --- | --- |
| 1 | north |
| 2 | south |
| 3 | west |

## 📊 Read the visual

![Bring rows in. Read the order IDs and delivery zones. → Keep the source. Record the file name, origin and column types. → Check and share. Reopen the export. Share the fields your task needs.](data-collection-steps.png)

**👀 Read the visual.** The same order rows can come from a CSV, a database, or an API.

**👉 What to do.** If a column disappears after export, check what was collected and which columns were selected.
