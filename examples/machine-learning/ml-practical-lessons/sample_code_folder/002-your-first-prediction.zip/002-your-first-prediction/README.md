# Your first prediction

**Core** · Shared code with lesson 001

Predict how long a 4 km delivery will take, then check the model against two trips with known times.

## ▶️ Run it

From the extracted lesson folder, run the two commands below. You only need to install its packages once.

```bash
python -m pip install -r requirements.txt
python lesson.py
```

## ✅ Expected result

See **18.0 minutes** next to **4 km** under **New delivery estimates**.

```text
New delivery estimates
distance_km  Predicted time (min)
4                  18.0
```

[See the full example output](expected-output.txt).

If the result differs on your first run, restore the original CSVs, run from the extracted lesson folder, and read the first error message if Python stops.

## 🧪 Try one change

In new_inputs.csv change 4 to 8. After rerunning, the first estimate should be 26.0 minutes.

[Open the Python script](lesson.py) · [Open sample.csv](sample.csv) · [Open new_inputs.csv](new_inputs.csv)

## What the code does

1. Read the CSV and check its inputs, including distance_km, minutes.
2. Print the result next to the input values so you can compare them.
3. Set aside the check rows before the model learns.
4. Teach the model from the training inputs and delivery time in minutes.
5. Compare predictions with the measured answers in the check rows.
6. Apply the fitted model to the new CSV rows and print a result for each row.

## 📋 Sample data

| distance_km | minutes |
| --- | --- |
| 1 | 12 |
| 2 | 14 |
| 3 | 16 |
| 5 | 20 |
| 6 | 22 |

## 📩 Supplied new inputs

| distance_km |
| --- |
| 4 |
| 7 |
| 9 |
