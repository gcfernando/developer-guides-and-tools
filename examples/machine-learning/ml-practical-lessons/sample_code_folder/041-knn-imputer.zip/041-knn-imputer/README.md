# KNN Imputer

**Practice**

Use two similar training deliveries to estimate a parcel’s missing weight.

## ▶️ Run it

From the extracted lesson folder, run the two commands below. You only need to install its packages once.

```bash
python -m pip install -r requirements.txt
python lesson.py
```

## ✅ Expected result

Use the first new delivery to check KNN. Compare its filled weight and predicted minutes with the values shown below.

```text
New row              Method  Filled kg  Prediction in minutes  Actual minutes
1 KNN (two neighbors)        3.0                  41.00            33.0
2 KNN (two neighbors)        2.0                  31.00            29.0
```

[See the full example output](expected-output.txt).

If the result differs on your first run, restore the original CSVs, run from the extracted lesson folder, and read the first error message if Python stops.

## 🧪 Try one change

Try changing distance_km from 10 to 14 in new_inputs.csv. Compare the new output.

[Open the Python script](lesson.py) · [Open sample.csv](sample.csv) · [Open new_inputs.csv](new_inputs.csv)

## What the code does

1. Read the delivery table. Distance is in km, and weight is in kg.
2. Set aside the check rows before the model learns.
3. Read the new CSV rows, then apply the rules from the sample.
4. Learn the conversion on the training inputs before applying it to a new row.
5. Teach the model from the training inputs and delivery time in minutes.

## 📋 Sample data

| distance_km | weight_kg | zone | delivery_minutes |
| --- | --- | --- | --- |
| 2 | 1 | north | 19 |
| 4 | — | north | 30 |
| 6 | 2 | — | 29 |
| 8 | 4 | south | 40 |
| 10 | 1 | ? | 33 |
| 12 | 3 | south | 44 |

## 📩 Supplied new inputs

| distance_km | weight_kg | actual_minutes |
| --- | --- | --- |
| 10 | — | 33 |
| 6 | 2 | 29 |
| 14 | — | — |
