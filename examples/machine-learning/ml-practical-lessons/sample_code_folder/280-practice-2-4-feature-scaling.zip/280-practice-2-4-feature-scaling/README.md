# Feature scaling

**Practice**

Put the numerical inputs on a common scale before using the invented flower measurements in a model.

## ▶️ Run it

Extract this ZIP and open a terminal in the lesson folder.

```bash
python -m pip install -r requirements.txt
python lesson.py
```

## ✅ Expected result

Find First scaled flower. Read the four scaled measurements in the same order as the input columns.

```text
First scaled flower: [-1.28, -0.81, -1.27, -0.83]
```

[Full run output](expected-output.txt) · [Python script](lesson.py) · [Sample CSV](sample.csv) · [Inputs to change](new_inputs.csv)

## 🧪 Try a change

Change an input in new_inputs.csv. Compare the predictions with the held-out check above.
