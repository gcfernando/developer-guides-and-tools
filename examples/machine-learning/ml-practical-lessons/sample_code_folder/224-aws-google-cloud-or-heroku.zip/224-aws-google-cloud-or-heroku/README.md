# AWS, Google Cloud, or Heroku

**Reference** · **Local request check + manual cloud walkthrough**

Practice a local request check, then use the deployment notes for your platform.

## ▶️ Run it

From the extracted lesson folder, run the two commands below. You only need to install its packages once.

```bash
python -m pip install -r requirements.txt
python lesson.py
```

## ✅ Expected result

Read expected_status for one usable input and one rejected input. The example returns 200 for valid fields and 422 for invalid fields.

```text
distance_km  weight_kg  valid  expected_status
5          2   True              200
15          6   True              200
```

[See the full example output](expected-output.txt).

If the result differs on your first run, restore the original CSVs, run from the extracted lesson folder, and read the first error message if Python stops.

## 🧪 Try one change

Try changing distance_km from 5 to -2 in sample.csv. Compare the new output.

[Open the Python script](lesson.py) · [Open sample.csv](sample.csv)

## What the code does

1. Read the delivery table. Distance is in km, and weight is in kg.
2. Print the result next to the input values so you can compare them.

## 📋 Sample data

| distance_km | weight_kg |
| --- | --- |
| 5 | 2 |
| 15 | 6 |
| -2 | 4 |
| 5 | 0 |


See [External services](EXTERNAL-SERVICES.md) for the platform steps.
