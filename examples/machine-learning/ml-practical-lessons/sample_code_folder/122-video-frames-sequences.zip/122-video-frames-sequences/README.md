# Video (Frames, Sequences)

**Practice** · Shared code with lesson 123, lesson 124

Make a short video from frames and classify which way an object moves.

## ▶️ Run it

From the extracted lesson folder, run the two commands below. You only need to install its packages once.

```bash
python -m pip install -r requirements.txt
python lesson.py
```

## ✅ Expected result

Look for `Clips × frames × channels × height × width: (8, 4, 1, 6, 6)` in the output excerpt below. Match it to the supplied CSV before changing any values.

```text
Clips × frames × channels × height × width: (8, 4, 1, 6, 6)
Decoded MP4 direction: [1]
Directions for all new clips: [1, 0]
```

[See the full example output](expected-output.txt).

If the result differs on your first run, restore the original CSVs, run from the extracted lesson folder, and read the first error message if Python stops.

## 🧪 Try one change

Try changing direction from 1 to 0 in new_inputs.csv. Compare the new output.

[Open the Python script](lesson.py) · [Open sample.csv](sample.csv) · [Open new_inputs.csv](new_inputs.csv)

## What the code does

1. Build a short sequence of frames showing one direction of travel.
2. Read the CSV and check its inputs, including direction, row.
3. Apply the fitted model to the new CSV rows and print a result for each row.

## 📋 Sample data

| direction | row |
| --- | --- |
| 0 | 1 |
| 0 | 2 |
| 0 | 3 |
| 0 | 4 |
| 1 | 1 |
| 1 | 2 |
| 1 | 3 |
| 1 | 4 |

## 📩 Supplied new inputs

| direction | row |
| --- | --- |
| 1 | 0 |
| 0 | 5 |

## 📊 Read the visual

![Extract frames. Read the video as a sequence of pictures. → Measure each frame. Use the same image model for every frame. → Read the sequence. Use the order of the frames to predict left or right.](video-feature-steps.png)

**👀 Read the visual.** Keep the pictures in time order so movement stays visible.

**👉 What to do.** Check frame order when direction matters. A picture shows position and the sequence shows movement.
