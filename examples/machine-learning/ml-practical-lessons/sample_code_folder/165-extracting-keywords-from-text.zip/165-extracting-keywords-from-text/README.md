# Extracting keywords from text

**Practice** · Shared code with lesson 162, lesson 163, lesson 164

Mark whether a support message contains the word urgent.

## ▶️ Run it

From the extracted lesson folder, run the two commands below. You only need to install its packages once.

```bash
python -m pip install -r requirements.txt
python lesson.py
```

## ✅ Expected result

Look for `age  urgent` in the output excerpt below. Match it to the supplied CSV before changing any values.

```text
age  urgent
34       0
24       0
```

[See the full example output](expected-output.txt).

If the result differs on your first run, restore the original CSVs, run from the extracted lesson folder, and read the first error message if Python stops.

## 🧪 Try one change

Edit the input values in new_inputs.csv and compare the displayed predictions.

[Open the Python script](lesson.py) · [Open sample.csv](sample.csv) · [Open new_inputs.csv](new_inputs.csv)

## What the code does

1. Read the CSV and check its inputs, including birth, message, review.
2. Turn a date and a message into numerical inputs.
3. Teach the model from the training inputs and whether the message needs review.
4. Apply the fitted model to the new CSV rows and print a result for each row.

## 📋 Sample data

| birth | message | review |
| --- | --- | --- |
| 1990-11-16 | please help urgently | 1 |
| 2000-10-03 | regular update | 0 |
| 1983-01-09 | urgent order change | 1 |
| 1992-07-05 | thanks for the update | 0 |
| 1998-03-01 | urgent call requested | 1 |

## 📩 Supplied new inputs

| birth | message |
| --- | --- |
| 1996-05-01 | urgent parcel |
| 1990-07-04 | regular update |
| 2000-01-01 | thanks for writing |
