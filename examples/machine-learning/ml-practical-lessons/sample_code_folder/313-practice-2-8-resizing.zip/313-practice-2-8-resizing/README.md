# Resizing

**Practice** · Shared code family (see lesson 310 for the same script)

Make the hand-drawn digit shapes the same size before using them in a model.

## ▶️ Run it

From the extracted lesson folder, run the two commands below. You only need to install its packages once.

```bash
python -m pip install -r requirements.txt
python lesson.py
```

## ✅ Expected result

Look for `First raw sketch: ['###', '#.#', '#.#', '#.#', '###']` in the output excerpt below. Match it to the supplied CSV before changing any values.

```text
First raw sketch: ['###', '#.#', '#.#', '#.#', '###']
Blank images to inspect: 0
Model-input shape: (10, 64)
```

[See the full example output](expected-output.txt).

If the result differs on your first run, restore the original CSVs, run from the extracted lesson folder, and read the first error message if Python stops.

## 🧪 Try one change

Edit new_inputs.csv. Within a picture, # is an on pixel, a dot is an off pixel, and / starts the next row.

[Open the Python script](lesson.py) · [Open sample.csv](sample.csv) · [Open new_inputs.csv](new_inputs.csv)

## What the code does

1. Read the small drawings and their labels. Each slash separates two rows of pixels.
2. Resize each picture and turn it into the same number of pixel values.
3. Fit the model on the prepared training rows. Keep it for the checks below.
4. Apply the fitted model to the new CSV rows and print a result for each row.

## 📋 Sample data

| split | pixel_rows | label |
| --- | --- | --- |
| train | ###/#.#/#.#/#.#/### | 0 |
| train | .#./##./.#./.#./### | 1 |
| train | ###/..#/###/#../### | 2 |
| train | ###/..#/.##/..#/### | 3 |
| train | #.#/#.#/###/..#/..# | 4 |
| train | ###/#../###/..#/### | 5 |
| train | ###/#../###/#.#/### | 6 |
| train | ###/..#/..#/.#./.#. | 7 |

Showing the first 8 of 12 rows. The CSV has the full sample.

## 📩 Supplied new inputs

| pixel_rows |
| --- |
| ###/#.#/#.#/#.#/##. |
| ###/..#/.##/.#./.#. |
