# Hierarchical Clustering

**Practice**

See which shoppers merge first by reading the clustering tree from bottom to top.

## ▶️ Run it

From the extracted lesson folder, run the two commands below. You only need to install its packages once.

```bash
python -m pip install -r requirements.txt
python lesson.py
```

## ✅ Expected result

Look for `Labels: [1, 1, 1, 2, 2, 2, 0, 0, 0]` in the output excerpt below. Match it to the supplied CSV before changing any values.

```text
Labels: [1, 1, 1, 2, 2, 2, 0, 0, 0]
age  income  spending
group
```

[See the full example output](expected-output.txt).

If the result differs on your first run, restore the original CSVs, run from the extracted lesson folder, and read the first error message if Python stops.

## 🧪 Try one change

Add a shopper with age 32, income 40 and spending 57. Regenerate the tree and see which branch joins first.

[Open the Python script](lesson.py) · [Open sample.csv](sample.csv)

## What the code does

1. Read the CSV and check its inputs, including age, income, spending.
2. Fit the model on the prepared training rows. Keep it for the checks below.
3. Plot the values so you can see how they compare.

## 📋 Sample data

| age | income | spending |
| --- | --- | --- |
| 21 | 25 | 71 |
| 23 | 28 | 73 |
| 26 | 31 | 68 |
| 42 | 55 | 41 |
| 43 | 59 | 45 |
| 46 | 62 | 43 |
| 59 | 89 | 77 |
| 62 | 93 | 80 |

Showing the first 8 of 9 rows. The CSV has the full sample.

## Graphs

![Tree showing how similar customers join clusters](hierarchical-clustering.png)

When you edit the CSV, this lesson recomputes the result for the whole table. It does not project a separate unseen row with an existing fitted estimator.
