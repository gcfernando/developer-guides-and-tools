# Z-score Method

**Practice**

Flag a parcel that is more than three standard deviations from the average weight.

## ▶️ Run it

From the extracted lesson folder, run the two commands below. You only need to install its packages once.

```bash
python -m pip install -r requirements.txt
python lesson.py
```

## ✅ Expected result

Look for `weight_kg  Z-score  IQR` in the output excerpt below. Match it to the supplied CSV before changing any values.

```text
weight_kg  Z-score  IQR
80     True True
```

[See the full example output](expected-output.txt).

If the result differs on your first run, restore the original CSVs, run from the extracted lesson folder, and read the first error message if Python stops.

## 🧪 Try one change

Compare 80 kg with 8 kg. Change or add a measured weight in sample.csv, then look for the flag and the boxplot.

[Open the Python script](lesson.py) · [Open sample.csv](sample.csv)

## What the code does

1. Read the CSV and check its inputs, including weight_kg.
2. Find where the middle values sit, then compare the remaining rows with those limits.
3. Plot the values so you can see how they compare.

## 📋 Sample data

| weight_kg |
| --- |
| 2 |
| 3 |
| 3 |
| 4 |
| 4 |
| 4 |
| 5 |
| 5 |

Showing the first 8 of 12 rows. The CSV has the full sample.
