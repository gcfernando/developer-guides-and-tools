# Convert to scientific notation (if values are too large)

**Practice** · Shared code with lesson 129

Display large numbers in compact scientific notation and read the original value alongside them.

## ▶️ Run it

From the extracted lesson folder, run the two commands below. You only need to install its packages once.

```bash
python -m pip install -r requirements.txt
python lesson.py
```

## ✅ Expected result

Look for `First ID: 123456789012345` in the output excerpt below. Match it to the supplied CSV before changing any values.

```text
First ID: 123456789012345
Traffic display: ['1.000e+02', '1.000e+04', '1.000e+06', '1.250e+10']
Numeric log features: [4.62, 9.21, 13.82, 23.25]
```

[See the full example output](expected-output.txt).

If the result differs on your first run, restore the original CSVs, run from the extracted lesson folder, and read the first error message if Python stops.

## 🧪 Try one change

Try changing event_id from 123456789012345 to 123456789012347 in sample.csv. Compare the new output.

[Open the Python script](lesson.py) · [Open sample.csv](sample.csv)

## What the code does

1. Read the CSV and check its inputs, including event_id, visits, server_cost.
2. Print the result next to the input values so you can compare them.
3. Fit the model on the prepared training rows. Keep it for the checks below.

## 📋 Sample data

| event_id | visits | server_cost |
| --- | --- | --- |
| 123456789012345 | 100 | 8 |
| 123456789012346 | 10000 | 15 |
| 123456789012347 | 1000000 | 19 |
| 123456789012348 | 12500000000 | 30 |
