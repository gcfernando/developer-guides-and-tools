# Categorical encoding

**Practice** · Shared code family (see lesson 250 for the same script)

Turn categories in the invented employee records into numbers the model can read.

## ▶️ Run it

From the extracted lesson folder, run the two commands below. You only need to install its packages once.

```bash
python -m pip install -r requirements.txt
python lesson.py
```

## ✅ Expected result

Look for `Missing cells before filling or removing rows: {'experience': 0, 'department': 0, 'salary': 1}` in the output excerpt below. Match it to the supplied CSV before changing any values.

```text
Missing cells before filling or removing rows: {'experience': 0, 'department': 0, 'salary': 1}
Field  Rows to review
experience               0
```

[See the full example output](expected-output.txt).

If the result differs on your first run, restore the original CSVs, run from the extracted lesson folder, and read the first error message if Python stops.

## 🧪 Try one change

Change an input in new_inputs.csv. Compare the predictions with the held-out check above.

[Open the Python script](lesson.py) · [Open sample.csv](sample.csv) · [Open new_inputs.csv](new_inputs.csv)

## What the code does

1. Read the example records from sample.csv. The table uses the dataset fields shown below.
2. Set aside the check rows before the model learns.
3. Find blanks in the rows you are about to use.
4. Find where the middle values sit, then compare the remaining rows with those limits.
5. Teach the model from the training inputs and salary.
6. Apply the fitted model to the new CSV rows and print a result for each row.

## 📋 Sample data

| experience | department | salary |
| --- | --- | --- |
| 1 | Support | 32000 |
| 2 | Support | 34000 |
| 4 | Engineering | 42000 |
| 5 | Sales | 43000 |
| 6 | Sales | — |
| 8 | Engineering | 54000 |
| 12 | Engineering | 68000 |
| 9 | Sales | 55000 |

Showing the first 8 of 9 rows. The CSV has the full sample.

## 📩 Supplied new inputs

| experience | department |
| --- | --- |
| 1 | Support |
| 3 | Support |
| 4 | Engineering |
