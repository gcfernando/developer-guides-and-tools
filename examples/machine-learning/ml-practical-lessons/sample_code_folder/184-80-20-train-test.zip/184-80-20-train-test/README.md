# 80%-20% (Train-Test)

**Practice** · Same split lab. Different check in each README; lesson 184 uses 80/20.

Train with 80% of the rows and check the model with the remaining 20%.

## ▶️ Run it

Extract this ZIP and open a terminal in the lesson folder.

```bash
python -m pip install -r requirements.txt
python lesson.py
```

## ✅ Expected result

Find 80 Training and 20 Test rows. The tree depth is fixed before the test.

```text
Shared IDs or identical input rows across splits: 0
     Set  Rows  Urgent  Urgent (%)
Training    80      16        20.0
    Test    20       4        20.0
Look for 80 training orders and 20 test orders. The tree depth is fixed before testing.
Chosen depth: 2
Test: 4 urgent caught, 0 urgent missed, 1 false alarms, 15 regular correct.
The test contains only 4 urgent orders. A single missed order changes recall a lot.
 distance_km  weight_kg  predicted_urgent
           5          2             False
          39          4             False
          47          3             False
```

[Full run output](expected-output.txt) · [Python script](lesson.py) · [Sample CSV](sample.csv) · [Inputs to change](new_inputs.csv)

## 🧪 Try a change

Copy one training CSV row below itself. The script should stop before splitting. Delete the copy and rerun.
