# Tableau

**Reference** · **Local example + manual walkthrough**

Turn batch counts into a CSV that Tableau can plot.

## ▶️ Run it

From the extracted lesson folder, run the two commands below. You only need to install its packages once.

```bash
python -m pip install -r requirements.txt
python lesson.py
```

## ✅ Expected result

Look for `Batch  Correct  Checked  Accuracy` in the output excerpt below. Match it to the supplied CSV before changing any values.

```text
Batch  Correct  Checked  Accuracy
Morning       18       20       0.9
Midday       14       20       0.7
```

[See the full example output](expected-output.txt).

If the result differs on your first run, restore the original CSVs, run from the extracted lesson folder, and read the first error message if Python stops.

## 🧪 Try one change

Try changing Batch from Morning to Afternoon in sample.csv. Compare the new output.

[Open the Python script](lesson.py) · [Open sample.csv](sample.csv)

## What the code does

1. Read the labeled batches so you can compare the model’s results over time.
2. Print the result next to the input values so you can compare them.

## 📋 Sample data

| Batch | Correct | Checked |
| --- | --- | --- |
| Morning | 18 | 20 |
| Midday | 14 | 20 |
| Afternoon | 16 | 20 |


See [External services](EXTERNAL-SERVICES.md) for the platform steps.
