# Missing values

**Practice** · Shared code family (see lesson 318 for the same script)

Find missing entries in the invented shopper records and see how the example prepares them for a model.

## ▶️ Run it

From the extracted lesson folder, run the two commands below. You only need to install its packages once.

```bash
python -m pip install -r requirements.txt
python lesson.py
```

## ✅ Expected result

Look for `age  annual_income  score` in the output excerpt below. Match it to the supplied CSV before changing any values.

```text
age  annual_income  score
0.05  21.4        25050.0  40.70
0.95  62.4       117400.0  78.95
```

[See the full example output](expected-output.txt).

If the result differs on your first run, restore the original CSVs, run from the extracted lesson folder, and read the first error message if Python stops.

## 🧪 Try one change

Change annual_income or score in new_inputs.csv. Compare the new cluster with scaling turned on and off.

[Open the Python script](lesson.py) · [Open sample.csv](sample.csv) · [Open new_inputs.csv](new_inputs.csv)

## What the code does

1. Read the example records from sample.csv. The table uses the dataset fields shown below.
2. Set aside the check rows before the model learns.
3. Read the new CSV rows, then apply the rules from the sample.
4. Give each method the same practice data so you can compare the results.

## 📋 Sample data

| age | annual_income | score | region |
| --- | --- | --- | --- |
| 21 | 24000 | 68 | north |
| 24 | — | 72 | north |
| 22 | 27000 | 70 | north |
| 42 | 57000 | 40 | south |
| 46 | 60000 | — | south |
| 44 | 56000 | 42 | south |
| 60 | 94000 | 75 | west |
| 58 | 90000 | 77 | west |

Showing the first 8 of 10 rows. The CSV has the full sample.

## 📩 Supplied new inputs

| age | annual_income | score | region |
| --- | --- | --- | --- |
| 21 | 24000.0 | 68.0 | north |
| 61 | 96000.0 | 78.0 | west |
| 22 | 27000.0 | 70.0 | north |
