"""
Simple Linear Regression (one input)

Teach a model one relationship, from delivery distance to time.

Run: python lesson.py
Edit the input values in new_inputs.csv and compare the displayed predictions.
"""

from pathlib import Path
import pandas as pd
from sklearn.linear_model import LinearRegression

input_path = Path(__file__).resolve().with_name("sample.csv")
new_path = Path(__file__).resolve().with_name("new_inputs.csv")


# 1. Read the delivery table. Distance is in km, and weight is in kg.
deliveries = pd.read_csv(input_path)


# 2. Set aside the check rows before the model learns.
train, hold = deliveries.iloc[:4], deliveries.iloc[4:]
# 3. Teach the model from the training inputs and delivery time in minutes.
simple = LinearRegression().fit(train[["distance_km"]], train["delivery_minutes"])
print("Simple predictions:", simple.predict(hold[["distance_km"]]).round(1).tolist())
# 4. Apply the fitted model to the new CSV rows and print a result for each row.
fresh = pd.read_csv(new_path)
print(
    fresh.assign(minutes=simple.predict(fresh[["distance_km"]]).round(2)).to_string(
        index=False
    )
)
