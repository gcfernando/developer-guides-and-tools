# REST API or integrate with mobile/web apps

**Practice**

Turn CSV rows into JSON request bodies a web or mobile app would send.

## ▶️ Run it

From the extracted lesson folder, run the two commands below. You only need to install its packages once.

```bash
python -m pip install -r requirements.txt
python lesson.py
```

## ✅ Expected result

Look for `POST /predict {"distance_km": 5, "weight_kg": 2}` in the output excerpt below. Match it to the supplied CSV before changing any values.

```text
POST /predict {"distance_km": 5, "weight_kg": 2}
POST /predict {"distance_km": 10, "weight_kg": 3}
POST /predict {"distance_km": 14, "weight_kg": 4}
```

[See the full example output](expected-output.txt).

If the result differs on your first run, restore the original CSVs, run from the extracted lesson folder, and read the first error message if Python stops.

## 🧪 Try one change

Try changing distance_km from 5 to 14 in sample.csv. Compare the new output.

[Open the Python script](lesson.py) · [Open sample.csv](sample.csv)

## What the code does

1. Read the delivery table. Distance is in km, and weight is in kg.

## 📋 Sample data

| distance_km | weight_kg |
| --- | --- |
| 5 | 2 |
| 10 | 3 |
| 14 | 4 |
