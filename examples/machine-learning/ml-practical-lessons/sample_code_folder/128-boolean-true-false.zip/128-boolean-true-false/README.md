# Boolean (True/False)

**Practice** · Shared code with lesson 092

Change a yes/no switch into a numeric input and fill missing values from training.

## ▶️ Run it

From the extracted lesson folder, run the two commands below. You only need to install its packages once.

```bash
python -m pip install -r requirements.txt
python lesson.py
```

## ✅ Expected result

Look for `signed_up  flag` in the output excerpt below. Match it to the supplied CSV before changing any values.

```text
signed_up  flag
Yes   1.0
No   0.0
```

[See the full example output](expected-output.txt).

If the result differs on your first run, restore the original CSVs, run from the extracted lesson folder, and read the first error message if Python stops.

## 🧪 Try one change

Try Yes, 0 and an unknown value in new_inputs.csv.

[Open the Python script](lesson.py) · [Open sample.csv](sample.csv) · [Open new_inputs.csv](new_inputs.csv)

## What the code does

1. Read the CSV and check its inputs, including signed_up, clicked.
2. Give different spellings of the same value one consistent form.
3. Fit the model on the prepared training rows. Keep it for the checks below.
4. Apply the fitted model to the new CSV rows and print a result for each row.

## 📋 Sample data

| signed_up | clicked |
| --- | --- |
| Yes | 1 |
| No | 0 |
| True | 1 |
| 0 | 0 |
| 1 | 1 |
| unknown | 0 |

## 📩 Supplied new inputs

| signed_up |
| --- |
| unknown |
| Yes |
| 0 |
