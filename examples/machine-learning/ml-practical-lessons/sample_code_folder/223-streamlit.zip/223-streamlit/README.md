# Streamlit

**Practice**

Fill in a Streamlit form and see the delivery estimate change.

## ▶️ Run it

From the extracted lesson folder, run the two commands below. You only need to install its packages once.

```bash
python -m pip install -r requirements.txt
python lesson.py
```

## ✅ Expected result

Look for `Prediction: 27.5 minutes` in the output excerpt below. Match it to the supplied CSV before changing any values.

```text
Prediction: 27.5 minutes
5 2 Prediction: 27.5 minutes
10 4 Prediction: 43.0 minutes
```

[See the full example output](expected-output.txt).

If the result differs on your first run, restore the original CSVs, run from the extracted lesson folder, and read the first error message if Python stops.

## 🧪 Try one change

Enter distances of 5, 10 and 15 km with positive weights. The script fills out the sample form for each row.

[Open the Python script](lesson.py) · [Open sample.csv](sample.csv) · [Open new_inputs.csv](new_inputs.csv)

## What the code does

1. Read the training data for the form and fit a model in the local Streamlit app.
2. Teach the model from the training inputs and delivery time in minutes.
3. Send each new CSV row to the app and read the response.

## 📋 Sample data

| distance_km | weight_kg | delivery_minutes |
| --- | --- | --- |
| 2 | 1 | 19 |
| 4 | 3 | 30 |
| 6 | 2 | 29 |
| 8 | 4 | 40 |

## 📩 Supplied new inputs

| distance_km | weight_kg |
| --- | --- |
| 5 | 2 |
| 10 | 4 |
| 15 | 1 |
