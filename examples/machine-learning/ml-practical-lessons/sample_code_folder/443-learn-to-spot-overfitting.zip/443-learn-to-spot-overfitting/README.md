# Spot overfitting with a validation curve

**Practice**

Vary model complexity, read the training and validation errors, and test the selected setting once.

## ▶️ Run it

Extract this ZIP and open a terminal in the lesson folder.

```bash
python -m pip install -r requirements.txt
python lesson.py
```

## ✅ Expected result

A depth-25 tree has almost zero training error but higher validation error. Depth 3 wins on validation.

```text
Depth  Training MAE  Validation MAE
     1          5.44            4.79
     2          3.68            3.24
     3          2.75            2.99
     5          1.92            3.57
    10          0.14            4.21
    25          0.01            4.30
Selected depth: 3. Test MAE: 3.91 minutes.
Open validation-curve.png. The vertical gap measures how differently the two sets behaved.
```

[Full run output](expected-output.txt) · [Python script](lesson.py) · [Sample CSV](sample.csv) · [Inputs to change](new_inputs.csv)

## 🧪 Try a change

Add a deeper tree to new_inputs.csv. Compare its training and validation errors with the shallower tree before checking the winner.

Open **validation-curve.png** after running the script.
