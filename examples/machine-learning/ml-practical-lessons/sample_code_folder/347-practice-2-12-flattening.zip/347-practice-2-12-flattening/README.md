# Flattening

**Practice**

Flatten one clothing drawing and reconstruct the original pixel grid.

## ▶️ Run it

Extract this ZIP and open a terminal in the lesson folder.

```bash
python -m pip install -r requirements.txt
python lesson.py
```

## ✅ Expected result

Find the original shape (5, 5) and flattened shape (25,). The recovery check should be True.

```text
Original shape: (5, 5). Flattened shape: (25,).
First ten values: [0, 255, 255, 255, 0, 255, 255, 255, 255, 255]
Recovered the original grid: True
```

[Full run output](expected-output.txt) · [Python script](lesson.py) · [Sample CSV](sample.csv) · [Inputs to change](new_inputs.csv)

## 🧪 Try a change

Change order from C to F. The first ten entries should change while the recovered grid remains the same.
