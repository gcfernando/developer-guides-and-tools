# Train the model using the training dataset

**Practice** · Shared code with lesson 187, lesson 188

Give models the same inputs and known answers before comparing their errors.

## ▶️ Run it

From the extracted lesson folder, run the two commands below. You only need to install its packages once.

```bash
python -m pip install -r requirements.txt
python lesson.py
```

## ✅ Expected result

Look for `DummyClassifier 0.687` in the output excerpt below. Match it to the supplied CSV before changing any values.

```text
DummyClassifier 0.687
LogisticRegression 0.908
DecisionTreeClassifier 0.744
```

[See the full example output](expected-output.txt).

If the result differs on your first run, restore the original CSVs, run from the extracted lesson folder, and read the first error message if Python stops.

## 🧪 Try one change

Change an input and its known answer consistently in sample.csv. Rerun the comparison and check what changes.

[Open the Python script](lesson.py) · [Open sample.csv](sample.csv)

## What the code does

1. Read the practice deliveries. Use km for distance and kg for parcel weight.
2. Compare the printed output with the original values.

## 📋 Sample data

| km | kg | answer |
| --- | --- | --- |
| 47 | 3 | 1 |
| 31 | 6 | 1 |
| 34 | 11 | 1 |
| 44 | 10 | 1 |
| 29 | 8 | 1 |
| 39 | 8 | 1 |
| 41 | 1 | 1 |
| 12 | 9 | 0 |

Showing the first 8 of 84 rows. The CSV has the full sample.

These scores compare settings on validation folds. Use an independent test set for the final score after you choose a model.
