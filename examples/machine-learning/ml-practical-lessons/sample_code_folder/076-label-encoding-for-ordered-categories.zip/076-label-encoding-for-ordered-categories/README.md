# Label Encoding (For Ordered Categories)

**Practice**

Turn Low, Medium and High into ordered numbers before predicting a review action.

## ▶️ Run it

Extract this ZIP and open a terminal in the lesson folder.

```bash
python -m pip install -r requirements.txt
python lesson.py
```

## ✅ Expected result

Look for Priority codes: [0.0, 1.0, 2.0] in the output excerpt below. Match it to the supplied CSV before changing any values.

```text
Priority codes: [0.0, 1.0, 2.0]
Held-out label: ['review']
priority action
     Low   wait
```

[Full run output](expected-output.txt) · [Python script](lesson.py) · [Sample CSV](sample.csv) · [Inputs to change](new_inputs.csv)

## 🧪 Try a change

Try changing priority from Low to High in new_inputs.csv. Compare the new output.
