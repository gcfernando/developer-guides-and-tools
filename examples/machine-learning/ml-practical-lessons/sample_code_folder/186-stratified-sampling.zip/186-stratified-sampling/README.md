# Stratified Sampling

**Practice** · Same split lab. Different check in each README; lesson 184 uses 80/20.

Keep similar proportions of urgent orders in each group.

## ▶️ Run it

Extract this ZIP and open a terminal in the lesson folder.

```bash
python -m pip install -r requirements.txt
python lesson.py
```

## ✅ Expected result

Find zero shared IDs or identical input rows. All three sets contain 20% urgent orders.

```text
Shared IDs or identical input rows across splits: 0
       Set  Rows  Urgent  Urgent (%)
  Training    70      14        20.0
Validation    20       4        20.0
      Test    10       2        20.0

Validation scores by tree depth
 Depth  Balanced accuracy
     1              0.500
     2              0.500
     3              0.562
Every set should have 20 percent urgent orders in the supplied CSV.
Chosen depth: 3
```

[Full run output](expected-output.txt) · [Python script](lesson.py) · [Sample CSV](sample.csv) · [Inputs to change](new_inputs.csv)

## 🧪 Try a change

Copy one training CSV row below itself. The script should stop before splitting. Delete the copy and rerun.
