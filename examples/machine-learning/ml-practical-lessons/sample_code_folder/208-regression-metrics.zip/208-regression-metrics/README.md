# Regression Metrics

**Practice** · Shared code with lesson 209, lesson 210

Read prediction errors in minutes and compare them with a simple baseline. Worked calculation using two test trips.

## ▶️ Run it

Extract this ZIP and open a terminal in the lesson folder.

```bash
python -m pip install -r requirements.txt
python lesson.py
```

## ✅ Expected result

The worked example gives 2.0 minutes MAE and RMSE from two test deliveries. Treat this as arithmetic practice.

```text
Worked calculation: two test deliveries. Use lesson 446 for a larger evaluation.
RMSE: 2.0
MAE: 2.0
R²: 0.868
 distance_km  weight_kg  prediction
           5          2        27.5
          13          3        43.5
          20          7        70.0
```

[Full run output](expected-output.txt) · [Python script](lesson.py) · [Sample CSV](sample.csv) · [Inputs to change](new_inputs.csv)

## 🧪 Try a change

Edit the input values in new_inputs.csv and compare the displayed predictions.
