# Datetime (Timestamps, Dates)

**Practice** · Shared code with lesson 093, lesson 094

Read dates and numeric timestamps into a consistent date field.

## ▶️ Run it

From the extracted lesson folder, run the two commands below. You only need to install its packages once.

```bash
python -m pip install -r requirements.txt
python lesson.py
```

## ✅ Expected result

Look for `['2025-02-03', '2025-02-04', 'invalid date', '2023-02-10']` in the output excerpt below. Match it to the supplied CSV before changing any values.

```text
['2025-02-03', '2025-02-04', 'invalid date', '2023-02-10']
```

[See the full example output](expected-output.txt).

If the result differs on your first run, restore the original CSVs, run from the extracted lesson folder, and read the first error message if Python stops.

## 🧪 Try one change

Change raw_date in sample.csv, for example from 02/03/2025 to invalid. Compare the printed rows.

[Open the Python script](lesson.py) · [Open sample.csv](sample.csv)

## What the code does

1. Read the raw date strings, including different formats and an invalid value.
2. Print the result next to the input values so you can compare them.

## 📋 Sample data

| raw_date |
| --- |
| 02/03/2025 |
| 2025-02-04 |
| invalid |
| 1676025600 |
