# Policy Gradient Methods

**Lesson 422 · Practice**

## Your goal

Improve the probability of choosing a move that has paid off.

## Before you start

Read a probability and expected reward.

Use the [learning path](../../LEARNING-PATH.md) to find the earlier skill, the [word list](../../GLOSSARY.md) for a term, and [Setup](../../SETUP.md) for computer steps. Extra-topic prerequisites and bridges are in [Extra topics](../../ELECTIVES.md). In an extracted ZIP, open README.html for the browser links and keep this folder directly inside the complete course folder.

## The idea in simple words

Policy gradient changes action probabilities from rewards. Actor–critic also learns a baseline value.

**Why and when.** Study probabilistic action choice and evaluate the resulting policy separately.

**A worked example to follow.** In the two-button task the actor changes logits. The critic estimates reward, and reward minus that estimate changes the actor update. This is a one-state bandit illustration.

**Input and output.** The supplied sample fields are `button`, `chance_of_reward`. In that field order, one original row is:

```text
left | 0.25
```

`(missing)` means a blank, not zero. The result table below belongs to the original supplied files.

**Follow the Python.** Open the complete [lesson.py](lesson.py) beside these instructions. Find the state/action inputs, follow the transition and reward calculation, then inspect the policy, action values or planned move this particular script produces. The [requirements file](requirements.txt) lists its packages. The next section gives exact run commands; use the same course Python to install and run.

## Guess first

Swap reward chances while keeping button order. What should be checked? Write a reason before running or opening the answer.

## Run one step at a time

1. Extract this ZIP. Open folders until you see `lesson.py`.
2. Open a terminal in that folder. Activate the course environment as shown in Setup. Every `python` below means that environment's Python.
3. The main path uses the common course packages. If this lesson needs more, use the same Python to install `requirements.txt` with the course constraint file. See Setup step 8. Do not install optional media packages just to read a lesson.
4. Run these lines one at a time. Wait for each to finish.

```bash
python lesson.py
```

## Check the result

Read the column names and units before the numbers. The original files produced this example. Your deliberate data edits may change it.

```text
Policy gradient chosen button: 1
```

[See the complete expected output](expected-output.txt). Explain one row aloud. A matching number is a check of the calculation, not proof of real-world quality.

## Change one thing

In sample.csv, swap the two chance_of_reward values. Keep the button names and row order. Rerun and read which button the method prefers.

Open the named CSV in a plain text editor. Keep its column names and commas. Save the same file name before running again. If you invent a request by changing its inputs, clear its old measured answer. Only score it after you have a real outcome for that new case.

## If you get stuck

If a file is missing, list the files with `dir` or `ls` and enter the folder holding the script. If a column or value is wrong, compare it with a fresh extracted CSV. Use a new folder to start over; keep your edited copy if useful. Use Setup for package or terminal errors.

## Explain the result

**Common mistakes and limits.** One lucky reward is not evidence of the better action. Randomness and reward design matter.

<details>
<summary>Check your choice and reason</summary>

Check adaptation toward the more rewarding button across suitable trials, reporting reward and variability rather than one fixed action.

</details>

After the guided file change above, close the notes and explain the same decision for a different supplied row. State one condition that makes this method unsuitable. If you cannot explain the reason, repeat the small worked example before adding more code.

## 📋 Sample data

| button | chance_of_reward |
| --- | --- |
| left | 0.25 |
| right | 0.75 |

<!-- teaching-note:start -->
<!-- teaching-profile:policy_gradient -->
<!-- teaching-note:end -->
