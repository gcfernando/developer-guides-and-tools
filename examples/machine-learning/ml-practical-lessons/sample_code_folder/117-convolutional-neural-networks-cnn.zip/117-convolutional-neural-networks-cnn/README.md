# Convolutional Neural Networks (CNN)

**Practice** · Shared code with lesson 113, lesson 115, lesson 116

Pass a tiny image through a convolution before predicting light or dark.

## ▶️ Run it

From the extracted lesson folder, run the two commands below. You only need to install its packages once.

```bash
python -m pip install -r requirements.txt
python lesson.py
```

## ✅ Expected result

Look for `Image matrix becomes one row: (4, 16)` in the output excerpt below. Match it to the supplied CSV before changing any values.

```text
Image matrix becomes one row: (4, 16)
First normalized pixels: [0.059, 0.059, 0.059, 0.059]
New picture: ['light', 'dark', 'light']
```

[See the full example output](expected-output.txt).

If the result differs on your first run, restore the original CSVs, run from the extracted lesson folder, and read the first error message if Python stops.

## 🧪 Try one change

Edit the red, green, and blue numbers (0–255) in new_inputs.csv to predict dark or light.

[Open the Python script](lesson.py) · [Open sample.csv](sample.csv) · [Open new_inputs.csv](new_inputs.csv)

## What the code does

1. Read the CSV and check its inputs, including red, green, blue.
2. Fit the model on the prepared training rows. Keep it for the checks below.
3. Apply the fitted model to the new CSV rows and print a result for each row.

## 📋 Sample data

| red | green | blue | label |
| --- | --- | --- | --- |
| 15 | 15 | 15 | dark |
| 30 | 30 | 30 | dark |
| 220 | 220 | 220 | light |
| 240 | 240 | 240 | light |

## 📩 Supplied new inputs

| red | green | blue |
| --- | --- | --- |
| 210 | 210 | 210 |
| 8 | 8 | 8 |
| 255 | 230 | 210 |
