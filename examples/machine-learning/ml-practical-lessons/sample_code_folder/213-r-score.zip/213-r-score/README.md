# R² score

**Practice**

Measure how much the model improves on a constant average prediction. Worked calculation using two test trips.

## ▶️ Run it

Extract this ZIP and open a terminal in the lesson folder.

```bash
python -m pip install -r requirements.txt
python lesson.py
```

## ✅ Expected result

R² is about 0.868 on two test deliveries. Use lesson 446 to assess a larger batch.

```text
Worked calculation: two test deliveries. Use lesson 446 for a larger evaluation.
Compares errors with a simple average baseline. 1 is perfect and negative is worse than that baseline.
0.868
 distance_km  weight_kg  prediction
           5          2        27.5
          13          3        43.5
          20          7        70.0
```

[Full run output](expected-output.txt) · [Python script](lesson.py) · [Sample CSV](sample.csv) · [Inputs to change](new_inputs.csv)

## 🧪 Try a change

Edit the input values in new_inputs.csv and compare the displayed predictions.
