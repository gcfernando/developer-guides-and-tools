# CNN and LSTM sequence modeling

**Practice** · Shared code with lesson 122, lesson 123

Use a CNN to read each frame and an LSTM to follow the movement over time.

## ▶️ Run it

From the extracted lesson folder, run the two commands below. You only need to install its packages once.

```bash
python -m pip install -r requirements.txt
python lesson.py
```

## ✅ Expected result

Look for `Clips × frames × channels × height × width: (8, 4, 1, 6, 6)` in the output excerpt below. Match it to the supplied CSV before changing any values.

```text
Clips × frames × channels × height × width: (8, 4, 1, 6, 6)
Decoded MP4 direction: [1]
Directions for all new clips: [1, 0]
```

[See the full example output](expected-output.txt).

If the result differs on your first run, restore the original CSVs, run from the extracted lesson folder, and read the first error message if Python stops.

## 🧪 Try one change

Try changing direction from 1 to 0 in new_inputs.csv. Compare the new output.

[Open the Python script](lesson.py) · [Open sample.csv](sample.csv) · [Open new_inputs.csv](new_inputs.csv)

## What the code does

1. Build a short sequence of frames showing one direction of travel.
2. Read the CSV and check its inputs, including direction, row.
3. Apply the fitted model to the new CSV rows and print a result for each row.

## 📋 Sample data

| direction | row |
| --- | --- |
| 0 | 1 |
| 0 | 2 |
| 0 | 3 |
| 0 | 4 |
| 1 | 1 |
| 1 | 2 |
| 1 | 3 |
| 1 | 4 |

## 📩 Supplied new inputs

| direction | row |
| --- | --- |
| 1 | 0 |
| 0 | 5 |
