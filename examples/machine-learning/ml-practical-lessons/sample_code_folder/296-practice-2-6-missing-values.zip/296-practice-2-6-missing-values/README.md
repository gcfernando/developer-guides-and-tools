# Missing values

**Practice**

Find missing entries in the invented wine measurements and see how the example prepares them for a model.

## ▶️ Run it

Extract this ZIP and open a terminal in the lesson folder.

```bash
python -m pip install -r requirements.txt
python lesson.py
```

## ✅ Expected result

Find Training median used for missing sulphates. The imputer learns this replacement from the training rows.

```text
Training median used for missing sulphates: 0.6
```

[Full run output](expected-output.txt) · [Python script](lesson.py) · [Sample CSV](sample.csv) · [Inputs to change](new_inputs.csv)

## 🧪 Try a change

Change an input in new_inputs.csv. Compare the predictions with the held-out check above.
