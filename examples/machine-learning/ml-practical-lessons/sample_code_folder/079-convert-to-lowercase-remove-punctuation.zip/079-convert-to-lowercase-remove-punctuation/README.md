# Convert to lowercase & remove punctuation

**Practice** · Shared code with lesson 078, lesson 127

Compare the original and cleaned message, then see which category the model predicts.

## ▶️ Run it

From the extracted lesson folder, run the two commands below. You only need to install its packages once.

```bash
python -m pip install -r requirements.txt
python lesson.py
```

## ✅ Expected result

Read the original message, the cleaned message and the predicted category on the same row.

```text
Original message   Cleaned message
MY Parcel Is Late!!! my parcel is late
Raw message             Clean message Prediction
```

[See the full example output](expected-output.txt).

If the result differs on your first run, restore the original CSVs, run from the extracted lesson folder, and read the first error message if Python stops.

## 🧪 Try one change

Try WHERE IS MY PARCEL!!! and check that cleanup produces where is my parcel.

[Open the Python script](lesson.py) · [Open sample.csv](sample.csv) · [Open new_inputs.csv](new_inputs.csv)

## What the code does

1. Read the support messages and their known categories.
2. Keep the same lowercase and punctuation rules for training and new messages.
3. Set aside the check rows before the model learns.
4. Teach the model from the training inputs and the known message category.
5. Apply the fitted model to the new CSV rows and print a result for each row.

## 📋 Sample data

| message | category |
| --- | --- |
| MY Parcel Is Late!!! | delivery |
| Where is my PACKAGE? | delivery |
| The parcel never arrived. | delivery |
| Please REFUND my payment! | billing |
| My invoice is WRONG? | billing |
| I was charged twice. | billing |
| Where is my parcel? | delivery |
| Please refund this charge! | billing |

## 📩 Supplied new inputs

| message |
| --- |
| WHERE IS MY PARCEL!!! |
| REFUND my card charge! |
| The package never arrived. |
