# Normalization

**Practice**

Put the numerical inputs on a common scale before using the invented wine measurements in a model.

## ▶️ Run it

Extract this ZIP and open a terminal in the lesson folder.

```bash
python -m pip install -r requirements.txt
python lesson.py
```

## ✅ Expected result

Find three 0.0 training minima and three 1.0 training maxima, one pair for each numeric column.

```text
Min-Max training minima: [0.0, 0.0, 0.0]
Min-Max training maxima: [1.0, 1.0, 1.0]
```

[Full run output](expected-output.txt) · [Python script](lesson.py) · [Sample CSV](sample.csv) · [Inputs to change](new_inputs.csv)

## 🧪 Try a change

Change an input in new_inputs.csv. Compare the predictions with the held-out check above.
