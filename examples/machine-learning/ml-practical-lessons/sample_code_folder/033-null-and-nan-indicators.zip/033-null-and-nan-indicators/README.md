# Null and NaN indicators

**Practice** · Shared code with lesson 030, lesson 031, lesson 032

Use pandas to count blank cells and question marks as missing.

## ▶️ Run it

From the extracted lesson folder, run the two commands below. You only need to install its packages once.

```bash
python -m pip install -r requirements.txt
python lesson.py
```

## ✅ Expected result

Look for `Column  Missing cells` in the output excerpt below. Match it to the supplied CSV before changing any values.

```text
Column  Missing cells
distance_km              0
weight_kg              1
```

[See the full example output](expected-output.txt).

If the result differs on your first run, restore the original CSVs, run from the extracted lesson folder, and read the first error message if Python stops.

## 🧪 Try one change

Enter a blank cell and a question mark in sample.csv. Check that both appear in the missing count.

[Open the Python script](lesson.py) · [Open sample.csv](sample.csv)

## What the code does

1. Read the delivery table. Distance is in km, and weight is in kg.
2. Find blanks in the rows you are about to use.

## 📋 Sample data

| distance_km | weight_kg | zone | delivery_minutes |
| --- | --- | --- | --- |
| 2 | 1 | north | 19 |
| 4 | — | north | 30 |
| 6 | 2 | — | 29 |
| 8 | 4 | south | 40 |
| 10 | 1 | ? | 33 |
| 12 | 3 | south | 44 |
