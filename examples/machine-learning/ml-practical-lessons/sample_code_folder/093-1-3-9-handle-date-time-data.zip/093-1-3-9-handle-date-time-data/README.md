# 1.3.9 Handle Date/Time Data

**Practice** · Shared code with lesson 094, lesson 130

Read written dates and timestamps so Python can use them consistently.

## ▶️ Run it

From the extracted lesson folder, run the two commands below. You only need to install its packages once.

```bash
python -m pip install -r requirements.txt
python lesson.py
```

## ✅ Expected result

Look for `['2025-02-03', '2025-02-04', 'invalid date', '2023-02-10']` in the output excerpt below. Match it to the supplied CSV before changing any values.

```text
['2025-02-03', '2025-02-04', 'invalid date', '2023-02-10']
```

[See the full example output](expected-output.txt).

If the result differs on your first run, restore the original CSVs, run from the extracted lesson folder, and read the first error message if Python stops.

## 🧪 Try one change

Change raw_date in sample.csv, for example from 02/03/2025 to invalid. Compare the printed rows.

[Open the Python script](lesson.py) · [Open sample.csv](sample.csv)

## What the code does

1. Read the raw date strings, including different formats and an invalid value.
2. Print the result next to the input values so you can compare them.

## 📋 Sample data

| raw_date |
| --- |
| 02/03/2025 |
| 2025-02-04 |
| invalid |
| 1676025600 |

## 📊 Read the visual

![Read the time. Parse the input string as a timestamp. → Extract fields. 2025, month 2, day 5. Wednesday at hour 9. → Choose inputs. Use hour and weekday if they matter for predicting order counts.](datetime-feature-steps-mobile.png)

**👀 Read the visual.** Use the date and time 2025-02-05 09:00 as a worked example.

**👉 What to do.** Change **09:00** to **17:00** and find the difference in the Hour column.
