# Description

**Reference** · Shared code with lesson 284

Inspect the columns in the invented flower measurements and see what each row represents.

## ▶️ Run it

From the extracted lesson folder, run the two commands below. You only need to install its packages once.

```bash
python -m pip install -r requirements.txt
python lesson.py
```

## ✅ Expected result

Look for `PDF reference: UCI Iris Dataset` in the output excerpt below. Match it to the supplied CSV before changing any values.

```text
PDF reference: UCI Iris Dataset
Origin of this CSV: original synthetic practice rows
Rows: 8
```

[See the full example output](expected-output.txt).

If the result differs on your first run, restore the original CSVs, run from the extracted lesson folder, and read the first error message if Python stops.

## 🧪 Try one change

Add another original example in sample.csv. Rerun to check that its columns and row count make sense.

[Open the Python script](lesson.py) · [Open sample.csv](sample.csv)

## What the code does

1. Read the example records from sample.csv. The table uses the dataset fields shown below.
2. Print the result next to the input values so you can compare them.

## 📋 Sample data

| sepal_length | sepal_width | petal_length | petal_width | species |
| --- | --- | --- | --- | --- |
| 3 | 2 | 1 | .2 | star |
| 3.2 | 2.1 | 1.2 | .3 | star |
| 4.5 | 2 | 3 | .8 | fan |
| 4.6 | 2.1 | 3.1 | .9 | fan |
| 6.1 | 3 | 5 | 2 | bell |
| 6.2 | 3.1 | 5.2 | 4.6 | bell |
| 4.7 | 2.2 | 3.2 | .9 | fan |
| 5.9 | 2.9 | 4.9 | 1.9 | bell |
