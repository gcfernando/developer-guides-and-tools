# Audio (Waves, Spectrograms)

**Practice** · Shared code with lesson 119, lesson 120, lesson 121

Create tones, inspect how their pitch looks in a plot, and classify them.

## ▶️ Run it

From the extracted lesson folder, run the two commands below. You only need to install its packages once.

```bash
python -m pip install -r requirements.txt
python lesson.py
```

## ✅ Expected result

Look for `One MFCC row: 8` in the output excerpt below. Match it to the supplied CSV before changing any values.

```text
One MFCC row: 8
New WAV sound: ['high']
Decoded MP3 sound: ['high']
```

[See the full example output](expected-output.txt).

If the result differs on your first run, restore the original CSVs, run from the extracted lesson folder, and read the first error message if Python stops.

## 🧪 Try one change

Change the frequency in new_inputs.csv to a value around 280 or 900. The script creates real WAV audio from those numbers and checks an MP3 round trip.

[Open the Python script](lesson.py) · [Open sample.csv](sample.csv) · [Open new_inputs.csv](new_inputs.csv)

## What the code does

1. Build a short sound from a frequency in the CSV.
2. Read the tone frequencies. Each row describes one sound to make.
3. Fit the model on the prepared training rows. Keep it for the checks below.
4. Apply the fitted model to the new CSV rows and print a result for each row.

## 📋 Sample data

| frequency_hz | label |
| --- | --- |
| 260 | low |
| 300 | low |
| 840 | high |
| 900 | high |

## 📩 Supplied new inputs

| frequency_hz |
| --- |
| 870 |
| 285 |
| 920 |

## 📊 Read the visual

![Open the recording. Read the waveform, which is the sound signal over time. → Measure frequencies. Open a spectrogram or summarize the tone with MFCC features. → Try a new tone. Apply the same steps and check the predicted sound class.](audio-feature-steps.png)

**👀 Read the visual.** Turn a practice recording into measurements the model can use.

**👉 What to do.** Try a higher pitch and look for a higher band in the spectrogram.
