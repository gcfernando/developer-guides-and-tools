# State

**Practice**

Give the robot different starting positions and see its next state.

## ▶️ Run it

From the extracted lesson folder, run the two commands below. You only need to install its packages once.

```bash
python -m pip install -r requirements.txt
python lesson.py
```

## ✅ Expected result

Look for `Start Action  Next cell  Reward  At goal` in the output excerpt below. Match it to the supplied CSV before changing any values.

```text
The state is the robot's current cell on the track.
Start Action  Next cell  Reward  At goal
0   left          0   -0.02    False
```

[See the full example output](expected-output.txt).

If the result differs on your first run, restore the original CSVs, run from the extracted lesson folder, and read the first error message if Python stops.

## 🧪 Try one change

Try changing start from 0 to 2 in new_inputs.csv. Compare the new output.

[Open the Python script](lesson.py) · [Open sample.csv](sample.csv) · [Open new_inputs.csv](new_inputs.csv)

## What the code does

1. Read the track rules. Each row describes one move and its reward.
2. Read the new CSV rows, then apply the rules from the sample.

## 📋 Sample data

| state | action | next_state | reward | done |
| --- | --- | --- | --- | --- |
| 0 | 0 | 0 | -0.02 | False |
| 0 | 1 | 1 | -0.02 | False |
| 1 | 0 | 0 | -0.02 | False |
| 1 | 1 | 2 | -0.02 | False |
| 2 | 0 | 1 | -0.02 | False |
| 2 | 1 | 3 | -0.02 | False |
| 3 | 0 | 2 | -0.02 | False |
| 3 | 1 | 4 | 1.0 | True |

## 📩 Supplied new inputs

| start | action |
| --- | --- |
| 0 | 0 |
| 0 | 1 |
| 2 | 1 |
| 3 | 1 |
