# Gradient Boosting (GBM)

**Practice**

Fit trees in sequence so later trees can correct earlier time errors.

## ▶️ Run it

From the extracted lesson folder, run the two commands below. You only need to install its packages once.

```bash
python -m pip install -r requirements.txt
python lesson.py
```

## ✅ Expected result

Check the mean absolute error (MAE) on the test deliveries. GradientBoostingRegressor misses the actual delivery time by an average of 3.99 minutes.

```text
GradientBoostingRegressor MAE: 3.99
```

[See the full example output](expected-output.txt).

If the result differs on your first run, restore the original CSVs and run the script again.

## 🧪 Try one change

Change km or kg in new_inputs.csv. The model is trained on sample.csv. The new rows only receive predictions.

[Open the Python script](lesson.py) · [Open sample.csv](sample.csv) · [Open new_inputs.csv](new_inputs.csv)

## What the code does

1. Read the practice deliveries. Use km for distance and kg for parcel weight.
2. Set the test rows aside. Drop any training rows with the same distance and weight as a test row.
3. Teach the model from the training inputs and delivery time in minutes.
4. Compare predictions with the measured answers in the check rows.
5. Apply the fitted model to the new CSV rows and print a result for each row.

## 📋 Sample data

| km | kg | minutes |
| --- | --- | --- |
| 48 | 4 | 90.0 |
| 32 | 6 | 71.0 |
| 35 | 5 | 72.5 |
| 45 | 3 | 84.5 |
| 29 | 12 | 77.5 |
| 39 | 1 | 71.5 |
| 42 | 2 | 79.0 |
| 12 | 3 | 32.0 |

Showing the first 8 of 60 rows. The CSV has the full sample.

## 📩 Supplied new inputs

| km | kg |
| --- | --- |
| 5 | 2 |
| 16 | 4 |
| 42 | 9 |
