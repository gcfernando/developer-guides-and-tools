# Source

**Reference** · Shared code with lesson 319

Read the dataset name from the PDF and inspect the invented shopper records used in this exercise.

## ▶️ Run it

From the extracted lesson folder, run the two commands below. You only need to install its packages once.

```bash
python -m pip install -r requirements.txt
python lesson.py
```

## ✅ Expected result

Find the reference dataset name and the sample file’s column types. Check that the rows describe the fields listed there.

```text
PDF reference: Kaggle Customer Segmentation Dataset
Origin of this CSV: original synthetic practice rows
Rows: 10
```

[See the full example output](expected-output.txt).

If the result differs on your first run, restore the original CSVs, run from the extracted lesson folder, and read the first error message if Python stops.

## 🧪 Try one change

Add another original example in sample.csv. Rerun to check that its columns and row count make sense.

[Open the Python script](lesson.py) · [Open sample.csv](sample.csv)

## What the code does

1. Read the example records from sample.csv. The table uses the dataset fields shown below.
2. Print the result next to the input values so you can compare them.

## 📋 Sample data

| age | annual_income | score | region |
| --- | --- | --- | --- |
| 21 | 24000 | 68 | north |
| 24 | — | 72 | north |
| 22 | 27000 | 70 | north |
| 42 | 57000 | 40 | south |
| 46 | 60000 | — | south |
| 44 | 56000 | 42 | south |
| 60 | 94000 | 75 | west |
| 58 | 90000 | 77 | west |

Showing the first 8 of 10 rows. The CSV has the full sample.
