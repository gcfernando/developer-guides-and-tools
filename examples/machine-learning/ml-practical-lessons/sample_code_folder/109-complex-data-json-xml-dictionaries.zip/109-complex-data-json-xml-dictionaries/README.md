# Complex Data (JSON, XML, Dictionaries)

**Practice** · Shared code family (see lesson 105 for the same script)

Read the same delivery fields from a nested dictionary, JSON, and XML.

## ▶️ Run it

From the extracted lesson folder, run the two commands below. You only need to install its packages once.

```bash
python -m pip install -r requirements.txt
python lesson.py
```

## ✅ Expected result

Look for `address  minutes  parcel.kg  latitude  longitude` in the output excerpt below. Match it to the supplied CSV before changing any values.

```text
address  minutes  parcel.kg  latitude  longitude
Depot North       10        1.0     59.35      18.05
Depot South       16        3.0     59.28      18.02
```

[See the full example output](expected-output.txt).

If the result differs on your first run, restore the original CSVs, run from the extracted lesson folder, and read the first error message if Python stops.

## 🧪 Try one change

Change address in sample.csv, for example from Depot North to Depot South. Compare the printed rows.

[Open the Python script](lesson.py) · [Open sample.csv](sample.csv)

## What the code does

1. Read the weights in kilograms and the delivery times in minutes.
2. Print the result next to the input values so you can compare them.
3. Teach the model from the training inputs and delivery time in minutes.

## 📋 Sample data

| address | weight_kg | minutes |
| --- | --- | --- |
| Depot North | 1 | 10 |
| Depot South | 3 | 16 |
| Depot North | — | 12 |
| Unknown | 2 | 15 |
