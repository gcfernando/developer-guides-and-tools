# Geocoding APIs

**Reference** · Shared code with lesson 106, lesson 107 · **Local example + manual walkthrough**

Try a local address lookup and see how it handles an address outside its small list.

## ▶️ Run it

From the extracted lesson folder, run the two commands below. You only need to install its packages once.

```bash
python -m pip install -r requirements.txt
python lesson.py
```

## ✅ Expected result

Look for `address  weight_kg             latitude            longitude    estimated_minutes` in the output excerpt below. Match it to the supplied CSV before changing any values.

```text
address  weight_kg             latitude            longitude    estimated_minutes
North Depot          3                59.35                18.06                 22.5
South Depot          2                59.28                18.02                 23.0
```

[See the full example output](expected-output.txt).

If the result differs on your first run, restore the original CSVs, run from the extracted lesson folder, and read the first error message if Python stops.

## 🧪 Try one change

Change address in new_inputs.csv, for example from North Depot to Unknown Depot. Compare the printed rows.

[Open the Python script](lesson.py) · [Open sample.csv](sample.csv) · [Open new_inputs.csv](new_inputs.csv)

## What the code does

1. Read the weights in kilograms and the delivery times in minutes.
2. Teach the model from the training inputs and delivery time in minutes.
3. Read the new CSV rows, then apply the rules from the sample.
4. Separate addresses with coordinates from those that need review.

## 📋 Sample data

| address | weight_kg | minutes |
| --- | --- | --- |
| North Depot | 2 | 19 |
| South Depot | 1 | 21 |
| River Depot | 2 | 27 |
| North Depot | 5 | 29 |
| South Depot | 3 | 25 |

## 📩 Supplied new inputs

| address | weight_kg |
| --- | --- |
| North Depot | 3 |
| South Depot | 2 |
| Unknown Depot | 2 |


See [External services](EXTERNAL-SERVICES.md) for the platform steps.
