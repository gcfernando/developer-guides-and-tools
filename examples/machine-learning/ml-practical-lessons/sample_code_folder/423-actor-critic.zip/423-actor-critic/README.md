# Actor-Critic

**Practice**

Use one part to choose actions and another to estimate how good they are.

## ▶️ Run it

From the extracted lesson folder, run the two commands below. You only need to install its packages once.

```bash
python -m pip install -r requirements.txt
python lesson.py
```

## ✅ Expected result

Look for `Policy gradient chosen button: 1` in the output excerpt below. Match it to the supplied CSV before changing any values.

```text
Policy gradient chosen button: 1
Actor-Critic chosen button: 1
Estimated policy value: 0.72
```

[See the full example output](expected-output.txt).

If the result differs on your first run, restore the original CSVs, run from the extracted lesson folder, and read the first error message if Python stops.

## 🧪 Try one change

Swap the two reward chances in sample.csv. Rerun and see which button each method prefers.

[Open the Python script](lesson.py) · [Open sample.csv](sample.csv)

## What the code does

1. Read the CSV and check its inputs, including button, chance_of_reward.
2. Compare the printed output with the original values.

## 📋 Sample data

| button | chance_of_reward |
| --- | --- |
| left | 0.25 |
| right | 0.75 |
