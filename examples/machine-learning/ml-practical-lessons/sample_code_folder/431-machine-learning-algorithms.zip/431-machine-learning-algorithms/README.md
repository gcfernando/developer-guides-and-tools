# Machine Learning Algorithms

**Practice**

Use delivery data to connect the diagram’s regression branch to a concrete prediction.

## ▶️ Run it

From the extracted lesson folder, run the two commands below. You only need to install its packages once.

```bash
python -m pip install -r requirements.txt
python lesson.py
```

## ✅ Expected result

Look for `Simple predictions: [45.0, 51.2]` in the output excerpt below. Match it to the supplied CSV before changing any values.

```text
Simple predictions: [45.0, 51.2]
Multiple-predictor predictions: [31.0, 42.0]
Two outcomes per row: [[31.0, 1.55], [42.0, 1.95]]
```

[See the full example output](expected-output.txt).

If the result differs on your first run, restore the original CSVs, run from the extracted lesson folder, and read the first error message if Python stops.

## 🧪 Try one change

Edit the input values in new_inputs.csv and compare the displayed predictions.

[Open the Python script](lesson.py) · [Open sample.csv](sample.csv) · [Open new_inputs.csv](new_inputs.csv)

## What the code does

1. Read the delivery table. Distance is in km, and weight is in kg.
2. Set aside the check rows before the model learns.
3. Teach the model from the training inputs and delivery time in minutes.
4. Apply the fitted model to the new CSV rows and print a result for each row.

## 📋 Sample data

| distance_km | weight_kg | delivery_minutes |
| --- | --- | --- |
| 2 | 1 | 19 |
| 4 | 3 | 30 |
| 6 | 2 | 29 |
| 8 | 4 | 40 |
| 10 | 1 | 33 |
| 12 | 3 | 44 |

## 📩 Supplied new inputs

| distance_km | weight_kg |
| --- | --- |
| 5 | 2 |
| 13 | 3 |
| 20 | 7 |
