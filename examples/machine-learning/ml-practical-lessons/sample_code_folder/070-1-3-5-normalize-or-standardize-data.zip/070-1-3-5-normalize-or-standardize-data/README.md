# 1.3.5 Normalize or Standardize Data

**Practice** · Shared code with lesson 125, lesson 175

Learn a scale from training deliveries and reuse it on new rows.

## ▶️ Run it

From the extracted lesson folder, run the two commands below. You only need to install its packages once.

```bash
python -m pip install -r requirements.txt
python lesson.py
```

## ✅ Expected result

Look for `New deliveries and their predicted minutes` in the output excerpt below. Match it to the supplied CSV before changing any values.

```text
New deliveries and their predicted minutes
distance_km  weight_kg  scaled_distance  scaled_weight  predicted_minutes
5          2             0.50           0.33               27.5
```

[See the full example output](expected-output.txt).

If the result differs on your first run, restore the original CSVs, run from the extracted lesson folder, and read the first error message if Python stops.

## 🧪 Try one change

In new_inputs.csv, try 5 km and 2 kg, then try 12 km and 4 kg. Read the scaled values and predicted minutes in the same row.

[Open the Python script](lesson.py) · [Open sample.csv](sample.csv) · [Open new_inputs.csv](new_inputs.csv)

## What the code does

1. Read the delivery table. Distance is in km, and weight is in kg.
2. Set aside the check rows before the model learns.
3. Learn the conversion on the training inputs before applying it to a new row.
4. Teach the model from the training inputs and delivery time in minutes.
5. Apply the fitted model to the new CSV rows and print a result for each row.
6. Compare predictions with the measured answers in the check rows.

## 📋 Sample data

| distance_km | weight_kg | delivery_minutes |
| --- | --- | --- |
| 2 | 1 | 19 |
| 4 | 3 | 30 |
| 6 | 2 | 29 |
| 8 | 4 | 40 |
| 10 | 1 | 33 |
| 12 | 3 | 44 |

## 📩 Supplied new inputs

| distance_km | weight_kg |
| --- | --- |
| 5 | 2 |
| 10 | 3 |
| 12 | 4 |
