# Cross-validation

**Practice**

Take turns holding different deliveries back and compare the error on each group.

## ▶️ Run it

From the extracted lesson folder, run the two commands below. You only need to install its packages once.

```bash
python -m pip install -r requirements.txt
python lesson.py
```

## ✅ Expected result

Check the **Average error in minutes** column. Each row of the table is a different group kept back for checking.

```text
Fold  Rows to learn  Rows to check  Average error in minutes
1              4              2                      0.37
2              4              2                      0.49
```

[See the full example output](expected-output.txt).

If the result differs on your first run, restore the original CSVs, run from the extracted lesson folder, and read the first error message if Python stops.

## 🧪 Try one change

Change the known time for one delivery. Rerun and find which fold errors change.

[Open the Python script](lesson.py) · [Open sample.csv](sample.csv)

## What the code does

1. Read the delivery table. Distance is in km, and weight is in kg.
2. Take turns keeping one group back for a check. Read each group’s average error in minutes.

## 📋 Sample data

| distance_km | weight_kg | delivery_minutes |
| --- | --- | --- |
| 2 | 1 | 19 |
| 4 | 3 | 30 |
| 6 | 2 | 29 |
| 8 | 4 | 40 |
| 10 | 1 | 33 |
| 12 | 3 | 44 |
