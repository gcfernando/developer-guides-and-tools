# Capstone: From delivery CSV to local model service

**Core**

Train, validate, test, and save a model. Send local requests and monitor later labeled deliveries.

## ▶️ Run it

Extract this ZIP and open a terminal in the lesson folder.

```bash
python -m pip install -r requirements.txt
python lesson.py
```

## ✅ Expected result

Ridge wins validation. Test MAE is 2.80 minutes and later-batch MAE rises to 5.59. Three requests are accepted and three return 422.

```text
Train: 430. Validation: 140. Test: 150.
Selected: Ridge. Final test MAE: 2.80 minutes.
Later batch: 180 orders, MAE 5.59 minutes.
Decision: INVESTIGATE. The practice alert triggers above a 2-minute increase.
```

[Full run output](expected-output.txt) · [Python script](lesson.py) · [Sample CSV](sample.csv) · [Inputs to change](new_inputs.csv)

## 🧪 Try a change

Change the 90 km request to 60 km. Run python send_requests.py to use your saved model. That request should receive 200 and an estimate.

## 📋 Data dictionary

| File or field | Meaning |
| --- | --- |
| sample.csv | 720 invented, completed deliveries in date order, split by whole dates into 430 training, 140 validation, and 150 test orders. |
| later_batch.csv | 180 later deliveries with measured outcomes. Use them for monitoring after the final test. |
| new_inputs.csv | Example requests, including a blank weight, invalid distance, and unknown zone. |
| shipment_id | Unique delivery identifier. It is used to check records, and stays out of the model. |
| delivery_date | Date used to split and monitor shipments. The model does not receive this field. |
| distance_km | Input distance in kilometers. The service checks the training range. |
| weight_kg | Input in kilograms. A blank weight is handled by the training median in the Ridge pipeline. |
| zone | North, South, or West. The service rejects unrecognized values. |
| actual_minutes | Measured delivery time. It is provided for training and scoring only. |

## 🚚 Try the live service on this computer

1. Run `python lesson.py` to create the model and run the example requests using a local test client.
2. Start the app with `python -m uvicorn service:create_app --factory --host 127.0.0.1 --port 8000`. Leave that terminal open.
3. In a browser open [local interactive API docs](http://127.0.0.1:8000/docs). Open POST /predict, select **Try it out**, enter the JSON below, and select **Execute**.

```json
{"distance_km": 15, "weight_kg": 3, "zone": "North"}
```

You should see status 200 and about 32.3 minutes. Change 15 to 90 to get 422. Stop the server with Ctrl+C after practice. Run `python monitor.py` to inspect the later batch again without training.

For CSV requests without retraining, edit `new_inputs.csv` and run `python send_requests.py`. To perform only the training step, run `python fit_delivery_model.py`.

The saved artifact includes `model-info.json` with the columns, training distance limits, allowed zones, test result, and package versions. Use the Joblib file you generated yourself. This capstone uses synthetic data and a local service.

## 🧾 Score your work

| Points | What to show |
| --- | --- |
| 2 | Explain each column and why the ID, date, and actual time stay out of API inputs. |
| 2 | Show the chronological split and why it keeps later orders out of model selection. |
| 2 | Name the validation winner and report the final test MAE in minutes. |
| 2 | Demonstrate an accepted request and a rejected request, and explain each response. |
| 2 | Compare the later batch with the test and explain why West deserves a closer look. |

The alert calls for investigation. Verify measurements and routing changes, then compare any replacement on a separate later batch before updating the service.
