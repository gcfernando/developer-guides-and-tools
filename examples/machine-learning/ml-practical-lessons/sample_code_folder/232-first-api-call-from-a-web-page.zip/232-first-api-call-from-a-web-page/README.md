# First API call from a web page

**Practice** · Shared code with lesson 218, lesson 231

Send a distance to a local model from a web page and read the response.

## ▶️ Run it

From the extracted lesson folder, run the two commands below. You only need to install its packages once.

```bash
python -m pip install -r requirements.txt
python lesson.py
```

## ✅ Expected result

Read **200** for the page and **18.0 minutes** for the 4 km request.

```text
Action  HTTP status  Predicted minutes
Open the page          200                NaN
Predict 4 km          200               18.0
```

[See the full example output](expected-output.txt).

If the result differs on your first run, restore the original CSVs, run from the extracted lesson folder, and read the first error message if Python stops.

## 🧪 Try one change

Change 4 to 12 in new_inputs.csv. The local test request should report 34.0 minutes.

[Open the Python script](lesson.py) · [Open sample.csv](sample.csv) · [Open new_inputs.csv](new_inputs.csv)

## What the code does

1. Read the CSV and check its inputs, including distance_km, minutes.
2. Teach the model from the training inputs and delivery time in minutes.
3. Send each new CSV row to the app and read the response.

## 📋 Sample data

| distance_km | minutes |
| --- | --- |
| 1 | 12 |
| 2 | 14 |
| 3 | 16 |

## 📩 Supplied new inputs

| km |
| --- |
| 4 |
| 8 |
| 12 |

## Open the form on your computer

1. In the lesson folder run `python -m uvicorn lesson:app`.
2. Open [the local form](http://127.0.0.1:8000) in your browser.
3. Enter 4 km or 12 km and click **Predict**. Press **Ctrl+C** in the terminal when you finish.
