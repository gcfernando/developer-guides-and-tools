# RMSE

**Practice**

Use RMSE to give bigger errors more weight. Worked calculation using two test trips.

## ▶️ Run it

Extract this ZIP and open a terminal in the lesson folder.

```bash
python -m pip install -r requirements.txt
python lesson.py
```

## ✅ Expected result

RMSE is 2.0 minutes on two test deliveries. Use lesson 446 to measure a larger batch.

```text
Worked calculation: two test deliveries. Use lesson 446 for a larger evaluation.
Typical error in minutes, with extra weight on large misses.
2.0
 distance_km  weight_kg  prediction
           5          2        27.5
          13          3        43.5
          20          7        70.0
```

[Full run output](expected-output.txt) · [Python script](lesson.py) · [Sample CSV](sample.csv) · [Inputs to change](new_inputs.csv)

## 🧪 Try a change

Edit the input values in new_inputs.csv and compare the displayed predictions.
