# Image embeddings

**Practice**

Summarize a drawing with two numeric measurements and use them to predict its direction.

## ▶️ Run it

From the extracted lesson folder, run the two commands below. You only need to install its packages once.

```bash
python -m pip install -r requirements.txt
python lesson.py
```

## ✅ Expected result

Look for `Vertical spread  Horizontal spread Label or prediction` in the output excerpt below. Match it to the supplied CSV before changing any values.

```text
Vertical spread  Horizontal spread Label or prediction
0.00               1.12            Sideways
0.00               1.12            Sideways
```

[See the full example output](expected-output.txt).

If the result differs on your first run, restore the original CSVs, run from the extracted lesson folder, and read the first error message if Python stops.

## 🧪 Try one change

Try changing direction from Upright to Sideways in new_inputs.csv. Compare the new output.

[Open the Python script](lesson.py) · [Open sample.csv](sample.csv) · [Open new_inputs.csv](new_inputs.csv)

## What the code does

1. Read the CSV and check its inputs, including direction, position.
2. Read the new CSV rows, then apply the rules from the sample.
3. Fit the model on the prepared training rows. Keep it for the checks below.
4. Plot the values so you can see how they compare.

## 📋 Sample data

| direction | position |
| --- | --- |
| Sideways | 1 |
| Sideways | 3 |
| Upright | 1 |
| Upright | 3 |

## 📩 Supplied new inputs

| direction | position |
| --- | --- |
| Upright | 4 |
| Sideways | 2 |
