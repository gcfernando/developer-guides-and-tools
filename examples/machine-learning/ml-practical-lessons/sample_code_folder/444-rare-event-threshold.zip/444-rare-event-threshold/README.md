# Choose a cutoff for rare urgent orders

**Core** · Same labeled order CSV. Different decisions and scripts.

Compare precision and recall and pick an alert cutoff on validation orders before testing.

## ▶️ Run it

Extract this ZIP and open a terminal in the lesson folder.

```bash
python -m pip install -r requirements.txt
python lesson.py
```

## ✅ Expected result

The chosen cutoff catches 104 urgent test orders instead of 38. False alarms rise from 26 to 199.

```text
Validation urgent share: 17.1%. Always silent accuracy: 82.9%; recall: 0%.
Validation choice: cutoff 0.192; precision 40.0%; recall 70.1%.
                Rule  Cutoff  Urgent caught  Urgent missed  False alarms  Precision  Recall
             Default   0.500             38            105            26      0.594   0.266
Chosen on validation   0.192            104             39           199      0.343   0.727
Validation average precision: 0.504
```

[Full run output](expected-output.txt) · [Python script](lesson.py) · [Sample CSV](sample.csv) · [Inputs to change](new_inputs.csv)

## 🧪 Try a change

Change min_recall from 0.70 to 0.85. Check why the new cutoff is lower and how the alert counts change. Pick a target on validation only.

Open **precision-recall.png** after running the script.
