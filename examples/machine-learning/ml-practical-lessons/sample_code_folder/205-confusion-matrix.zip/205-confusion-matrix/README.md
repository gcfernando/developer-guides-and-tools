# Confusion Matrix

**Practice**

Locate missed urgent orders and false alarms in a labeled matrix.

## ▶️ Run it

Extract this ZIP and open a terminal in the lesson folder.

```bash
python -m pip install -r requirements.txt
python lesson.py
```

## ✅ Expected result

At cutoff 0.5, find the bottom-left cell for the one missed urgent order. The top-right cell counts two false alarms.

```text
Predicted regular  Predicted urgent
Actual regular                 10                 2
Actual urgent                   1                17
Missed urgent orders: 1. False alarms: 2.
```

[Full run output](expected-output.txt) · [Python script](lesson.py) · [Sample CSV](sample.csv) · [Inputs to change](new_inputs.csv)

## 🧪 Try a change

Set cutoff to 0.25. The missed-urgent count should fall to zero. Check the two false alarms.

Open **confusion-matrix.png** after running the script.
