# Practice

**Practice** · Shared code family (see lesson 277 for the same script)

Use sepal and petal measurements from invented flower measurements to estimate flower type.

## ▶️ Run it

From the extracted lesson folder, run the two commands below. You only need to install its packages once.

```bash
python -m pip install -r requirements.txt
python lesson.py
```

## ✅ Expected result

Look for `Flower measurements to review: {'sepal_length': 0, 'sepal_width': 0, 'petal_length': 0, 'petal_width': 1}` in the output excerpt below. Match it to the supplied CSV before changing any values.

```text
Flower measurements to review: {'sepal_length': 0, 'sepal_width': 0, 'petal_length': 0, 'petal_width': 1}
Actual: ['fan', 'bell']
Predicted: ['fan', 'bell']
```

[See the full example output](expected-output.txt).

If the result differs on your first run, restore the original CSVs, run from the extracted lesson folder, and read the first error message if Python stops.

## 🧪 Try one change

Change an input in new_inputs.csv. Compare the predictions with the held-out check above.

[Open the Python script](lesson.py) · [Open sample.csv](sample.csv) · [Open new_inputs.csv](new_inputs.csv)

## What the code does

1. Read the example records from sample.csv. The table uses the dataset fields shown below.
2. Set aside the check rows before the model learns.
3. Find where the middle values sit, then compare the remaining rows with those limits.
4. Plot the values so you can see how they compare.
5. Teach the model from the training inputs and the known flower type.
6. Apply the fitted model to the new CSV rows and print a result for each row.

## 📋 Sample data

| sepal_length | sepal_width | petal_length | petal_width | species |
| --- | --- | --- | --- | --- |
| 3 | 2 | 1 | .2 | star |
| 3.2 | 2.1 | 1.2 | .3 | star |
| 4.5 | 2 | 3 | .8 | fan |
| 4.6 | 2.1 | 3.1 | .9 | fan |
| 6.1 | 3 | 5 | 2 | bell |
| 6.2 | 3.1 | 5.2 | 4.6 | bell |
| 4.7 | 2.2 | 3.2 | .9 | fan |
| 5.9 | 2.9 | 4.9 | 1.9 | bell |

## 📩 Supplied new inputs

| sepal_length | sepal_width | petal_length | petal_width |
| --- | --- | --- | --- |
| 3.0 | 2.0 | 1.0 | 0.2 |
| 5.9 | 2.9 | 4.9 | 1.9 |
| 4.5 | 2.0 | 3.0 | 0.8 |
