# Categorical encoding

**Practice** · Shared code family (see lesson 349 for the same script)

Turn categories in the invented app listings into numbers the model can read.

## ▶️ Run it

From the extracted lesson folder, run the two commands below. You only need to install its packages once.

```bash
python -m pip install -r requirements.txt
python lesson.py
```

## ✅ Expected result

Look for `Missing ratings: 1` in the output excerpt below. Match it to the supplied CSV before changing any values.

```text
Missing ratings: 1
name  price  installs
Plan     35     80000
```

[See the full example output](expected-output.txt).

If the result differs on your first run, restore the original CSVs, run from the extracted lesson folder, and read the first error message if Python stops.

## 🧪 Try one change

Change price to $5 in new_inputs.csv. Run the same command and compare the result.

[Open the Python script](lesson.py) · [Open sample.csv](sample.csv) · [Open new_inputs.csv](new_inputs.csv)

## What the code does

1. Read the example records from sample.csv. The table uses the dataset fields shown below.
2. Set aside the check rows before the model learns.
3. Fit the model on the prepared training rows. Keep it for the checks below.
4. Apply the fitted model to the new CSV rows and print a result for each row.

## 📋 Sample data

| name | category | rating | price | installs |
| --- | --- | --- | --- | --- |
| Meter | tools | 4.1 | $0 | 1,000+ |
| Map | travel | 4.8 | $4 | 2,000+ |
| Puzzle | game | 3.9 | $0 | 650+ |
| Notes | tools | — | $1 | 550+ |
| Plan | travel | 4.1 | $35 | 80,000+ |
| Photo | — | 4.0 | $3 | 300+ |
| Quiz | game | 4.2 | $2 | 1,200+ |

## 📩 Supplied new inputs

| name | category | rating | price |
| --- | --- | --- | --- |
| Meter | tools | 4.1 | $0 |
| Quiz | game | 4.2 | $2 |
| Puzzle | game | 3.9 | $0 |
