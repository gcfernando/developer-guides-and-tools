# 1.5. Feature Engineering & Feature Selection

**Practice** · Shared code family (see lesson 161 for the same script)

See how creating or choosing useful input columns helps the model.

## ▶️ Run it

From the extracted lesson folder, run the two commands below. You only need to install its packages once.

```bash
python -m pip install -r requirements.txt
python lesson.py
```

## ✅ Expected result

Look for `accuracy     0.900` in the output excerpt below. Match it to the supplied CSV before changing any values.

```text
accuracy     0.900
precision    0.895
recall       0.944
```

[See the full example output](expected-output.txt).

If the result differs on your first run, restore the original CSVs, run from the extracted lesson folder, and read the first error message if Python stops.

## 🧪 Try one change

Edit new_inputs.csv and rerun the script. Change an input and its known answer consistently in sample.csv. Rerun the comparison and check what changes.

[Open the Python script](lesson.py) · [Open sample.csv](sample.csv) · [Open new_inputs.csv](new_inputs.csv)

## What the code does

1. Read the CSV and check its inputs, including distance, weight, answer.
2. Set aside the check rows before the model learns.
3. Fit the model on the prepared training rows. Keep it for the checks below.
4. Check how often the model gets the known answers right on the rows you set aside.
5. Plot the values so you can see how they compare.
6. Apply the fitted model to the new CSV rows and print a result for each row.

## 📋 Sample data

| distance | weight | answer |
| --- | --- | --- |
| 37 | 5 | 1 |
| 25 | 7 | 1 |
| 27 | 5 | 1 |
| 35 | 7 | 1 |
| 23 | 6 | 0 |
| 31 | 7 | 1 |
| 33 | 10 | 1 |
| 9 | 2 | 0 |

Showing the first 8 of 120 rows. The CSV has the full sample.

## 📩 Supplied new inputs

| distance | weight |
| --- | --- |
| 5 | 2 |
| 28 | 7 |
| 40 | 5 |

## 📊 Read the visual

![Raw input. Birth date: 2000-10-03. → Derived feature. Age on 2025-04-01: 24 years. → Reuse the rule. Follow the same reference-date rule for each new row.](features-from-raw-data.png)

**👀 Read the visual.** Choose fields the app can use when the request arrives.

**👉 What to do.** Use a feature only if the app knows it at prediction time. A measured delivery time arrives after the trip.
