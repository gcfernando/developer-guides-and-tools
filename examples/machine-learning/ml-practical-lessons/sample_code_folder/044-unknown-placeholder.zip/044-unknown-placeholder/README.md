# Unknown placeholder

**Practice**

Keep a blank zone visible to the model by using Unknown as its own category.

## ▶️ Run it

From the extracted lesson folder, run the two commands below. You only need to install its packages once.

```bash
python -m pip install -r requirements.txt
python lesson.py
```

## ✅ Expected result

Look for `Explicit Unknown  zone  filled  minutes` in the output excerpt below. Match it to the supplied CSV before changing any values.

```text
Explicit Unknown  zone  filled  minutes
NaN Unknown    29.00
south   south    40.00
```

[See the full example output](expected-output.txt).

If the result differs on your first run, restore the original CSVs, run from the extracted lesson folder, and read the first error message if Python stops.

## 🧪 Try one change

Change zone in new_inputs.csv, for example from ? to north. Compare the printed rows.

[Open the Python script](lesson.py) · [Open sample.csv](sample.csv) · [Open new_inputs.csv](new_inputs.csv)

## What the code does

1. Read the CSV and check its inputs, including zone, minutes.
2. Set aside the check rows before the model learns.
3. Read the new CSV rows, then apply the rules from the sample.
4. Give each method the same practice data so you can compare the results.

## 📋 Sample data

| zone | minutes |
| --- | --- |
| north | 19 |
| north | 30 |
| — | 29 |
| south | 40 |
| ? | 33 |
| south | 44 |

## 📩 Supplied new inputs

| zone |
| --- |
| ? |
| south |
| north |
| east |
