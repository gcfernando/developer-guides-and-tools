# Unknown placeholder

**Lesson 044 · Core**

## Your goal

Keep a blank zone visible to the model by using Unknown as its own category.

## Before you start

Distinguish a missing zone from a new, named zone.

Use the [learning path](../../LEARNING-PATH.md) to find the earlier skill, the [word list](../../GLOSSARY.md) for a term, and [Setup](../../SETUP.md) for computer steps. Extra-topic prerequisites and bridges are in [Extra topics](../../ELECTIVES.md). In an extracted ZIP, open README.html for the browser links and keep this folder directly inside the complete course folder.

## The idea in simple words

A categorical fill replaces a missing name with the most common training name or an explicit Unknown name.

**Why and when.** Use the mode if a common-category assumption is defensible. Preserve Unknown when missingness deserves its own visible category.

**A worked example to follow.** The lesson fits the fill and encoder on the first four rows. It then handles the same blank zone under both choices. An explicit Unknown is a chosen placeholder, not a measurement that the parcel came from a zone called Unknown.

**Input and output.** The supplied sample fields are `zone`, `minutes`. In that field order, one original row is:

```text
north | 19
```

`(missing)` means a blank, not zero. The result table below belongs to the original supplied files.

**Follow the Python.** Open the complete [lesson.py](lesson.py) beside these instructions. Keep inputs apart from measured answers. Follow this script’s split and fit, then trace the saved preparation into the held-back result and any new request. A request must not supply its own training answer. The [requirements file](requirements.txt) lists its packages. The next section gives exact run commands; use the same course Python to install and run.

## Guess first

A request says east and another leaves zone blank. Which one can a missing-value fill change? What must the service decide separately? Write a reason before running or opening the answer.

## Run one step at a time

1. Extract this ZIP. Open folders until you see `lesson.py`.
2. Open a terminal in that folder. Activate the course environment as shown in Setup. Every `python` below means that environment's Python.
3. The main path uses the common course packages. If this lesson needs more, use the same Python to install `requirements.txt` with the course constraint file. See Setup step 8. Do not install optional media packages just to read a lesson.
4. Run these lines one at a time. Wait for each to finish.

```bash
python lesson.py
```

## Check the result

Read the column names and units before the numbers. The original files produced this example. Your deliberate data edits may change it.

```text
Explicit Unknown  zone  filled  minutes
  NaN Unknown    29.00
south   south    40.00
north   north    24.50
 east    east    31.17
          Method  Check row Zone sent to encoder  Actual time (min)  Predicted time (min)
Explicit Unknown          5              Unknown                 33                  29.0
Explicit Unknown          6                south                 44                  40.0
```

[See the complete expected output](expected-output.txt). Explain one row aloud. A matching number is a check of the calculation, not proof of real-world quality.

## Change one thing

Change zone in new_inputs.csv, for example from ? to north. Compare the printed rows.

Open the named CSV in a plain text editor. Keep its column names and commas. Save the same file name before running again. If you invent a request by changing its inputs, clear its old measured answer. Only score it after you have a real outcome for that new case.

## If you get stuck

If a file is missing, list the files with `dir` or `ls` and enter the folder holding the script. If a column or value is wrong, compare it with a fresh extracted CSV. Use a new folder to start over; keep your edited copy if useful. Use Setup for package or terminal errors.

## Explain the result

**Common mistakes and limits.** An Unknown category with no training examples does not gain a learned effect merely because the name is written down. A new east zone and an absent zone are different situations.

<details markdown="1">
<summary>Check your choice and reason</summary>

The fill changes the blank. It does not turn the named east zone into the training mode. Unknown-name handling belongs to the encoder and service policy; test it explicitly.

</details>

After the guided file change above, close the notes and explain the same decision for a different supplied row. State one condition that makes this method unsuitable. If you cannot explain the reason, repeat the small worked example before adding more code.

## 📋 Sample data

| zone | minutes |
| --- | --- |
| north | 19 |
| north | 30 |
| — | 29 |
| south | 40 |
| ? | 33 |
| south | 44 |

## 📩 Supplied new inputs

| zone |
| --- |
| ? |
| south |
| north |
| east |

<!-- teaching-note:start -->
<!-- teaching-profile:category_fill -->
<!-- teaching-note:end -->
