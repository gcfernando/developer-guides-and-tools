# Which Technique Should You Use?

**Practice** · Shared code with lesson 073

Use the same validation folds to compare which transformation makes better predictions.

## ▶️ Run it

From the extracted lesson folder, run the two commands below. You only need to install its packages once.

```bash
python -m pip install -r requirements.txt
python lesson.py
```

## ✅ Expected result

Look for `Raw                         MAE 10.88` in the output excerpt below. Match it to the supplied CSV before changing any values.

```text
Raw                         MAE 10.88
Min-Max Scaling             MAE 12.18
Z-Score Standardization     MAE 10.94
```

[See the full example output](expected-output.txt).

If the result differs on your first run, restore the original CSVs, run from the extracted lesson folder, and read the first error message if Python stops.

## 🧪 Try one change

Try changing signal from 1 to 12 in sample.csv. Compare the new output.

[Open the Python script](lesson.py) · [Open sample.csv](sample.csv)

## What the code does

1. Read the sensor readings and their measured costs.
2. Compare the printed output with the original values.

## 📋 Sample data

| signal | cost |
| --- | --- |
| 1 | 10 |
| 5 | 18 |
| 12 | 25 |
| 20 | 31 |
| 35 | 41 |
| 80 | 53 |
| 160 | 64 |
| 10 | 23 |

Showing the first 8 of 9 rows. The CSV has the full sample.

These scores compare settings on validation folds. Use an independent test set for the final score after you choose a model.
