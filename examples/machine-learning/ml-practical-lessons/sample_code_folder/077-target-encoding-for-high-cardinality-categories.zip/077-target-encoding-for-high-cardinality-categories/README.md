# Target Encoding (For High-Cardinality Categories)

**Practice**

Summarize each supplier by its learned delay rate and try a supplier the model has never seen.

## ▶️ Run it

From the extracted lesson folder, run the two commands below. You only need to install its packages once.

```bash
python -m pip install -r requirements.txt
python lesson.py
```

## ✅ Expected result

Look for `supplier  delayed` in the output excerpt below. Match it to the supplied CSV before changing any values.

```text
supplier  delayed
S00        1
S01        1
```

[See the full example output](expected-output.txt).

If the result differs on your first run, restore the original CSVs, run from the extracted lesson folder, and read the first error message if Python stops.

## 🧪 Try one change

Enter S00 and a supplier name such as New Supplier. Compare their encoded values and estimated chances of delay.

[Open the Python script](lesson.py) · [Open sample.csv](sample.csv) · [Open new_inputs.csv](new_inputs.csv)

## What the code does

1. Read the CSV and check its inputs, including supplier, delayed.
2. Set aside the check rows before the model learns.
3. Fit the model on the prepared training rows. Keep it for the checks below.
4. Apply the fitted model to the new CSV rows and print a result for each row.

## 📋 Sample data

| supplier | delayed |
| --- | --- |
| S00 | 1 |
| S01 | 1 |
| S02 | 1 |
| S03 | 1 |
| S04 | 0 |
| S05 | 0 |
| S06 | 1 |
| S07 | 1 |

Showing the first 8 of 72 rows. The CSV has the full sample.

## 📩 Supplied new inputs

| supplier |
| --- |
| S00 |
| S03 |
| Unseen |
