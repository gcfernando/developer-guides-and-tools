# Encoding categorical variables

**Practice** · Shared code with lesson 074, lesson 075, lesson 126

Turn category names into input numbers the model can read.

## ▶️ Run it

From the extracted lesson folder, run the two commands below. You only need to install its packages once.

```bash
python -m pip install -r requirements.txt
python lesson.py
```

## ✅ Expected result

Look for `Original color  Red  Blue  Green` in the output excerpt below. Match it to the supplied CSV before changing any values.

```text
Original color  Red  Blue  Green
Red    1     0      0
Blue    0     1      0
```

[See the full example output](expected-output.txt).

If the result differs on your first run, restore the original CSVs, run from the extracted lesson folder, and read the first error message if Python stops.

## 🧪 Try one change

In new_inputs.csv, enter Red, Blue and an unfamiliar color such as Purple. See the encoded columns and predicted orders for each one.

[Open the Python script](lesson.py) · [Open sample.csv](sample.csv) · [Open new_inputs.csv](new_inputs.csv)

## What the code does

1. Read the CSV and check its inputs, including color, orders.
2. Set aside the check rows before the model learns.
3. Learn the conversion on the training inputs before applying it to a new row.
4. Teach the model from the training inputs and the recorded order count.
5. Apply the fitted model to the new CSV rows and print a result for each row.

## 📋 Sample data

| color | orders |
| --- | --- |
| Red | 20 |
| Blue | 12 |
| Green | 15 |
| Red | 22 |
| Blue | 14 |
| Green | 16 |
| Red | 23 |

## 📩 Supplied new inputs

| color |
| --- |
| Red |
| Blue |
| Purple |
