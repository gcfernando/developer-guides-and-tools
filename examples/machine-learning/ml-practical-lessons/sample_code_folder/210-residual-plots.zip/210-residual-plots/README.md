# Residual Plots

**Practice** · Shared code with lesson 208, lesson 209

Plot actual minutes minus predicted minutes to see where the model is off. Worked calculation using two test trips.

## ▶️ Run it

Extract this ZIP and open a terminal in the lesson folder.

```bash
python -m pip install -r requirements.txt
python lesson.py
```

## ✅ Expected result

The points represent only two held-out trips. Read each actual-minus-predicted error before interpreting the residual plot.

```text
Worked calculation: two test deliveries. Use lesson 446 for a larger evaluation.
RMSE: 2.0
MAE: 2.0
R²: 0.868
 distance_km  weight_kg  prediction
           5          2        27.5
          13          3        43.5
          20          7        70.0
```

[Full run output](expected-output.txt) · [Python script](lesson.py) · [Sample CSV](sample.csv) · [Inputs to change](new_inputs.csv)

## 🧪 Try a change

Edit the input values in new_inputs.csv and compare the displayed predictions.
