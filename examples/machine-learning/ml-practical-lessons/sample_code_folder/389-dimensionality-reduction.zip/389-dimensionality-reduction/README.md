# Dimensionality Reduction

**Practice** · Shared code with lesson 390, lesson 439

Shrink three input measurements into fewer measurements you can inspect.

## ▶️ Run it

From the extracted lesson folder, run the two commands below. You only need to install its packages once.

```bash
python -m pip install -r requirements.txt
python lesson.py
```

## ✅ Expected result

Look for `Variance explained: [0.94, 0.05]` in the output excerpt below. Match it to the supplied CSV before changing any values.

```text
Variance explained: [0.94, 0.05]
Output shape: (8, 2)
First two rows: [[-2.3, -0.19], [-1.66, -0.16]]
```

[See the full example output](expected-output.txt).

If the result differs on your first run, restore the original CSVs, run from the extracted lesson folder, and read the first error message if Python stops.

## 🧪 Try one change

Change a measurement in new_inputs.csv. The fitted scaler and algorithm process each row.

[Open the Python script](lesson.py) · [Open sample.csv](sample.csv) · [Open new_inputs.csv](new_inputs.csv)

## What the code does

1. Read the CSV and check its inputs, including long, wide, score.
2. Learn the conversion on the training inputs before applying it to a new row.
3. Apply the conversion learned from training to each new row.

## 📋 Sample data

| long | wide | score | group |
| --- | --- | --- | --- |
| 2 | 1 | 3 | 0 |
| 3 | 2 | 4 | 0 |
| 4 | 1 | 2 | 0 |
| 5 | 6 | 7 | 1 |
| 6 | 7 | 8 | 1 |
| 7 | 6 | 9 | 1 |
| 8 | 8 | 7 | 1 |
| 10 | 9 | 10 | 1 |

## 📩 Supplied new inputs

| long | wide | score |
| --- | --- | --- |
| 2 | 1 | 3 |
| 10 | 9 | 10 |
| 4 | 1 | 2 |
