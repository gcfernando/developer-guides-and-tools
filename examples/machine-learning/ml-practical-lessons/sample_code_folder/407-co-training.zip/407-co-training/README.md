# Co-Training

**Practice**

Let models trained on different input columns teach each other from unlabeled rows.

## ▶️ Run it

From the extracted lesson folder, run the two commands below. You only need to install its packages once.

```bash
python -m pip install -r requirements.txt
python lesson.py
```

## ✅ Expected result

Look for `Labeled / unlabeled training rows: 8 46` in the output excerpt below. Match it to the supplied CSV before changing any values.

```text
Labeled / unlabeled training rows: 8 46
Labels per view: [13, 13]
Holdout accuracy: 1.0
```

[See the full example output](expected-output.txt).

If the result differs on your first run, restore the original CSVs, run from the extracted lesson folder, and read the first error message if Python stops.

## 🧪 Try one change

Edit x or y in new_inputs.csv. These rows are kept separate from the rows with masked labels and the labeled check rows.

[Open the Python script](lesson.py) · [Open sample.csv](sample.csv) · [Open new_inputs.csv](new_inputs.csv)

## What the code does

1. Read the CSV and check its inputs, including x, y, label.
2. Set aside the check rows before the model learns.
3. Have the two classifiers exchange confident labels on unlabeled training rows.
4. Apply the fitted model to the new CSV rows and print a result for each row.

## 📋 Sample data

| x | y | label |
| --- | --- | --- |
| -1.9990158773140139 | -1.761003569993224 | 0 |
| -2.219310284289774 | -2.7124734710058194 | 0 |
| -2.363736628137378 | -2.79331724399717 | 0 |
| -1.951885117922049 | -0.9278278035563732 | 0 |
| -2.3937652148410637 | -2.4963799198559524 | 0 |
| -1.6081263598518414 | -1.7144903934719513 | 0 |
| -1.9156686008016812 | -2.744374435766564 | 0 |
| -2.023401457970619 | -1.4437574444333698 | 0 |

Showing the first 8 of 72 rows. The CSV has the full sample.

## 📩 Supplied new inputs

| x | y |
| --- | --- |
| -2 | -2 |
| 2 | 2 |
| 0.3 | 0.4 |
