# Forward Fill (ffill)

**Practice** · Shared code with lesson 045

Carry the most recent known count forward to fill a missing day.

## ▶️ Run it

From the extracted lesson folder, run the two commands below. You only need to install its packages once.

```bash
python -m pip install -r requirements.txt
python lesson.py
```

## ✅ Expected result

Look for `day  requests  forward  backward` in the output excerpt below. Match it to the supplied CSV before changing any values.

```text
day  requests  forward  backward
1      10.0     10.0      10.0
2       NaN     10.0      16.0
```

[See the full example output](expected-output.txt).

If the result differs on your first run, restore the original CSVs, run from the extracted lesson folder, and read the first error message if Python stops.

## 🧪 Try one change

Edit the input values in new_inputs.csv and compare the displayed predictions.

[Open the Python script](lesson.py) · [Open sample.csv](sample.csv) · [Open new_inputs.csv](new_inputs.csv)

## What the code does

1. Read the CSV and check its inputs, including day, requests.
2. Set aside the check rows before the model learns.
3. Fit the model on the prepared training rows. Keep it for the checks below.
4. Apply the fitted model to the new CSV rows and print a result for each row.

## 📋 Sample data

| day | requests |
| --- | --- |
| 1 | 10 |
| 2 | — |
| 3 | 16 |
| 4 | 19 |
| 5 | 22 |

## 📩 Supplied new inputs

| day |
| --- |
| 6 |
| 7 |
| 10 |
