# Common Algorithms

**Practice** · Shared code with lesson 420, lesson 425

Learn from trial moves until the robot can choose a better path.

## ▶️ Run it

From the extracted lesson folder, run the two commands below. You only need to install its packages once.

```bash
python -m pip install -r requirements.txt
python lesson.py
```

## ✅ Expected result

Look for `Best actions (0 left, 1 right): [1, 1, 1, 1]` in the output excerpt below. Match it to the supplied CSV before changing any values.

```text
Best actions (0 left, 1 right): [1, 1, 1, 1]
State values: [0.8, 0.86, 0.93, 1.0]
Moves for test starts: [1, 1, 1]
```

[See the full example output](expected-output.txt).

If the result differs on your first run, restore the original CSVs, run from the extracted lesson folder, and read the first error message if Python stops.

## 🧪 Try one change

Change a starting cell (0–3) in new_inputs.csv. Read the saved-in-memory policy’s preferred move, 0 left or 1 right.

[Open the Python script](lesson.py) · [Open sample.csv](sample.csv) · [Open new_inputs.csv](new_inputs.csv)

## What the code does

1. Read the track rules. Each row describes one move and its reward.
2. Read what happens after this move from the track table.
3. Read the new CSV rows, then apply the rules from the sample.

## 📋 Sample data

| state | action | next_state | reward | done |
| --- | --- | --- | --- | --- |
| 0 | 0 | 0 | -0.02 | False |
| 0 | 1 | 1 | -0.02 | False |
| 1 | 0 | 0 | -0.02 | False |
| 1 | 1 | 2 | -0.02 | False |
| 2 | 0 | 1 | -0.02 | False |
| 2 | 1 | 3 | -0.02 | False |
| 3 | 0 | 2 | -0.02 | False |
| 3 | 1 | 4 | 1.0 | True |

## 📩 Supplied new inputs

| start |
| --- |
| 0 |
| 1 |
| 3 |
