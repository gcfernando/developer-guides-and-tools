# Standardization (Z-score Scaling)

**Practice**

Measure distance and weight relative to their training averages, then estimate a new delivery time.

## ▶️ Run it

From the extracted lesson folder, run the two commands below. You only need to install its packages once.

```bash
python -m pip install -r requirements.txt
python lesson.py
```

## ✅ Expected result

Look for `New deliveries and their predicted minutes` in the output excerpt below. Match it to the supplied CSV before changing any values.

```text
New deliveries and their predicted minutes
distance_km  weight_kg  scaled_distance  scaled_weight  predicted_minutes
5          2             0.00          -0.45               27.5
```

[See the full example output](expected-output.txt).

If the result differs on your first run, restore the original CSVs, run from the extracted lesson folder, and read the first error message if Python stops.

## 🧪 Try one change

In new_inputs.csv, try 5 km and 2 kg, then try 12 km and 4 kg. Read the scaled values and predicted minutes in the same row.

[Open the Python script](lesson.py) · [Open sample.csv](sample.csv) · [Open new_inputs.csv](new_inputs.csv)

## What the code does

1. Read the practice deliveries and their measured times.
2. Use the first four trips to learn and keep the last two for checking.
3. Find the training average and spread for each input. Express each row in those units.
4. Teach the model how the scaled inputs relate to the measured minutes.
5. Read the new trips and scale them using the training values.
6. Compare estimates with the two known times, then read the estimates for your new trips.

## 📋 Sample data

| distance_km | weight_kg | delivery_minutes |
| --- | --- | --- |
| 2 | 1 | 19 |
| 4 | 3 | 30 |
| 6 | 2 | 29 |
| 8 | 4 | 40 |
| 10 | 1 | 33 |
| 12 | 3 | 44 |

## 📩 Supplied new inputs

| distance_km | weight_kg |
| --- | --- |
| 5 | 2 |
| 10 | 3 |
| 12 | 4 |
