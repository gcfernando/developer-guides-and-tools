# 3.3. Semi-Supervised Learning

**Practice** · Shared code with lesson 403, lesson 404

Fit a small classifier using rows with known and missing labels.

## ▶️ Run it

From the extracted lesson folder, run the two commands below. You only need to install its packages once.

```bash
python -m pip install -r requirements.txt
python lesson.py
```

## ✅ Expected result

The small search assigns two negative and two positive pseudo-labels. The new rows have no known answers.

```text
Chosen training pseudo-labels: (-1, -1, 1, 1)
Predictions for new rows: [-1, 1, 1]
```

[Full searched result](expected-output.txt).

## 🧪 Try one change

Change x and y in new_inputs.csv. Keep four blank-label rows in sample.csv if editing the training example.

[Open the Python script](lesson.py) · [Open sample.csv](sample.csv) · [Open new_inputs.csv](new_inputs.csv)

## What the code does

1. Read the CSV and check its inputs, including x, y, label.
2. Give each method the same practice data so you can compare the results.
3. Apply the fitted model to the new CSV rows and print a result for each row.

## 📋 Sample data

| x | y | label |
| --- | --- | --- |
| -2 | -2 | -1 |
| -1.6 | -1.9 | -1 |
| 1.8 | 1.9 | 1 |
| 2 | 2 | 1 |
| -1.4 | -1.3 | — |
| -0.8 | -1.2 | — |
| 1 | 0.9 | — |
| 1.5 | 1.3 | — |

## 📩 Supplied new inputs

| x | y |
| --- | --- |
| -1.1 | -1 |
| 1.1 | 1 |
| 0.2 | 0.7 |

## 📊 Read the visual

![Start with labels. Train a first model using the known classes. → Use unlabeled rows. Add confident guesses as extra training labels. → Check the change. Compare with the original model on labeled check rows.](semi-supervised-steps.png)

**👀 Read the visual.** Keep separate known answers to check whether the extra rows helped.

**👉 What to do.** If guesses are uncertain or checks get worse, collect more confirmed labels.

This intentionally small illustration searches a few possible labels. The new CSV has inputs without confirmed answers, so its predictions do not measure accuracy.
