# Standardize formats

**Core** · Shared code family (see lesson 054 for the same script)

Turn dates, pounds and uneven zone names into consistent model inputs, then predict a new delivery.

## ▶️ Run it

From the extracted lesson folder, run the two commands below. You only need to install its packages once.

```bash
python -m pip install -r requirements.txt
python lesson.py
```

## ✅ Expected result

Find a standardized ISO date and its weight in kilograms before reading the estimate.

```text
Original date Standard date Original weight  Weight (kg) Original zone Standard zone  South flag
01/02/2025    2025-01-02           10 lb         4.54         NORTH         north           0
2025-01-03    2025-01-03            8 kg         8.00         south         south           1
```

[See the full example output](expected-output.txt).

If the result differs on your first run, restore the original CSVs, run from the extracted lesson folder, and read the first error message if Python stops.

## 🧪 Try one change

Try 22 lb on 01/13/2025 in new_inputs.csv. The cleaned row should show 2025-01-13 and about 9.98 kg.

[Open the Python script](lesson.py) · [Open sample.csv](sample.csv) · [Open new_inputs.csv](new_inputs.csv)

## What the code does

1. Read the shipment records from both systems.
2. Write one cleanup function for dates, weight units and zone names.
3. Use the first four cleaned rows for training. Keep the final delivery for a check.
4. Give the model kilograms, a weekday number and a zone flag. Teach it the recorded minutes.
5. Clean new shipments with those same rules and estimate the minutes.

## 📋 Sample data

| ship_date | weight | unit | zone | minutes |
| --- | --- | --- | --- | --- |
| 01/02/2025 | 10 | lb | NORTH | 19 |
| 2025-01-03 | 8 | kg | south | 27 |
| 01/04/2025 | 35 | lbs | NORTH | 38 |
| 2025-01-05 | 16 | kg | south | 40 |
| 2025-01-06 | 12 | kg | north | 35 |

## 📩 Supplied new inputs

| ship_date | weight | unit | zone |
| --- | --- | --- | --- |
| 01/07/2025 | 18 | lb | NORTH |
| 2025-01-09 | 7 | kg | south |
| 2025-01-10 | 30 | lbs | north |

## 📊 Read the visual

![Raw shipment. US date 01/07/2025, weight 18 lb and zone NORTH. → Clean the fields. Date 2025-01-07. Weight 8.16 kg. Zone north. → Give model inputs. Use kilograms, the weekday and a zone indicator.](standardize-formats-steps-mobile.png)

**👀 Read the visual.** The same conversion steps run for training deliveries and new shipments.

**👉 What to do.** Give the model **8.16 kg** for this shipment. Its training weight column uses kilograms.
