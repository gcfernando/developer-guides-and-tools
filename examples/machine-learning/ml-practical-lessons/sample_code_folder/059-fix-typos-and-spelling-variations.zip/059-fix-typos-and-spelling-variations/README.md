# Fix typos and spelling variations

**Practice**

Map known spelling variants to a single category before encoding it.

## ▶️ Run it

From the extracted lesson folder, run the two commands below. You only need to install its packages once.

```bash
python -m pip install -r requirements.txt
python lesson.py
```

## ✅ Expected result

Look for `category standard` in the output excerpt below. Match it to the supplied CSV before changing any values.

```text
category standard
Male     Male
M     Male
```

[See the full example output](expected-output.txt).

If the result differs on your first run, restore the original CSVs, run from the extracted lesson folder, and read the first error message if Python stops.

## 🧪 Try one change

Try changing record_id from 1 to 3 in sample.csv. Compare the new output.

[Open the Python script](lesson.py) · [Open sample.csv](sample.csv)

## What the code does

1. Read the CSV and check its inputs, including record_id, category.
2. Give different spellings of the same value one consistent form.
3. Fit the model on the prepared training rows. Keep it for the checks below.

## 📋 Sample data

| record_id | category |
| --- | --- |
| 1 | Male |
| 2 | M |
| 3 | Female |
| 4 | female |
