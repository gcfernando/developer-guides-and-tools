# Standardize text cases and remove spaces

**Practice** · Shared code with lesson 051, lesson 053

Clean up capitalization and spaces so the same name has a consistent comparison key.

## ▶️ Run it

From the extracted lesson folder, run the two commands below. You only need to install its packages once.

```bash
python -m pip install -r requirements.txt
python lesson.py
```

## ✅ Expected result

Look for `Similar names: 0.91` in the output excerpt below. Match it to the supplied CSV before changing any values.

```text
Similar names: 0.91
Confirmed distinct orders: ['A', 'B']
```

[See the full example output](expected-output.txt).

If the result differs on your first run, restore the original CSVs, run from the extracted lesson folder, and read the first error message if Python stops.

## 🧪 Try one change

Try changing order_id from A to B in sample.csv. Compare the new output.

[Open the Python script](lesson.py) · [Open sample.csv](sample.csv)

## What the code does

1. Read the CSV and check its inputs, including order_id, name, minutes.
2. Give different spellings of the same value one consistent form.

## 📋 Sample data

| order_id | name | minutes |
| --- | --- | --- |
| A | Maya   Jensen | 19 |
| A | maya jensen | 19 |
| B | Maya Jenson | 31 |
