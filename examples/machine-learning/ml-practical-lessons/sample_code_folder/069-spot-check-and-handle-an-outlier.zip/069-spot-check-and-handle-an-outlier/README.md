# Spot, check, and handle an outlier

**Core**

Review a recorded 90 kg parcel, correct it using the weighing slip, and compare the two predictions on a graph.

## ▶️ Run it

From the extracted lesson folder, run the two commands below. You only need to install its packages once.

```bash
python -m pip install -r requirements.txt
python lesson.py
```

## ✅ Expected result

Find **Decision: CORRECT** and compare **17.7** with **26.0 minutes** for the same check parcel.

```text
Decision: CORRECT
The slip confirms 5 kg. Change 90 kg to 5 kg.
Check parcel 8
```

[See the full example output](expected-output.txt).

If the result differs on your first run, restore the original CSVs, run from the extracted lesson folder, and read the first error message if Python stops.

## 🧪 Try one change

In weighing_slip.csv, change the verified weight from 5 to 90 for KEEP. Clear the second cell for FLAG.

[Open the Python script](lesson.py) · [Open sample.csv](sample.csv)

## How the script works

1. Set aside parcel 8 and learn the review limits from the other seven weights.
2. Read the verified weight for parcel 5 from the source file.
3. Choose CORRECT, KEEP or FLAG. Save the decision in the terminal output.
4. Compare both model estimates for the same parcel and open the two PNG charts.

## 📋 Sample data

| parcel | weight_kg | minutes |
| --- | --- | --- |
| 1 | 1 | 12 |
| 2 | 2 | 14 |
| 3 | 3 | 16 |
| 4 | 4 | 18 |
| 5 | 90 | 20 |
| 6 | 6 | 22 |
| 7 | 7 | 24 |
| 8 | 8 | 26 |

## Try all three decisions

Leave sample.csv unchanged. Edit only the second cell in the data row of weighing_slip.csv, save, and run the same command.

| Verified weight on the slip | Expected decision | What the script does |
| --- | --- | --- |
| 5 | CORRECT | Uses 5 kg and predicts 26.0 minutes on the check parcel. |
| 90 | KEEP | Keeps 90 kg and predicts 17.7 minutes. |
| Blank | FLAG | Sets the row aside for this practice run and asks for a source check. |

Open [the weighing slip](weighing_slip.csv). Keep the parcel ID as 5.

## 📊 Read the visual

![Parcel 5 is plotted at 90 kg above the 12.5 kg review limit. Every other parcel is below the limit.](spot-check-and-handle-an-outlier-1.png)

**👀 Read the visual.** Find parcel 5 along the bottom. Its orange diamond is at **90 kg**. The dashed line shows the **12.5 kg** upper review limit learned from the seven training parcels.

**👉 What to do.** **Flag parcel 5 for review.** The plot tells you which record to check.

![Use the weighing slip to choose an action. A confirmed 5 kg means correct the entry. A confirmed 90 kg means keep it. A missing slip means flag for review.](outlier-source-decision.png)

**👀 Read the visual.** Follow the branch that matches the source. In this exercise the weighing slip shows **5 kg**, so the 90 kg entry gets corrected.

**👉 What to do.** Keep a confirmed 90 kg. If the source is missing, request a reweigh and leave the value flagged.

![For the same 8 kg test parcel, the original model predicted 17.7 minutes and the corrected model predicted 26.0 minutes. The dashed line shows the actual 26 minutes.](spot-check-and-handle-an-outlier-2.png)

**👀 Read the visual.** The dashed line is the real time for **parcel 8**, which was kept aside. The orange bar ends at **17.7 min**. The teal bar reaches **26.0 min**.

**👉 What to do.** Use the verified training correction, then check more held-out deliveries before trusting the improvement in an app.
