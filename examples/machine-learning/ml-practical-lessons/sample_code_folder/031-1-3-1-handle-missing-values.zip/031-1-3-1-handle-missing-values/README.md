# 1.3.1 Handle Missing Values

**Practice** · Shared code with lesson 030, lesson 032, lesson 033

Count missing entries and locate the delivery rows you need to review.

## ▶️ Run it

From the extracted lesson folder, run the two commands below. You only need to install its packages once.

```bash
python -m pip install -r requirements.txt
python lesson.py
```

## ✅ Expected result

Look for `Column  Missing cells` in the output excerpt below. Match it to the supplied CSV before changing any values.

```text
Column  Missing cells
distance_km              0
weight_kg              1
```

[See the full example output](expected-output.txt).

If the result differs on your first run, restore the original CSVs, run from the extracted lesson folder, and read the first error message if Python stops.

## 🧪 Try one change

Try changing distance_km from 2 to 6 in sample.csv. Compare the new output.

[Open the Python script](lesson.py) · [Open sample.csv](sample.csv)

## What the code does

1. Read the delivery table. Distance is in km, and weight is in kg.
2. Find blanks in the rows you are about to use.

## 📋 Sample data

| distance_km | weight_kg | zone | delivery_minutes |
| --- | --- | --- | --- |
| 2 | 1 | north | 19 |
| 4 | — | north | 30 |
| 6 | 2 | — | 29 |
| 8 | 4 | south | 40 |
| 10 | 1 | ? | 33 |
| 12 | 3 | south | 44 |

## 📊 Read the visual

![Find the gap. The weight is blank. The measured delivery time is present. → Learn a fill rule. Use a rule based on the training weights, such as their median. → Reuse the rule. Fill a blank on a new request using that saved rule.](missing-values-steps.png)

**👀 Read the visual.** This example follows one completed delivery whose weight is missing.

**👉 What to do.** If the **actual delivery time** is missing, hold that row out of supervised training. You can still ask the model to estimate its time.
