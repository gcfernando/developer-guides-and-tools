# 1.3.2 Remove Duplicates

**Practice** · Shared code with lesson 050

Check whether repeated order records would give some deliveries extra weight in training.

## ▶️ Run it

From the extracted lesson folder, run the two commands below. You only need to install its packages once.

```bash
python -m pip install -r requirements.txt
python lesson.py
```

## ✅ Expected result

Look for `Repeated rows: 1` in the output excerpt below. Match it to the supplied CSV before changing any values.

```text
Repeated rows: 1
D prediction: [30.0]
km  prediction
```

[See the full example output](expected-output.txt).

If the result differs on your first run, restore the original CSVs, run from the extracted lesson folder, and read the first error message if Python stops.

## 🧪 Try one change

Edit the input values in new_inputs.csv and compare the displayed predictions.

[Open the Python script](lesson.py) · [Open sample.csv](sample.csv) · [Open new_inputs.csv](new_inputs.csv)

## What the code does

1. Read the CSV and check its inputs, including order_id, km, minutes.
2. Print the result next to the input values so you can compare them.
3. Apply the confirmed correction before teaching the model.
4. Set aside the check rows before the model learns.
5. Teach the model from the training inputs and delivery time in minutes.
6. Apply the fitted model to the new CSV rows and print a result for each row.

## 📋 Sample data

| order_id | km | minutes |
| --- | --- | --- |
| A | 2 | 14 |
| A | 2 | 14 |
| B | 5 | 20 |
| C | 8 | 26 |
| D | 10 | 30 |

## 📩 Supplied new inputs

| km |
| --- |
| 4 |
| 9 |
| 13 |

## 📊 Read the visual

![Compare fields. Look at order ID, name and the measured time. → Confirm identity. Matching IDs and values may be two copies of the same order. → Review conflicts. Different orders can share a name. Use the source to confirm.](duplicate-check-steps.png)

**👀 Read the visual.** Two customer names can look nearly identical while their orders differ.

**👉 What to do.** **Keep both rows** if the source confirms they are separate orders.
