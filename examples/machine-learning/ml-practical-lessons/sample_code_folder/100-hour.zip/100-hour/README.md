# Hour

**Practice**

Get the hour of the day so the model can use time of day.

## ▶️ Run it

From the extracted lesson folder, run the two commands below. You only need to install its packages once.

```bash
python -m pip install -r requirements.txt
python lesson.py
```

## ✅ Expected result

Look for `Year  Month  Day  Weekday  Hour` in the output excerpt below. Match it to the supplied CSV before changing any values.

```text
Year  Month  Day  Weekday  Hour
2025      2    3        0     8
2025      2    3        0    10
```

[See the full example output](expected-output.txt).

If the result differs on your first run, restore the original CSVs, run from the extracted lesson folder, and read the first error message if Python stops.

## 🧪 Try one change

Try 2025-02-05 09:00 and 2026-01-12 08:30 in new_inputs.csv. Keep the YYYY-MM-DD HH:MM format.

[Open the Python script](lesson.py) · [Open sample.csv](sample.csv) · [Open new_inputs.csv](new_inputs.csv)

## What the code does

1. Read the timestamp and recorded order count for each row.
2. Read each timestamp once and pull out the parts the model can use.
3. Teach the model from the training inputs and the recorded order count.
4. Apply the fitted model to the new CSV rows and print a result for each row.

## 📋 Sample data

| timestamp | orders |
| --- | --- |
| 2025-02-03 08:00 | 10 |
| 2025-02-03 10:00 | 14 |
| 2025-02-04 08:00 | 13 |
| 2025-02-04 10:00 | 17 |

## 📩 Supplied new inputs

| timestamp |
| --- |
| 2025-02-05 09:00 |
| 2025-03-08 17:30 |
| 2026-01-12 08:30 |
