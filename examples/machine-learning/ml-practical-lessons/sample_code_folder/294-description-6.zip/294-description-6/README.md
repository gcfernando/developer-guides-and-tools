# Description

**Reference** · Shared code with lesson 301

Inspect the columns in the invented wine measurements and see what each row represents.

## ▶️ Run it

From the extracted lesson folder, run the two commands below. You only need to install its packages once.

```bash
python -m pip install -r requirements.txt
python lesson.py
```

## ✅ Expected result

Look for `PDF reference: UCI Wine Quality Dataset` in the output excerpt below. Match it to the supplied CSV before changing any values.

```text
PDF reference: UCI Wine Quality Dataset
Origin of this CSV: original synthetic practice rows
Rows: 8
```

[See the full example output](expected-output.txt).

If the result differs on your first run, restore the original CSVs, run from the extracted lesson folder, and read the first error message if Python stops.

## 🧪 Try one change

Add another original example in sample.csv. Rerun to check that its columns and row count make sense.

[Open the Python script](lesson.py) · [Open sample.csv](sample.csv)

## What the code does

1. Read the example records from sample.csv. The table uses the dataset fields shown below.
2. Print the result next to the input values so you can compare them.

## 📋 Sample data

| alcohol | citric_acid | sulphates | quality |
| --- | --- | --- | --- |
| 8 | .2 | .3 | 4 |
| 9 | .2 | .4 | 5 |
| 10 | .3 | — | 5 |
| 11 | .3 | .6 | 6 |
| 12 | .4 | .7 | 7 |
| 16 | .3 | 1.1 | 8 |
| 9.5 | .2 | .4 | 5 |
| 12.1 | .4 | .7 | 7 |
