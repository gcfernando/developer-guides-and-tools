# K-Means Classifier

**Practice**

Find clusters first, then use known labels to name each cluster.

## ▶️ Run it

From the extracted lesson folder, run the two commands below. You only need to install its packages once.

```bash
python -m pip install -r requirements.txt
python lesson.py
```

## ✅ Expected result

Look for `Cluster IDs: [0, 1, 0]` in the output excerpt below. Match it to the supplied CSV before changing any values.

```text
Cluster IDs: [0, 1, 0]
Mapped class predictions: ['local', 'long', 'local']
```

[See the full example output](expected-output.txt).

If the result differs on your first run, restore the original CSVs, run from the extracted lesson folder, and read the first error message if Python stops.

## 🧪 Try one change

Try changing x from 1.5 to 4 in new_inputs.csv. Compare the new output.

[Open the Python script](lesson.py) · [Open sample.csv](sample.csv) · [Open new_inputs.csv](new_inputs.csv)

## What the code does

1. Read the CSV and check its inputs, including x, y, label.
2. Match each cluster to the most common known label among its training rows.
3. Apply the fitted model to the new CSV rows and print a result for each row.

## 📋 Sample data

| x | y | label |
| --- | --- | --- |
| 1 | 1 | local |
| 2 | 1 | local |
| 1 | 2 | local |
| 8 | 8 | long |
| 9 | 8 | long |
| 8 | 9 | long |

## 📩 Supplied new inputs

| x | y |
| --- | --- |
| 1.5 | 2 |
| 9 | 9 |
| 4 | 5 |
