# Check whether predicted probabilities are reliable

**Practice** · Same labeled order CSV. Different decisions and scripts.

Fit a calibration model using validation rows and compare probability quality on a separate test set.

## ▶️ Run it

Extract this ZIP and open a terminal in the lesson folder.

```bash
python -m pip install -r requirements.txt
python lesson.py
```

## ✅ Expected result

The two Brier scores are close. In this test the raw forest scores 0.1081 and the adjusted forest 0.1083. Use the chart to see where the probability estimates differ.

```text
Raw forest test Brier score: 0.1081
Adjusted forest test Brier score: 0.1083
Lower Brier score is better on this probability check. Changing bins changes the visual, not the score.
```

[Full run output](expected-output.txt) · [Python script](lesson.py) · [Sample CSV](sample.csv) · [Inputs to change](new_inputs.csv)

## 🧪 Try a change

Change bins from 5 to 10. Compare the chart’s grouping. The Brier scores should stay the same.

Open **calibration.png** after running the script.

Adjustment can help some test groups and hurt others. Compare on data that the original classifier and the adjustment have never seen. [Calibration guide](https://scikit-learn.org/stable/modules/calibration.html)
