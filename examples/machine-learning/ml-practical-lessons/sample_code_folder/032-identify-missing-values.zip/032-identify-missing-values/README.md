# Identify missing values

**Core** · Shared code with lesson 030, lesson 031, lesson 033

Find which weights or delivery zones are missing and read the affected rows.

## ▶️ Run it

From the extracted lesson folder, run the two commands below. You only need to install its packages once.

```bash
python -m pip install -r requirements.txt
python lesson.py
```

## ✅ Expected result

Find **one blank weight** and **two missing zones**, then see the affected rows.

```text
Column  Missing cells
distance_km              0
weight_kg              1
```

[See the full example output](expected-output.txt).

If the result differs on your first run, restore the original CSVs, run from the extracted lesson folder, and read the first error message if Python stops.

## 🧪 Try one change

Fill the blank weight with 2 in sample.csv. The missing weight count should fall by one.

[Open the Python script](lesson.py) · [Open sample.csv](sample.csv)

## What the code does

1. Read the CSV. Treat a question mark like a blank cell.
2. Count missing values by column. Then print the rows you need to review.

## 📋 Sample data

| distance_km | weight_kg | zone | delivery_minutes |
| --- | --- | --- | --- |
| 2 | 1 | north | 19 |
| 4 | — | north | 30 |
| 6 | 2 | — | 29 |
| 8 | 4 | south | 40 |
| 10 | 1 | ? | 33 |
| 12 | 3 | south | 44 |
