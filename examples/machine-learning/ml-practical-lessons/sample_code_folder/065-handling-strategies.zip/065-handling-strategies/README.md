# Handling Strategies

**Practice** · Shared code with lesson 066, lesson 067, lesson 068

Compare deleting a confirmed error, clipping a value and applying a log.

## ▶️ Run it

From the extracted lesson folder, run the two commands below. You only need to install its packages once.

```bash
python -m pip install -r requirements.txt
python lesson.py
```

## ✅ Expected result

Look for `Confirmed errors removed: 1` in the output excerpt below. Match it to the supplied CSV before changing any values.

```text
Confirmed errors removed: 1
remove only
weight_used_by_model  original_weight_kg  predicted_minutes  actual_minutes
```

[See the full example output](expected-output.txt).

If the result differs on your first run, restore the original CSVs, run from the extracted lesson folder, and read the first error message if Python stops.

## 🧪 Try one change

Try changing weight_kg from 1 to 2 in sample.csv. Compare the new output.

[Open the Python script](lesson.py) · [Open sample.csv](sample.csv)

## What the code does

1. Read the weights in kilograms and the delivery times in minutes.
2. Set aside the check rows before the model learns.
3. Give each method the same practice data so you can compare the results.

## 📋 Sample data

| weight_kg | minutes |
| --- | --- |
| 1 | 18 |
| -45 | 18 |
| 2 | 21 |
| 3 | 23 |
| 5 | 28 |
| 40 | 72 |
| 7 | 32 |
