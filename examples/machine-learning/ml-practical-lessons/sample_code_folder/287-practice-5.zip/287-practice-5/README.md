# Practice

**Practice** · Shared code family (see lesson 285 for the same script)

Use age, education and working hours from invented income records to estimate income group.

## ▶️ Run it

From the extracted lesson folder, run the two commands below. You only need to install its packages once.

```bash
python -m pip install -r requirements.txt
python lesson.py
```

## ✅ Expected result

Look for `Missing cells before filling or removing rows: {'age': 0, 'hours': 0, 'education': 0, 'workclass': 1, …` in the output excerpt below. Match it to the supplied CSV before changing any values.

```text
Missing cells before filling or removing rows: {'age': 0, 'hours': 0, 'education': 0, 'workclass': 1, 'occupation': 1, 'marital_status': 0, 'income_group': 0}
Field  Rows to review
age               0
```

[See the full example output](expected-output.txt).

If the result differs on your first run, restore the original CSVs, run from the extracted lesson folder, and read the first error message if Python stops.

## 🧪 Try one change

Change an input in new_inputs.csv. Compare the predictions with the held-out check above.

[Open the Python script](lesson.py) · [Open sample.csv](sample.csv) · [Open new_inputs.csv](new_inputs.csv)

## What the code does

1. Read the example records from sample.csv. The table uses the dataset fields shown below.
2. Set aside the check rows before the model learns.
3. Find blanks in the rows you are about to use.
4. Find where the middle values sit, then compare the remaining rows with those limits.
5. Fit the model on the prepared training rows. Keep it for the checks below.
6. Apply the fitted model to the new CSV rows and print a result for each row.

## 📋 Sample data

| age | hours | education | workclass | occupation | marital_status | income_group |
| --- | --- | --- | --- | --- | --- | --- |
| 22 | 25 | school | private | retail | single | 50k_or_less |
| 30 | 35 | degree | private | analyst | single | 50k_or_less |
| 36 | 45 | degree | public | manager | married | above_50k |
| 49 | 47 | graduate | private | — | married | above_50k |
| 47 | 50 | degree | — | engineer | married | above_50k |
| 73 | 17 | school | private | retail | single | 50k_or_less |
| 28 | 28 | school | public | — | single | 50k_or_less |
| 38 | 45 | degree | public | engineer | married | above_50k |

## 📩 Supplied new inputs

| age | hours | education | workclass | occupation | marital_status |
| --- | --- | --- | --- | --- | --- |
| 22 | 25 | school | private | retail | single |
| 38 | 45 | degree | public | engineer | married |
| 36 | 45 | degree | public | manager | married |
