# Fixed range [0, 1]

**Practice** · Shared code with lesson 131, lesson 132

See how the smallest and largest training readings map to 0 and 1.

## ▶️ Run it

From the extracted lesson folder, run the two commands below. You only need to install its packages once.

```bash
python -m pip install -r requirements.txt
python lesson.py
```

## ✅ Expected result

Look for `Min-Max Scaling first two training rows: [[0.0], [0.03]]` in the output excerpt below. Match it to the supplied CSV before changing any values.

```text
Min-Max Scaling first two training rows: [[0.0], [0.03]]
Actual costs: [23, 48]
Predicted costs: [23.9, 37.7]
```

[See the full example output](expected-output.txt).

If the result differs on your first run, restore the original CSVs, run from the extracted lesson folder, and read the first error message if Python stops.

## 🧪 Try one change

Try a signal reading of 3, 15, or 40 in new_inputs.csv. Compare the predicted cost for each row.

[Open the Python script](lesson.py) · [Open sample.csv](sample.csv) · [Open new_inputs.csv](new_inputs.csv)

## What the code does

1. Read the sensor readings and their measured costs.
2. Set aside the check rows before the model learns.
3. Teach the model from the training inputs and the recorded cost.
4. Apply the fitted model to the new CSV rows and print a result for each row.

## 📋 Sample data

| signal | cost |
| --- | --- |
| 1 | 10 |
| 5 | 18 |
| 12 | 25 |
| 20 | 31 |
| 35 | 41 |
| 80 | 53 |
| 160 | 64 |
| 10 | 23 |

Showing the first 8 of 9 rows. The CSV has the full sample.

## 📩 Supplied new inputs

| signal |
| --- |
| 3 |
| 15 |
| 40 |
