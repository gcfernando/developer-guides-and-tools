# Log1p and base-10 log

**Practice**

Compare what happens when you apply log1p to a reading and when you use a base-10 log.

## ▶️ Run it

From the extracted lesson folder, run the two commands below. You only need to install its packages once.

```bash
python -m pip install -r requirements.txt
python lesson.py
```

## ✅ Expected result

Look for `signal  log1p  log10` in the output excerpt below. Match it to the supplied CSV before changing any values.

```text
signal  log1p  log10
1  0.693  0.000
5  1.792  0.699
```

[See the full example output](expected-output.txt).

If the result differs on your first run, restore the original CSVs, run from the extracted lesson folder, and read the first error message if Python stops.

## 🧪 Try one change

Try a reading of 3, 15, or 40 in new_inputs.csv. Read the log1p and base-10 comparison for the positive training readings.

[Open the Python script](lesson.py) · [Open sample.csv](sample.csv) · [Open new_inputs.csv](new_inputs.csv)

## What the code does

1. Read the sensor readings and their measured costs.
2. Set aside the check rows before the model learns.
3. Teach the model from the training inputs and the recorded cost.
4. Apply the fitted model to the new CSV rows and print a result for each row.

## 📋 Sample data

| signal | cost |
| --- | --- |
| 1 | 10 |
| 5 | 18 |
| 12 | 25 |
| 20 | 31 |
| 35 | 41 |
| 80 | 53 |
| 160 | 64 |
| 10 | 23 |

Showing the first 8 of 9 rows. The CSV has the full sample.

## 📩 Supplied new inputs

| signal |
| --- |
| 3 |
| 15 |
| 40 |
