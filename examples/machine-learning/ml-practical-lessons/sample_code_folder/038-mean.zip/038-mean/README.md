# Mean

**Practice**

Fill an empty weight with the average of the measured training weights.

## ▶️ Run it

From the extracted lesson folder, run the two commands below. You only need to install its packages once.

```bash
python -m pip install -r requirements.txt
python lesson.py
```

## ✅ Expected result

Use the first new delivery to check Mean. Compare its filled weight and predicted minutes with the values shown below.

```text
distance_km  weight_kg  filled_weight_kg  predicted_minutes  actual_minutes
10          —          2.333333              33.59            33.0
6        2.0          2.000000              28.56            29.0
```

[See the full example output](expected-output.txt).

If the result differs on your first run, restore the original CSVs, run from the extracted lesson folder, and read the first error message if Python stops.

## 🧪 Try one change

Try changing distance_km from 10 to 14 in new_inputs.csv. Compare the new output.

[Open the Python script](lesson.py) · [Open sample.csv](sample.csv) · [Open new_inputs.csv](new_inputs.csv)

## What the code does

1. Read the delivery table. Distance is in km, and weight is in kg.
2. Set aside the check rows before the model learns.
3. Apply the conversion learned from training to each new row.
4. Teach the model from the training inputs and delivery time in minutes.

## 📋 Sample data

| distance_km | weight_kg | zone | delivery_minutes |
| --- | --- | --- | --- |
| 2 | 1 | north | 19 |
| 4 | — | north | 30 |
| 6 | 2 | — | 29 |
| 8 | 4 | south | 40 |
| 10 | 1 | ? | 33 |
| 12 | 3 | south | 44 |

## 📩 Supplied new inputs

| distance_km | weight_kg | actual_minutes |
| --- | --- | --- |
| 10 | — | 33 |
| 6 | 2 | 29 |
| 14 | — | — |
