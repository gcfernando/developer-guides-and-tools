"""
Mean

Fill an empty weight with the average of the measured training weights.

Run: python lesson.py
Try changing distance_km from 10 to 14 in new_inputs.csv. Compare the new output.
"""

from pathlib import Path
import pandas as pd
from sklearn.impute import SimpleImputer
from sklearn.linear_model import LinearRegression

input_path = Path(__file__).resolve().with_name("sample.csv")
new_path = Path(__file__).resolve().with_name("new_inputs.csv")


# 1. Read the delivery table. Distance is in km, and weight is in kg.
data = pd.read_csv(input_path, na_values=["?"])


# 2. Set aside the check rows before the model learns.
training = data.iloc[:4]
inputs = ["distance_km", "weight_kg"]
# 3. Apply the conversion learned from training to each new row.
new_parcel = pd.read_csv(new_path).loc[:, inputs]
# Keep any measured time for the comparison table.
actual_minutes = pd.read_csv(new_path)["actual_minutes"].to_numpy()


# Learn the mean weight from the training rows.
imputer = SimpleImputer(strategy="mean")
# Learn the needed values here. New rows use transform with these saved values.
filled_training = imputer.fit_transform(training[inputs])

# Fit a delivery model with the completed training rows.
# 4. Teach the model from the training inputs and delivery time in minutes.
model = LinearRegression().fit(filled_training, training["delivery_minutes"])

# Fill missing weights in the new rows the same way.
filled_parcels = imputer.transform(new_parcel)
results = new_parcel.copy()
# Column 0 is first. Column 1 is the second column.
results["filled_weight_kg"] = filled_parcels[:, 1]
results["predicted_minutes"] = model.predict(filled_parcels).round(2)
results["actual_minutes"] = actual_minutes
print(results.to_string(index=False, na_rep="—"))
