# Handle missing values

**Practice** · Shared code with lesson 035

Decide which incomplete delivery rows you can still use to train a model.

## ▶️ Run it

From the extracted lesson folder, run the two commands below. You only need to install its packages once.

```bash
python -m pip install -r requirements.txt
python lesson.py
```

## ✅ Expected result

Look for `Rows retained: 4` in the output excerpt below. Match it to the supplied CSV before changing any values.

```text
Rows retained: 4
Held-out prediction: [35.0]
[25. 41.]
```

[See the full example output](expected-output.txt).

If the result differs on your first run, restore the original CSVs, run from the extracted lesson folder, and read the first error message if Python stops.

## 🧪 Try one change

Try another distance in new_inputs.csv.

[Open the Python script](lesson.py) · [Open sample.csv](sample.csv) · [Open new_inputs.csv](new_inputs.csv)

## What the code does

1. Read the CSV and check its inputs, including distance_km, note, minutes.
2. Keep rows with both a usable input and a known answer.
3. Set aside the check rows before the model learns.
4. Teach the model from the training inputs and delivery time in minutes.
5. Apply the fitted model to the new CSV rows and print a result for each row.

## 📋 Sample data

| distance_km | note | minutes |
| --- | --- | --- |
| 2 | — | 19 |
| 4 | left at desk | 23 |
| — | — | 27 |
| 8 | — | 31 |
| 10 | — | 35 |

## 📩 Supplied new inputs

| distance_km |
| --- |
| 5 |
| 13 |
