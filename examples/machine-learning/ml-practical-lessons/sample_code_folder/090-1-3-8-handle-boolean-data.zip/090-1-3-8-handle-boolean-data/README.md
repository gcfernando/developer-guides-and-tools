# 1.3.8 Handle Boolean Data

**Practice** · Shared code with lesson 091

Make mixed yes/no entries consistent before a model uses them.

## ▶️ Run it

From the extracted lesson folder, run the two commands below. You only need to install its packages once.

```bash
python -m pip install -r requirements.txt
python lesson.py
```

## ✅ Expected result

Look for `signed_up  flag` in the output excerpt below. Match it to the supplied CSV before changing any values.

```text
signed_up  flag
Yes   1.0
no   0.0
```

[See the full example output](expected-output.txt).

If the result differs on your first run, restore the original CSVs, run from the extracted lesson folder, and read the first error message if Python stops.

## 🧪 Try one change

Change signed_up in sample.csv, for example from Yes to true. Compare the printed rows.

[Open the Python script](lesson.py) · [Open sample.csv](sample.csv)

## What the code does

1. Read the CSV and check its inputs, including signed_up.
2. Give different spellings of the same value one consistent form.

## 📋 Sample data

| signed_up |
| --- |
| Yes |
| no |
| true |
| 0 |
| unknown |

## 📊 Read the visual

![Recognize yes. Yes, true or 1 means the value is 1. → Recognize no. No, false or 0 means the value is 0. → Handle unknown. Keep unfamiliar entries missing until the fill rule runs.](boolean-input-steps.png)

**👀 Read the visual.** Handle each entry based on its meaning.

**👉 What to do.** A false value is a known **0**. Leave an unknown entry missing until a rule handles it.
