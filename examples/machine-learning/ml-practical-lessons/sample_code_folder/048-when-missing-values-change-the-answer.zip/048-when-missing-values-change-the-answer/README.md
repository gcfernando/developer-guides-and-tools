# When missing values change the answer

**Practice**

See how losing the slower trips can make the average delivery time look too low.

## ▶️ Run it

From the extracted lesson folder, run the two commands below. You only need to install its packages once.

```bash
python -m pip install -r requirements.txt
python lesson.py
```

## ✅ Expected result

Look for `Average uses  Average time (min)` in the output excerpt below. Match it to the supplied CSV before changing any values.

```text
Average uses  Average time (min)
All six times                23.0
Recorded times only                18.0
```

[See the full example output](expected-output.txt).

If the result differs on your first run, restore the original CSVs, run from the extracted lesson folder, and read the first error message if Python stops.

## 🧪 Try one change

Try changing True time from 12 to 16 in sample.csv. Compare the new output.

[Open the Python script](lesson.py) · [Open sample.csv](sample.csv)

## What the code does

1. Read the CSV and check its inputs, including Route, True time, Recorded time.
2. Print the result next to the input values so you can compare them.
3. Plot the values so you can see how they compare.

## 📋 Sample data

| Route | True time | Recorded time |
| --- | --- | --- |
| Short | 12 | 12.0 |
| Short | 14 | 14.0 |
| Short | 16 | 16.0 |
| Long | 30 | 30.0 |
| Long | 32 | — |
| Long | 34 | — |
