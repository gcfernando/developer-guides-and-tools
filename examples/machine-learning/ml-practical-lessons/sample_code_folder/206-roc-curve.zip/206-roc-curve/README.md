# ROC Curve

**Practice**

Compare catches and false alarms at two fixed practice cutoffs.

## ▶️ Run it

Extract this ZIP and open a terminal in the lesson folder.

```bash
python -m pip install -r requirements.txt
python lesson.py
```

## ✅ Expected result

At 0.25 the model catches 18 urgent orders and raises two false alarms. At 0.75 it catches 17 and raises one false alarm.

```text
Cutoff  Urgent caught  Urgent missed  False alarms  Urgent recall  False alarm rate
   0.25             18              0             2          1.000             0.167
   0.75             17              1             1          0.944             0.083
AUC-ROC: 0.991
Here the test cutoffs are fixed for teaching. Choose an app cutoff on validation data.
```

[Full run output](expected-output.txt) · [Python script](lesson.py) · [Sample CSV](sample.csv) · [Inputs to change](new_inputs.csv)

## 🧪 Try a change

Replace 0.75 with 0.5. Compare detections and false alarms with the first row. These are practice cutoffs on the test set.

Open **roc-cutoffs.png** after running the script.
