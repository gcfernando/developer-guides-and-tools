# t-Distributed Stochastic Neighbor Embedding (t-SNE)

**Practice**

Draw similar rows near one another in a two-dimensional plot.

## ▶️ Run it

From the extracted lesson folder, run the two commands below. You only need to install its packages once.

```bash
python -m pip install -r requirements.txt
python lesson.py
```

## ✅ Expected result

Look for `Output shape: (8, 2)` in the output excerpt below. Match it to the supplied CSV before changing any values.

```text
Output shape: (8, 2)
First two rows: [[-0.47999998927116394, 21.760000228881836], [-2.5999999046325684, 13.529999732971191]]
```

[See the full example output](expected-output.txt).

If the result differs on your first run, restore the original CSVs, run from the extracted lesson folder, and read the first error message if Python stops.

## 🧪 Try one change

Add or edit a row in sample.csv, then rerun to refit. This method works on the whole group of rows.

[Open the Python script](lesson.py) · [Open sample.csv](sample.csv)

## What the code does

1. Read the CSV and check its inputs, including long, wide, score.
2. Learn the conversion on the training inputs before applying it to a new row.
3. Plot the values so you can see how they compare.

## 📋 Sample data

| long | wide | score | group |
| --- | --- | --- | --- |
| 2 | 1 | 3 | 0 |
| 3 | 2 | 4 | 0 |
| 4 | 1 | 2 | 0 |
| 5 | 6 | 7 | 1 |
| 6 | 7 | 8 | 1 |
| 7 | 6 | 9 | 1 |
| 8 | 8 | 7 | 1 |
| 10 | 9 | 10 | 1 |

When you edit the CSV, this lesson recomputes the result for the whole table. It does not project a separate unseen row with an existing fitted estimator.
