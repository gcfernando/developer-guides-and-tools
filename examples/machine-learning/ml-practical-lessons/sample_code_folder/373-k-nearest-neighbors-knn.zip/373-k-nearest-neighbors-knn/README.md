# K-Nearest Neighbors (KNN)

**Practice**

Look at nearby deliveries with known answers to predict late or on time.

## ▶️ Run it

From the extracted lesson folder, run the two commands below. You only need to install its packages once.

```bash
python -m pip install -r requirements.txt
python lesson.py
```

## ✅ Expected result

Check the accuracy on the test deliveries. The model matches 15 of the 15 test labels in this sample.

```text
Accuracy: 1.0
```

[See the full example output](expected-output.txt).

If the result differs on your first run, restore the original CSVs and run the script again.

## 🧪 Try one change

Change km or kg in new_inputs.csv. The model is trained on sample.csv. The new rows only receive predictions.

[Open the Python script](lesson.py) · [Open sample.csv](sample.csv) · [Open new_inputs.csv](new_inputs.csv)

## What the code does

1. Read the practice deliveries. Use km for distance and kg for parcel weight.
2. Set the test rows aside. Drop any training rows with the same distance and weight as a test row.
3. Teach the model from the training inputs and whether the delivery was late.
4. Apply the fitted model to the new CSV rows and print a result for each row.

## 📋 Sample data

| km | kg | late |
| --- | --- | --- |
| 48 | 4 | 1 |
| 32 | 6 | 1 |
| 35 | 5 | 1 |
| 45 | 3 | 1 |
| 29 | 12 | 1 |
| 39 | 1 | 1 |
| 42 | 2 | 1 |
| 12 | 3 | 0 |

Showing the first 8 of 60 rows. The CSV has the full sample.

## 📩 Supplied new inputs

| km | kg |
| --- | --- |
| 5 | 2 |
| 16 | 4 |
| 42 | 9 |
