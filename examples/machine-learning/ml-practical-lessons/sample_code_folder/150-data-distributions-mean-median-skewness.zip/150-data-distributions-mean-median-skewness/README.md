# Data distributions (mean, median, skewness)

**Practice** · Shared code family (see lesson 148 for the same script)

Compare the mean, middle and skew of delivery measurements.

## ▶️ Run it

From the extracted lesson folder, run the two commands below. You only need to install its packages once.

```bash
python -m pip install -r requirements.txt
python lesson.py
```

## ✅ Expected result

Look for `distance  route_distance  weight  minutes` in the output excerpt below. Match it to the supplied CSV before changing any values.

```text
distance  route_distance  weight  minutes
mean         7.0             7.7    4.33    35.33
median       7.0             7.7    2.50    31.50
```

[See the full example output](expected-output.txt).

If the result differs on your first run, restore the original CSVs, run from the extracted lesson folder, and read the first error message if Python stops.

## 🧪 Try one change

Try changing distance from 2 to 6 in sample.csv. Compare the new output.

[Open the Python script](lesson.py) · [Open sample.csv](sample.csv)

## What the code does

1. Read the CSV and check its inputs, including distance, route_distance, weight.
2. Print the result next to the input values so you can compare them.
3. Plot the values so you can see how they compare.

## 📋 Sample data

| distance | route_distance | weight | minutes |
| --- | --- | --- | --- |
| 2 | 2.2 | 1 | 19 |
| 4 | 4.4 | 3 | 30 |
| 6 | 6.6 | 2 | 29 |
| 8 | 8.8 | 4 | 40 |
| 10 | 11 | 1 | 33 |
| 12 | 13.2 | 15 | 61 |
