# RMSE, MAE, R² score

**Practice** · Shared code with lesson 208, lesson 210

Compare average error, large misses and fit relative to a baseline. Worked calculation using two test trips.

## ▶️ Run it

Extract this ZIP and open a terminal in the lesson folder.

```bash
python -m pip install -r requirements.txt
python lesson.py
```

## ✅ Expected result

The two test trips have MAE and RMSE of 2.0 minutes and R² near 0.868. Use lesson 446 for a larger test.

```text
Worked calculation: two test deliveries. Use lesson 446 for a larger evaluation.
RMSE: 2.0
MAE: 2.0
R²: 0.868
 distance_km  weight_kg  prediction
           5          2        27.5
          13          3        43.5
          20          7        70.0
```

[Full run output](expected-output.txt) · [Python script](lesson.py) · [Sample CSV](sample.csv) · [Inputs to change](new_inputs.csv)

## 🧪 Try a change

Change a completed delivery time and compare MAE, RMSE and R².
