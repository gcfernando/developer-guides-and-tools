# Numerical Data: Mean, Median, Mode, KNN Imputer

**Practice** · Shared code with lesson 036

Compare four ways of filling the same missing weight and see how each changes the prediction.

## ▶️ Run it

From the extracted lesson folder, run the two commands below. You only need to install its packages once.

```bash
python -m pip install -r requirements.txt
python lesson.py
```

## ✅ Expected result

Look for `New row               Method  Filled kg  Prediction in minutes  Actual minutes` in the output excerpt below. Match it to the supplied CSV before changing any values.

```text
New row               Method  Filled kg  Prediction in minutes  Actual minutes
1                 Mean       2.33                  33.59            33.0
2                 Mean       2.00                  28.56            29.0
```

[See the full example output](expected-output.txt).

If the result differs on your first run, restore the original CSVs, run from the extracted lesson folder, and read the first error message if Python stops.

## 🧪 Try one change

Leave weight_kg blank for a new distance and compare what each method fills in.

[Open the Python script](lesson.py) · [Open sample.csv](sample.csv) · [Open new_inputs.csv](new_inputs.csv)

## What the code does

1. Read the delivery table. Distance is in km, and weight is in kg.
2. Set aside the check rows before the model learns.
3. Read the new CSV rows, then apply the rules from the sample.
4. Give each method the same practice data so you can compare the results.
5. Learn the conversion on the training inputs before applying it to a new row.

## 📋 Sample data

| distance_km | weight_kg | zone | delivery_minutes |
| --- | --- | --- | --- |
| 2 | 1 | north | 19 |
| 4 | — | north | 30 |
| 6 | 2 | — | 29 |
| 8 | 4 | south | 40 |
| 10 | 1 | ? | 33 |
| 12 | 3 | south | 44 |

## 📩 Supplied new inputs

| distance_km | weight_kg | actual_minutes |
| --- | --- | --- |
| 10 | — | 33 |
| 6 | 2 | 29 |
| 14 | — | — |
