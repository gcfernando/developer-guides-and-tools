# Handle data privacy & security concerns

**Practice** · Shared code family (see lesson 016 for the same script)

Export a delivery table with order IDs and times while keeping contact details out of the shared file.

## ▶️ Run it

From the extracted lesson folder, run the two commands below. You only need to install its packages once.

```bash
python -m pip install -r requirements.txt
python lesson.py
```

## ✅ Expected result

Look for `{'source': 'original sample', 'method': 'created in Python', 'bytes': 27, 'types': {'order_id': 'int64', …` in the output excerpt below. Match it to the supplied CSV before changing any values.

```text
{'source': 'original sample', 'method': 'created in Python', 'bytes': 27, 'types': {'order_id': 'int64', 'minutes': 'int64'}}
file_type  collected
text       True
```

[See the full example output](expected-output.txt).

If the result differs on your first run, restore the original CSVs, run from the extracted lesson folder, and read the first error message if Python stops.

## 🧪 Try one change

Try changing order_id from 1 to 2 in sample.csv. Compare the new output.

[Open the Python script](lesson.py) · [Open sample.csv](sample.csv)

## What the code does

1. Read the CSV and check its inputs, including order_id, minutes, contact.
2. Print the result next to the input values so you can compare them.

## 📋 Sample data

| order_id | minutes | contact |
| --- | --- | --- |
| 1 | 22 | sample1@example.invalid |
| 2 | 31 | sample2@example.invalid |
