# REST API

**Practice** · Shared code family (see lesson 215 for the same script)

Try the same delivery API with several JSON inputs.

## ▶️ Run it

From the extracted lesson folder, run the two commands below. You only need to install its packages once.

```bash
python -m pip install -r requirements.txt
python lesson.py
```

## ✅ Expected result

Look for `200 {'minutes': 27.8}` in the output excerpt below. Match it to the supplied CSV before changing any values.

```text
200 {'minutes': 27.8}
Invalid distance: 422
{'distance_km': 5, 'weight_kg': 2} 200 {'minutes': 27.8}
```

[See the full example output](expected-output.txt).

If the result differs on your first run, restore the original CSVs, run from the extracted lesson folder, and read the first error message if Python stops.

## 🧪 Try one change

Try changing distance_km from 5 to -2 in new_inputs.csv. Compare the new output.

[Open the Python script](lesson.py) · [Open sample.csv](sample.csv) · [Open new_inputs.csv](new_inputs.csv)

## What the code does

1. Read the delivery table. Distance is in km, and weight is in kg.
2. Send a practice request and read the response code and body.
3. Send each new CSV row to the app and read the response.

## 📋 Sample data

| distance_km | weight_kg | delivery_minutes |
| --- | --- | --- |
| 2 | 1 | 19 |
| 4 | 3 | 30 |
| 6 | 2 | 29 |
| 8 | 4 | 40 |
| 10 | 1 | 33 |
| 12 | 3 | 44 |

## 📩 Supplied new inputs

| distance_km | weight_kg |
| --- | --- |
| 5 | 2 |
| 20 | 4 |
| -2 | 3 |
