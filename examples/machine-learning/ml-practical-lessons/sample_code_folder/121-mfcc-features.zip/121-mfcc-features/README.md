# MFCC features

**Practice** · Shared code with lesson 118, lesson 119, lesson 120

Turn short tones into MFCC features and use them to predict low or high pitch.

## ▶️ Run it

From the extracted lesson folder, run the two commands below. You only need to install its packages once.

```bash
python -m pip install -r requirements.txt
python lesson.py
```

## ✅ Expected result

Look for `One MFCC row: 8` in the output excerpt below. Match it to the supplied CSV before changing any values.

```text
One MFCC row: 8
New WAV sound: ['high']
Decoded MP3 sound: ['high']
```

[See the full example output](expected-output.txt).

If the result differs on your first run, restore the original CSVs, run from the extracted lesson folder, and read the first error message if Python stops.

## 🧪 Try one change

Change the frequency in new_inputs.csv to a value around 280 or 900. The script creates real WAV audio from those numbers and checks an MP3 round trip.

[Open the Python script](lesson.py) · [Open sample.csv](sample.csv) · [Open new_inputs.csv](new_inputs.csv)

## What the code does

1. Build a short sound from a frequency in the CSV.
2. Read the tone frequencies. Each row describes one sound to make.
3. Fit the model on the prepared training rows. Keep it for the checks below.
4. Apply the fitted model to the new CSV rows and print a result for each row.

## 📋 Sample data

| frequency_hz | label |
| --- | --- |
| 260 | low |
| 300 | low |
| 840 | high |
| 900 | high |

## 📩 Supplied new inputs

| frequency_hz |
| --- |
| 870 |
| 285 |
| 920 |
