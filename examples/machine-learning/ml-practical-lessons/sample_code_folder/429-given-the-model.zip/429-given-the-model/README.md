# Given the Model

**Practice**

Plan the best move using a transition table that is already available.

## ▶️ Run it

From the extracted lesson folder, run the two commands below. You only need to install its packages once.

```bash
python -m pip install -r requirements.txt
python lesson.py
```

## ✅ Expected result

Look for `given-the-model first-action values: [0.74, 0.8]` in the output excerpt below. Match it to the supplied CSV before changing any values.

```text
given-the-model first-action values: [0.74, 0.8]
Best action: 1
Start 0, planned values: [0.7403087499999998, 0.8003249999999998]
```

[See the full example output](expected-output.txt).

If the result differs on your first run, restore the original CSVs, run from the extracted lesson folder, and read the first error message if Python stops.

## 🧪 Try one change

Edit start in new_inputs.csv. The planner reads the supplied transition rules directly.

[Open the Python script](lesson.py) · [Open sample.csv](sample.csv) · [Open new_inputs.csv](new_inputs.csv)

## What the code does

1. Read the track rules. Each row describes one move and its reward.
2. Read what happens after this move from the track table.
3. Read the new CSV rows, then apply the rules from the sample.

## 📋 Sample data

| state | action | next_state | reward | done |
| --- | --- | --- | --- | --- |
| 0 | 0 | 0 | -0.02 | False |
| 0 | 1 | 1 | -0.02 | False |
| 1 | 0 | 0 | -0.02 | False |
| 1 | 1 | 2 | -0.02 | False |
| 2 | 0 | 1 | -0.02 | False |
| 2 | 1 | 3 | -0.02 | False |
| 3 | 0 | 2 | -0.02 | False |
| 3 | 1 | 4 | 1.0 | True |

## 📩 Supplied new inputs

| start |
| --- |
| 0 |
| 1 |
| 3 |
