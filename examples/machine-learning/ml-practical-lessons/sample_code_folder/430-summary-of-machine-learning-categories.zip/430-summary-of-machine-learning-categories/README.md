# Summary of Machine Learning Categories

**Practice**

Match a delivery problem to one of the four learning categories.

## ▶️ Run it

Extract this ZIP and open a terminal in the lesson folder.

```bash
python -m pip install -r requirements.txt
python lesson.py
```

## ✅ Expected result

Look under Worked examples for all four categories. Known answers map to Supervised and rewards map to Reinforcement.

```text
Worked examples
                                      problem      feedback learning_category
                        Predict delivery time known answers        Supervised
          Group routes by distance and weight    no answers      Unsupervised
             Tag the remaining delivery notes  some answers   Semi-supervised
Learn which corridor reaches the loading door       rewards     Reinforcement

Your examples
                                problem      feedback learning_category
                 Predict package weight known answers        Supervised
           Find unusual delivery routes    no answers      Unsupervised
Classify photos with a few known labels  some answers   Semi-supervised
      Learn parcel sorting with scoring       rewards     Reinforcement
```

[Full run output](expected-output.txt) · [Python script](lesson.py) · [Sample CSV](sample.csv) · [Inputs to change](new_inputs.csv)

## 🧪 Try a change

Change the first new example’s feedback to some answers. Its category should become Semi-supervised.
