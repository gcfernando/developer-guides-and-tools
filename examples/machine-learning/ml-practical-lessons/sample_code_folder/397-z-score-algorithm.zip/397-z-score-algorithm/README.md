# Z-score Algorithm

**Practice**

Check how many standard deviations a parcel weight lies from the training average.

## ▶️ Run it

From the extracted lesson folder, run the two commands below. You only need to install its packages once.

```bash
python -m pip install -r requirements.txt
python lesson.py
```

## ✅ Expected result

The 40 kg parcel exceeds a z-score magnitude of 3 and is flagged for review.

```text
Z-scores: [0.0, 24.49, 1.63]
Flagged: [False, True, False]
```

[Full searched result](expected-output.txt).

## 🧪 Try one change

Edit the rows in new_inputs.csv. Compare a typical case with an unusually heavy parcel. A flag means check the original record.

[Open the Python script](lesson.py) · [Open sample.csv](sample.csv) · [Open new_inputs.csv](new_inputs.csv)

## What the code does

1. Read the CSV and check its inputs, including weight_kg.
2. Read the new CSV rows, then apply the rules from the sample.
3. Measure each new weight in training standard deviations from the mean.

## 📋 Sample data

| weight_kg |
| --- |
| 9 |
| 8 |
| 10 |
| 11 |
| 11 |
| 10 |
| 9 |
| 12 |

## 📩 Supplied new inputs

| weight_kg |
| --- |
| 10 |
| 40 |
| 12 |
