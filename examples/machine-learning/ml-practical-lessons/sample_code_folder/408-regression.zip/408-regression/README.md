# Regression

**Practice**

Train a model with a few known numbers, then use its confident estimates to add practice rows.

## ▶️ Run it

From the extracted lesson folder, run the two commands below. You only need to install its packages once.

```bash
python -m pip install -r requirements.txt
python lesson.py
```

## ✅ Expected result

Look for `Added values: 5` in the output excerpt below. Match it to the supplied CSV before changing any values.

```text
Added values: 5
Holdout MAE, before / after: 0.47 0.57
Fresh estimates: [27.56, 60.9, 66.96]
```

[See the full example output](expected-output.txt).

If the result differs on your first run, restore the original CSVs, run from the extracted lesson folder, and read the first error message if Python stops.

## 🧪 Try one change

Change the input in new_inputs.csv. The model supplies an estimated numeric value.

[Open the Python script](lesson.py) · [Open sample.csv](sample.csv) · [Open new_inputs.csv](new_inputs.csv)

## What the code does

1. Read the CSV and check its inputs, including input, answer.
2. Set aside the check rows before the model learns.
3. Keep half the training answers and compare guesses from two regressors.
4. Fit the model on the prepared training rows. Keep it for the checks below.
5. Apply the fitted model to the new CSV rows and print a result for each row.

## 📋 Sample data

| input | answer |
| --- | --- |
| 1 | 19 |
| 2 | 23 |
| 3 | 24 |
| 4 | 28 |
| 5 | 31 |
| 6 | 36 |
| 7 | 35 |
| 8 | 40 |

Showing the first 8 of 14 rows. The CSV has the full sample.

## 📩 Supplied new inputs

| input |
| --- |
| 4 |
| 15 |
| 17 |
