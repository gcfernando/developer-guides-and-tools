# A dashboard that refreshes on your computer

**Practice** · Shared code with lesson 240, lesson 241

Run a local dashboard that reads the latest accuracy file.

## ▶️ Run it

From the extracted lesson folder, run the two commands below. You only need to install its packages once.

```bash
python -m pip install -r requirements.txt
python lesson.py
```

## ✅ Expected result

The last batch has 16 correct predictions out of 20. Read **80%**, an **85%** threshold, and **Alert visible: True**.

| Dashboard field | Value |
| --- | --- |
| Latest labeled accuracy | 80% |
| Alert threshold | 85% |
| Alert visible | True |

## 🧪 Try one change

Change Correct from 16 to 18 in the Afternoon row. Accuracy should rise to 90% and the alert should disappear.

[Open the Python script](lesson.py) · [Open sample.csv](sample.csv)

## What the code does

1. Read the labeled batches so you can compare the model’s results over time.
2. Print the result next to the input values so you can compare them.

## 📋 Sample data

| Batch | Correct | Checked |
| --- | --- | --- |
| Morning | 18 | 20 |
| Midday | 14 | 20 |
| Afternoon | 16 | 20 |

## Open the dashboard

1. Run `python lesson.py` to build the dashboard and its monitoring CSV.
2. Run `python -m streamlit run monitoring_dashboard.py` in the same folder. Open the local address printed in the terminal.
3. Change `sample.csv` and rerun `python lesson.py` from a second terminal in the same folder. The open dashboard reads the new accuracy.
