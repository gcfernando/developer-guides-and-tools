# Description

**Reference** · Shared code with lesson 355

Inspect the columns in the invented app listings and see what each row represents.

## ▶️ Run it

From the extracted lesson folder, run the two commands below. You only need to install its packages once.

```bash
python -m pip install -r requirements.txt
python lesson.py
```

## ✅ Expected result

Look for `PDF reference: Google Play Store Dataset (Kaggle)` in the output excerpt below. Match it to the supplied CSV before changing any values.

```text
PDF reference: Google Play Store Dataset (Kaggle)
Origin of this CSV: original synthetic practice rows
Rows: 7
```

[See the full example output](expected-output.txt).

If the result differs on your first run, restore the original CSVs, run from the extracted lesson folder, and read the first error message if Python stops.

## 🧪 Try one change

Add another original example in sample.csv. Rerun to check that its columns and row count make sense.

[Open the Python script](lesson.py) · [Open sample.csv](sample.csv)

## What the code does

1. Read the example records from sample.csv. The table uses the dataset fields shown below.
2. Print the result next to the input values so you can compare them.

## 📋 Sample data

| name | category | rating | price | installs |
| --- | --- | --- | --- | --- |
| Meter | tools | 4.1 | $0 | 1,000+ |
| Map | travel | 4.8 | $4 | 2,000+ |
| Puzzle | game | 3.9 | $0 | 650+ |
| Notes | tools | — | $1 | 550+ |
| Plan | travel | 4.1 | $35 | 80,000+ |
| Photo | — | 4.0 | $3 | 300+ |
| Quiz | game | 4.2 | $2 | 1,200+ |
