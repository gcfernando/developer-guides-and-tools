# Source

**Reference** · Shared code with lesson 311

Read the dataset name from the PDF and inspect the hand-drawn digit shapes used in this exercise.

## ▶️ Run it

From the extracted lesson folder, run the two commands below. You only need to install its packages once.

```bash
python -m pip install -r requirements.txt
python lesson.py
```

## ✅ Expected result

Find the reference dataset name and the sample file’s column types. Check that the rows describe the fields listed there.

```text
PDF reference: MNIST Dataset
Origin of this CSV: original synthetic practice rows
Rows: 12
```

[See the full example output](expected-output.txt).

If the result differs on your first run, restore the original CSVs, run from the extracted lesson folder, and read the first error message if Python stops.

## 🧪 Try one change

Add another original example in sample.csv. Rerun to check that its columns and row count make sense.

[Open the Python script](lesson.py) · [Open sample.csv](sample.csv)

## What the code does

1. Read the small drawings and their labels. Each slash separates two rows of pixels.
2. Print the result next to the input values so you can compare them.

## 📋 Sample data

| split | pixel_rows | label |
| --- | --- | --- |
| train | ###/#.#/#.#/#.#/### | 0 |
| train | .#./##./.#./.#./### | 1 |
| train | ###/..#/###/#../### | 2 |
| train | ###/..#/.##/..#/### | 3 |
| train | #.#/#.#/###/..#/..# | 4 |
| train | ###/#../###/..#/### | 5 |
| train | ###/#../###/#.#/### | 6 |
| train | ###/..#/..#/.#./.#. | 7 |

Showing the first 8 of 12 rows. The CSV has the full sample.
