# 70%-20%-10% (Train-Validation-Test)

**Practice** · Same split lab. Different check in each README; lesson 184 uses 80/20.

Use 70% to learn, 20% to choose tree depth and 10% to check it.

## ▶️ Run it

Extract this ZIP and open a terminal in the lesson folder.

```bash
python -m pip install -r requirements.txt
python lesson.py
```

## ✅ Expected result

Find 70 Training, 20 Validation and 10 Test rows. Confirm that all sets have zero overlap.

```text
Shared IDs or identical input rows across splits: 0
       Set  Rows  Urgent  Urgent (%)
  Training    70      14        20.0
Validation    20       4        20.0
      Test    10       2        20.0

Validation scores by tree depth
 Depth  Balanced accuracy
     1              0.500
     2              0.500
     3              0.562
Look for 70 training, 20 validation, and 10 test orders.
Chosen depth: 3
```

[Full run output](expected-output.txt) · [Python script](lesson.py) · [Sample CSV](sample.csv) · [Inputs to change](new_inputs.csv)

## 🧪 Try a change

Copy one training CSV row below itself. The script should stop before splitting. Delete the copy and rerun.
