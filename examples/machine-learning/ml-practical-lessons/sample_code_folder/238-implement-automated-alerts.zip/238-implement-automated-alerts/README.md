# Implement automated alerts

**Practice** · Shared code family (see lesson 234 for the same script)

Raise a local alert if accuracy falls or the input data changes too much.

## ▶️ Run it

From the extracted lesson folder, run the two commands below. You only need to install its packages once.

```bash
python -m pip install -r requirements.txt
python lesson.py
```

## ✅ Expected result

Look for `Recent accuracy: 0.53 median km change: 7.0` in the output excerpt below. Match it to the supplied CSV before changing any values.

```text
Recent accuracy: 0.53 median km change: 7.0
ALERT: investigate before promoting a candidate.
Later batch, live / candidate: 0.5 1.0
```

[See the full example output](expected-output.txt).

If the result differs on your first run, restore the original CSVs, run from the extracted lesson folder, and read the first error message if Python stops.

## 🧪 Try one change

Try changing km from 19 to 14 in sample.csv. Compare the new output.

[Open the Python script](lesson.py) · [Open sample.csv](sample.csv)

## What the code does

1. Read the labeled batches so you can compare the model’s results over time.
2. Teach the model from the training inputs and whether the delivery was late.
3. Plot the values so you can see how they compare.

## 📋 Sample data

| batch | km | late |
| --- | --- | --- |
| historical | 19 | True |
| historical | 13 | True |
| historical | 14 | True |
| historical | 18 | True |
| historical | 12 | True |
| historical | 16 | True |
| historical | 17 | True |
| historical | 5 | False |

Showing the first 8 of 160 rows. The CSV has the full sample.
