# Ensure correct units (kg vs. lbs)

**Practice** · Shared code family (see lesson 054 for the same script)

Convert pounds to kilograms so every weight means the same thing to the model.

## ▶️ Run it

From the extracted lesson folder, run the two commands below. You only need to install its packages once.

```bash
python -m pip install -r requirements.txt
python lesson.py
```

## ✅ Expected result

Look for `Original date Standard date Original weight  Weight (kg) Original zone Standard zone  South flag` in the output excerpt below. Match it to the supplied CSV before changing any values.

```text
Original date Standard date Original weight  Weight (kg) Original zone Standard zone  South flag
01/02/2025    2025-01-02           10 lb         4.54         NORTH         north           0
2025-01-03    2025-01-03            8 kg         8.00         south         south           1
```

[See the full example output](expected-output.txt).

If the result differs on your first run, restore the original CSVs, run from the extracted lesson folder, and read the first error message if Python stops.

## 🧪 Try one change

Try changing ship_date from 01/07/2025 to 2025-01-10 in new_inputs.csv. Compare the new output.

[Open the Python script](lesson.py) · [Open sample.csv](sample.csv) · [Open new_inputs.csv](new_inputs.csv)

## What the code does

1. Read the CSV and check its inputs, including ship_date, weight, unit.
2. Put the date, unit, and zone rules in one place so fresh rows go through the same cleanup.
3. Set aside the check rows before the model learns.
4. Teach the model from the training inputs and delivery time in minutes.
5. Apply the fitted model to the new CSV rows and print a result for each row.

## 📋 Sample data

| ship_date | weight | unit | zone | minutes |
| --- | --- | --- | --- | --- |
| 01/02/2025 | 10 | lb | NORTH | 19 |
| 2025-01-03 | 8 | kg | south | 27 |
| 01/04/2025 | 35 | lbs | NORTH | 38 |
| 2025-01-05 | 16 | kg | south | 40 |
| 2025-01-06 | 12 | kg | north | 35 |

## 📩 Supplied new inputs

| ship_date | weight | unit | zone |
| --- | --- | --- | --- |
| 01/07/2025 | 18 | lb | NORTH |
| 2025-01-09 | 7 | kg | south |
| 2025-01-10 | 30 | lbs | north |
