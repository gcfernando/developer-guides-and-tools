# Practice

**Practice** · Shared code family (see lesson 326 for the same script)

Use balance, duration and job from invented bank campaign records to estimate subscription.

## ▶️ Run it

From the extracted lesson folder, run the two commands below. You only need to install its packages once.

```bash
python -m pip install -r requirements.txt
python lesson.py
```

## ✅ Expected result

Look for `Balance / duration range: {'balance': {'min': 300, 'max': 12000}, 'duration': {'min': 35, 'max': 650}}` in the output excerpt below. Match it to the supplied CSV before changing any values.

```text
Balance / duration range: {'balance': {'min': 300, 'max': 12000}, 'duration': {'min': 35, 'max': 650}}
Training-only descriptive duration scale: [-0.86, -0.63, -0.19, 0.88, -0.97, 1.77]
Missing cells before filling or removing rows: {'age': 0, 'balance': 0, 'job': 1, 'marital': 1, 'education': 0, 'prior': 0, 'subscribed': 0}
```

[See the full example output](expected-output.txt).

If the result differs on your first run, restore the original CSVs, run from the extracted lesson folder, and read the first error message if Python stops.

## 🧪 Try one change

Change an input in new_inputs.csv. Compare the predictions with the held-out check above.

[Open the Python script](lesson.py) · [Open sample.csv](sample.csv) · [Open new_inputs.csv](new_inputs.csv)

## What the code does

1. Read the example records from sample.csv. The table uses the dataset fields shown below.
2. Print the result next to the input values so you can compare them.
3. Set aside the check rows before the model learns.
4. Find blanks in the rows you are about to use.
5. Find where the middle values sit, then compare the remaining rows with those limits.
6. Teach the model from the training inputs and whether the customer subscribed.
7. Apply the fitted model to the new CSV rows and print a result for each row.

## 📋 Sample data

| age | balance | duration | job | marital | education | prior | subscribed |
| --- | --- | --- | --- | --- | --- | --- | --- |
| 21 | 500 | 60 | student | single | school | none | no |
| 36 | 1200 | 110 | admin | married | degree | none | no |
| 44 | 4200 | 210 | manager | married | degree | success | yes |
| 51 | 6500 | 450 | owner | married | graduate | success | yes |
| 28 | 300 | 35 | — | single | school | none | no |
| 60 | 12000 | 650 | owner | — | graduate | success | yes |
| 30 | 700 | 40 | admin | single | degree | none | no |
| 49 | 5000 | 220 | manager | married | degree | success | yes |

## 📩 Supplied new inputs

| age | balance | duration | job | marital | education | prior |
| --- | --- | --- | --- | --- | --- | --- |
| 21 | 500 | 60 | student | single | school | none |
| 49 | 5000 | 220 | manager | married | degree | success |
| 44 | 4200 | 210 | manager | married | degree | success |
