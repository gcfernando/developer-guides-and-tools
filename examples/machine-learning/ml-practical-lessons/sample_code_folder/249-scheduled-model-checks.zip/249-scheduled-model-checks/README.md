# Scheduled model checks

**Practice**

Reuse the same model check for each batch and see which one raises an alert.

## ▶️ Run it

From the extracted lesson folder, run the two commands below. You only need to install its packages once.

```bash
python -m pip install -r requirements.txt
python lesson.py
```

## ✅ Expected result

Look for `Check  Current error (min)  Candidate error (min)           Decision` in the output excerpt below. Match it to the supplied CSV before changing any values.

```text
Check  Current error (min)  Candidate error (min)           Decision
Monday                  0.0                    0.0 Keep current model
Tuesday                  3.0                    0.0   Review candidate
```

[See the full example output](expected-output.txt).

If the result differs on your first run, restore the original CSVs, run from the extracted lesson folder, and read the first error message if Python stops.

## 🧪 Try one change

Try changing distance from 1 to 3 in sample.csv. Compare the new output.

[Open the Python script](lesson.py) · [Open sample.csv](sample.csv)

## What the code does

1. Read the labeled batches so you can compare the model’s results over time.
2. Print the result next to the input values so you can compare them.

## 📋 Sample data

| batch | distance | minutes |
| --- | --- | --- |
| History | 1 | 12 |
| History | 2 | 14 |
| History | 3 | 16 |
| History | 4 | 18 |
| History | 5 | 20 |
| History | 6 | 22 |
| Monday | 1 | 12 |
| Monday | 2 | 14 |

Showing the first 8 of 18 rows. The CSV has the full sample.
