# Practice

**Practice** · Shared code family (see lesson 334 for the same script)

Use age, cholesterol and other practice measurements from invented health-related rows to estimate fabricated label.

## ▶️ Run it

From the extracted lesson folder, run the two commands below. You only need to install its packages once.

```bash
python -m pip install -r requirements.txt
python lesson.py
```

## ✅ Expected result

Look for `Missing cells before filling or removing rows: {'age': 0, 'cholesterol': 0, 'blood_pressure': 0, …` in the output excerpt below. Match it to the supplied CSV before changing any values.

```text
Missing cells before filling or removing rows: {'age': 0, 'cholesterol': 0, 'blood_pressure': 0, 'exercise_score': 0, 'sex': 0, 'chest_pain': 0, 'example_label': 0}
Field  Rows to review
age               0
```

[See the full example output](expected-output.txt).

If the result differs on your first run, restore the original CSVs, run from the extracted lesson folder, and read the first error message if Python stops.

## 🧪 Try one change

Change an input in new_inputs.csv. Compare the predictions with the held-out check above.

[Open the Python script](lesson.py) · [Open sample.csv](sample.csv) · [Open new_inputs.csv](new_inputs.csv)

## What the code does

1. Read the example records from sample.csv. The table uses the dataset fields shown below.
2. Set aside the check rows before the model learns.
3. Find blanks in the rows you are about to use.
4. Find where the middle values sit, then compare the remaining rows with those limits.
5. Fit the model on the prepared training rows. Keep it for the checks below.
6. Apply the fitted model to the new CSV rows and print a result for each row.

## 📋 Sample data

| age | cholesterol | blood_pressure | exercise_score | sex | chest_pain | example_label |
| --- | --- | --- | --- | --- | --- | --- |
| 29 | 155 | 111 | 80 | F | none | 0 |
| 38 | 166 | 118 | 72 | M | none | 0 |
| 58 | 250 | 147 | 39 | F | reported | 1 |
| 62 | 273 | 157 | 33 | M | reported | 1 |
| 45 | 172 | 123 | 66 | F | none | 0 |
| 67 | 300 | 163 | 29 | M | reported | 1 |
| 41 | 169 | 122 | 70 | M | none | 0 |
| 65 | 277 | 155 | 34 | F | reported | 1 |

## 📩 Supplied new inputs

| age | cholesterol | blood_pressure | exercise_score | sex | chest_pain |
| --- | --- | --- | --- | --- | --- |
| 29 | 155 | 111 | 80 | F | none |
| 65 | 277 | 155 | 34 | F | reported |
| 58 | 250 | 147 | 39 | F | reported |
