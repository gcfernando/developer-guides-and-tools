# Test set

**Practice** · Same split lab. Different check in each README; lesson 184 uses 80/20.

Check the chosen model once using its untouched test rows.

## ▶️ Run it

Extract this ZIP and open a terminal in the lesson folder.

```bash
python -m pip install -r requirements.txt
python lesson.py
```

## ✅ Expected result

The test table contains two urgent orders. Read the counts for those orders and the one false alarm.

```text
Shared IDs or identical input rows across splits: 0
       Set  Rows  Urgent  Urgent (%)
  Training    70      14        20.0
Validation    20       4        20.0
      Test    10       2        20.0

Validation scores by tree depth
 Depth  Balanced accuracy
     1              0.500
     2              0.500
     3              0.562
Look for Test. Count missed urgent cases after the depth has been chosen.
Chosen depth: 3
```

[Full run output](expected-output.txt) · [Python script](lesson.py) · [Sample CSV](sample.csv) · [Inputs to change](new_inputs.csv)

## 🧪 Try a change

Copy one training CSV row below itself. The script should stop before splitting. Delete the copy and rerun.
