# 1.9. Model Deployment

**Practice** · Shared code family (see lesson 216 for the same script)

Serve a delivery model through a local test endpoint.

## ▶️ Run it

From the extracted lesson folder, run the two commands below. You only need to install its packages once.

```bash
python -m pip install -r requirements.txt
python lesson.py
```

## ✅ Expected result

Look for `200 {'minutes': 27.8}` in the output excerpt below. Match it to the supplied CSV before changing any values.

```text
200 {'minutes': 27.8}
Invalid distance: 422
{'distance_km': 5, 'weight_kg': 2} 200 {'minutes': 27.8}
```

[See the full example output](expected-output.txt).

If the result differs on your first run, restore the original CSVs, run from the extracted lesson folder, and read the first error message if Python stops.

## 🧪 Try one change

Try changing distance_km from 5 to -2 in new_inputs.csv. Compare the new output.

[Open the Python script](lesson.py) · [Open sample.csv](sample.csv) · [Open new_inputs.csv](new_inputs.csv)

## What the code does

1. Read the delivery table. Distance is in km, and weight is in kg.
2. Send a practice request and read the response code and body.
3. Send each new CSV row to the app and read the response.

## 📋 Sample data

| distance_km | weight_kg | delivery_minutes |
| --- | --- | --- |
| 2 | 1 | 19 |
| 4 | 3 | 30 |
| 6 | 2 | 29 |
| 8 | 4 | 40 |
| 10 | 1 | 33 |
| 12 | 3 | 44 |

## 📩 Supplied new inputs

| distance_km | weight_kg |
| --- | --- |
| 5 | 2 |
| 20 | 4 |
| -2 | 3 |

## 📊 Read the visual

![Send the inputs. Distance is 5 km. Weight is 2 kg. → Check the request. Reject a negative distance or an invalid weight. → Return an estimate. Give valid input to the model and return the predicted minutes.](api-request-steps.png)

**👀 Read the visual.** Send the app the fields it needs to predict.

**👉 What to do.** Try both a normal row and a negative distance. Check the response code and the message in each case.
