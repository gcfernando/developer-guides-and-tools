# Anomaly Detection (diagram)

**Reference** · Shared code with lesson 394, lesson 395

Follow the anomaly-detection branch and flag unusual deliveries.

## ▶️ Run it

From the extracted lesson folder, run the two commands below. You only need to install its packages once.

```bash
python -m pip install -r requirements.txt
python lesson.py
```

## ✅ Expected result

Look for `Example training shipments: [[10.0, 4.15], [9.73, 3.55], [9.55, 3.5]]` in the output excerpt below. Match it to the supplied CSV before changing any values.

```text
Example training shipments: [[10.0, 4.15], [9.73, 3.55], [9.55, 3.5]]
Typical / unusually large: [1, -1, -1]
```

[See the full example output](expected-output.txt).

If the result differs on your first run, restore the original CSVs, run from the extracted lesson folder, and read the first error message if Python stops.

## 🧪 Try one change

Edit the rows in new_inputs.csv. Compare a typical case with an unusually heavy parcel. A flag means check the original record.

[Open the Python script](lesson.py) · [Open sample.csv](sample.csv) · [Open new_inputs.csv](new_inputs.csv)

## What the code does

1. Read the CSV and check its inputs, including minutes, kg.
2. Read the new CSV rows, then apply the rules from the sample.
3. Fit the model on the prepared training rows. Keep it for the checks below.

## 📋 Sample data

| minutes | kg |
| --- | --- |
| 10.001230153357483 | 4.149372768754235 |
| 9.725862144637782 | 3.554704080621363 |
| 9.545329214828277 | 3.504176722501769 |
| 10.060143602597439 | 4.670107622777267 |
| 9.50779348144867 | 3.68976255009003 |
| 10.489842050185198 | 4.178443504080031 |
| 10.1054142489979 | 3.5347659776458977 |
| 9.970748177536727 | 4.347651597229144 |

Showing the first 8 of 45 rows. The CSV has the full sample.

## 📩 Supplied new inputs

| minutes | kg |
| --- | --- |
| 10 | 4 |
| 50 | 34 |
| 12 | 6 |
