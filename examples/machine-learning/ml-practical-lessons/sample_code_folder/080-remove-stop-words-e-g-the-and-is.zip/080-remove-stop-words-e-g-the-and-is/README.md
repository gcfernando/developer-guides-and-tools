# Remove stop words (e.g., "the", "and", "is")

**Practice**

Drop selected common words such as the and is, then test a delivery or billing message.

## ▶️ Run it

From the extracted lesson folder, run the two commands below. You only need to install its packages once.

```bash
python -m pip install -r requirements.txt
python lesson.py
```

## ✅ Expected result

Look for `Before: ['the', 'parcel', 'is', 'not', 'here', 'and', 'am', 'waiting']` in the output excerpt below. Match it to the supplied CSV before changing any values.

```text
Before: ['the', 'parcel', 'is', 'not', 'here', 'and', 'am', 'waiting']
After: ['parcel', 'not', 'here', 'am', 'waiting']
Actual: ['delivery', 'billing']
```

[See the full example output](expected-output.txt).

If the result differs on your first run, restore the original CSVs, run from the extracted lesson folder, and read the first error message if Python stops.

## 🧪 Try one change

Replace one message in new_inputs.csv. Include one delivery message and one billing message.

[Open the Python script](lesson.py) · [Open sample.csv](sample.csv) · [Open new_inputs.csv](new_inputs.csv)

## What the code does

1. Read the support messages and their known categories.
2. Print the result next to the input values so you can compare them.
3. Set aside the check rows before the model learns.
4. Teach the model from the training inputs and the known message category.
5. Apply the fitted model to the new CSV rows and print a result for each row.

## 📋 Sample data

| message | category |
| --- | --- |
| MY Parcel Is Late!!! | delivery |
| Where is my PACKAGE? | delivery |
| The parcel never arrived. | delivery |
| Please REFUND my payment! | billing |
| My invoice is WRONG? | billing |
| I was charged twice. | billing |
| Where is my parcel? | delivery |
| Please refund this charge! | billing |

## 📩 Supplied new inputs

| message |
| --- |
| The parcel is late! |
| I need a refund for two charges. |
| WHERE ARE MY PACKAGES? |
