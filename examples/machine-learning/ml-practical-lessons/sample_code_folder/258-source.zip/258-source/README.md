# Source

**Reference** · Shared code with lesson 252

Read the dataset name from the PDF and inspect the invented employee records used in this exercise.

## ▶️ Run it

From the extracted lesson folder, run the two commands below. You only need to install its packages once.

```bash
python -m pip install -r requirements.txt
python lesson.py
```

## ✅ Expected result

Find the reference dataset name and the sample file’s column types. Check that the rows describe the fields listed there.

```text
PDF reference: Generated example
Origin of this CSV: original synthetic practice rows
Rows: 9
```

[See the full example output](expected-output.txt).

If the result differs on your first run, restore the original CSVs, run from the extracted lesson folder, and read the first error message if Python stops.

## 🧪 Try one change

Add another original example in sample.csv. Rerun to check that its columns and row count make sense.

[Open the Python script](lesson.py) · [Open sample.csv](sample.csv)

## What the code does

1. Read the example records from sample.csv. The table uses the dataset fields shown below.
2. Print the result next to the input values so you can compare them.

## 📋 Sample data

| experience | department | salary |
| --- | --- | --- |
| 1 | Support | 32000 |
| 2 | Support | 34000 |
| 4 | Engineering | 42000 |
| 5 | Sales | 43000 |
| 6 | Sales | — |
| 8 | Engineering | 54000 |
| 12 | Engineering | 68000 |
| 9 | Sales | 55000 |

Showing the first 8 of 9 rows. The CSV has the full sample.
