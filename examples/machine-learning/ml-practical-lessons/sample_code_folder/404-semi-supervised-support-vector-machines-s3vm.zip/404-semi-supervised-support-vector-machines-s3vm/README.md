# Semi-Supervised Support Vector Machines (S3VM)

**Practice** · Shared code with lesson 402, lesson 403

See how a small support-vector example can choose labels for some unknown rows.

## ▶️ Run it

From the extracted lesson folder, run the two commands below. You only need to install its packages once.

```bash
python -m pip install -r requirements.txt
python lesson.py
```

## ✅ Expected result

Look for four chosen pseudo-labels followed by three predictions. The new rows have no confirmed answers.

```text
Chosen training pseudo-labels: (-1, -1, 1, 1)
Predictions for new rows: [-1, 1, 1]
```

[Full searched result](expected-output.txt).

## 🧪 Try one change

Change x or y in new_inputs.csv. Keep two known classes and four unlabeled practice rows if editing sample.csv.

[Open the Python script](lesson.py) · [Open sample.csv](sample.csv) · [Open new_inputs.csv](new_inputs.csv)

## What the code does

1. Read the CSV and check its inputs, including x, y, label.
2. Give each method the same practice data so you can compare the results.
3. Apply the fitted model to the new CSV rows and print a result for each row.

## 📋 Sample data

| x | y | label |
| --- | --- | --- |
| -2 | -2 | -1 |
| -1.6 | -1.9 | -1 |
| 1.8 | 1.9 | 1 |
| 2 | 2 | 1 |
| -1.4 | -1.3 | — |
| -0.8 | -1.2 | — |
| 1 | 0.9 | — |
| 1.5 | 1.3 | — |

## 📩 Supplied new inputs

| x | y |
| --- | --- |
| -1.1 | -1 |
| 1.1 | 1 |
| 0.2 | 0.7 |

This intentionally small illustration searches a few possible labels. The new CSV has inputs without confirmed answers, so its predictions do not measure accuracy.
