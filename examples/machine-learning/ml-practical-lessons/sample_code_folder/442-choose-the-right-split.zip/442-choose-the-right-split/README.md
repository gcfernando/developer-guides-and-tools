# Choose the right data split

**Core**

Compare random, customer-grouped, and chronological splits on the same delivery data.

## ▶️ Run it

Extract this ZIP and open a terminal in the lesson folder.

```bash
python -m pip install -r requirements.txt
python lesson.py
```

## ✅ Expected result

All plans share zero shipment IDs. The customer plan shares zero customers. Only the time plan puts all test dates after training.

```text
Plan  Test orders  Shared shipments  Shared customers  Test is entirely later  Test MAE (min)
  random          105                 0                63                   False            2.92
customer          105                 0                 0                   False            5.91
    time          105                 0                84                    True            2.50

Random: independent orders in the same setting. Customer: customers the model has never seen.
Time: later orders. Their customers may already be known. Pick the plan before comparing scores.
```

[Full run output](expected-output.txt) · [Python script](lesson.py) · [Sample CSV](sample.csv) · [Inputs to change](new_inputs.csv)

## 🧪 Try a change

Leave only customer in new_inputs.csv. Check that this plan keeps all rows for an unseen customer together.

Choose the random plan for independent observations, the customer plan for unseen customers, or the time plan for forecasting later batches. Each result answers a different question. [Cross-validation guide](https://scikit-learn.org/stable/modules/cross_validation.html)
