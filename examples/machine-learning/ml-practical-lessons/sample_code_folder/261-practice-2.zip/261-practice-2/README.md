# Practice

**Practice** · Shared code family (see lesson 259 for the same script)

Use age, fare and family details from invented ferry bookings to estimate priority boarding.

## ▶️ Run it

From the extracted lesson folder, run the two commands below. You only need to install its packages once.

```bash
python -m pip install -r requirements.txt
python lesson.py
```

## ✅ Expected result

Look for `Missing cells before filling or removing rows: {'age': 1, 'fare': 0, 'family_size': 0, 'cabin_recorded': 0, …` in the output excerpt below. Match it to the supplied CSV before changing any values.

```text
Missing cells before filling or removing rows: {'age': 1, 'fare': 0, 'family_size': 0, 'cabin_recorded': 0, 'pass_type': 0, 'terminal': 1, 'priority': 0}
Field  Rows to review
age               0
```

[See the full example output](expected-output.txt).

If the result differs on your first run, restore the original CSVs, run from the extracted lesson folder, and read the first error message if Python stops.

## 🧪 Try one change

Change an input in new_inputs.csv. Compare the predictions with the held-out check above.

[Open the Python script](lesson.py) · [Open sample.csv](sample.csv) · [Open new_inputs.csv](new_inputs.csv)

## What the code does

1. Read the example records from sample.csv. The table uses the dataset fields shown below.
2. Set aside the check rows before the model learns.
3. Find blanks in the rows you are about to use.
4. Find where the middle values sit, then compare the remaining rows with those limits.
5. Teach the model from the training inputs and the boarding priority.
6. Apply the fitted model to the new CSV rows and print a result for each row.

## 📋 Sample data

| age | fare | pass_type | terminal | cabin | siblings | parents | priority |
| --- | --- | --- | --- | --- | --- | --- | --- |
| 18 | 12 | standard | north | — | 0 | 1 | 0 |
| — | 18 | standard | — | A | 1 | 0 | 0 |
| 52 | 46 | premium | south | B | 0 | 0 | 1 |
| 34 | 24 | standard | north | — | 1 | 1 | 0 |
| 62 | 64 | premium | south | C | 0 | 0 | 1 |
| 65 | 22 | standard | south | B | 0 | 0 | 1 |
| 29 | 120 | premium | north | A | 2 | 0 | 1 |
| 19 | 19 | standard | north | — | 0 | 1 | 0 |

Showing the first 8 of 9 rows. The CSV has the full sample.

## 📩 Supplied new inputs

| age | fare | pass_type | terminal | cabin | siblings | parents |
| --- | --- | --- | --- | --- | --- | --- |
| 18.0 | 12 | standard | north | — | 0 | 1 |
| 57.0 | 42 | premium | south | B | 1 | 1 |
| 52.0 | 46 | premium | south | B | 0 | 0 |
