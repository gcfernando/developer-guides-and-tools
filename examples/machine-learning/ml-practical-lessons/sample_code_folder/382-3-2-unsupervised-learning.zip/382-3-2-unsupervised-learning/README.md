# 3.2. Unsupervised Learning

**Practice** · Shared code family (see lesson 383 for the same script)

Group similar shoppers using their measurements without given group labels.

## ▶️ Run it

From the extracted lesson folder, run the two commands below. You only need to install its packages once.

```bash
python -m pip install -r requirements.txt
python lesson.py
```

## ✅ Expected result

Look for `Labels: [0, 0, 0, 2, 2, 2, 1, 1, 1]` in the output excerpt below. Match it to the supplied CSV before changing any values.

```text
Labels: [0, 0, 0, 2, 2, 2, 1, 1, 1]
age  income  spending
group
```

[See the full example output](expected-output.txt).

If the result differs on your first run, restore the original CSVs, run from the extracted lesson folder, and read the first error message if Python stops.

## 🧪 Try one change

Change a measurement in new_inputs.csv. The fitted scaler and algorithm process each row.

[Open the Python script](lesson.py) · [Open sample.csv](sample.csv) · [Open new_inputs.csv](new_inputs.csv)

## What the code does

1. Read the CSV and check its inputs, including age, income, spending.
2. Learn the conversion on the training inputs before applying it to a new row.
3. Fit the model on the prepared training rows. Keep it for the checks below.
4. Apply the fitted model to the new CSV rows and print a result for each row.

## 📋 Sample data

| age | income | spending |
| --- | --- | --- |
| 21 | 25 | 71 |
| 23 | 28 | 73 |
| 26 | 31 | 68 |
| 42 | 55 | 41 |
| 43 | 59 | 45 |
| 46 | 62 | 43 |
| 59 | 89 | 77 |
| 62 | 93 | 80 |

Showing the first 8 of 9 rows. The CSV has the full sample.

## 📩 Supplied new inputs

| age | income | spending |
| --- | --- | --- |
| 21 | 25 | 71 |
| 64 | 95 | 82 |
| 26 | 31 | 68 |

## 📊 Read the visual

![Read the inputs. Age, income and spending score. → Find groups. Put shoppers with similar measurements near one another. → Inspect the result. Read the group averages before describing each group.](unsupervised-model-steps.png)

**👀 Read the visual.** Use measurements to compare shoppers.

**👉 What to do.** Group numbers are names assigned by the algorithm. Compare the profiles to understand the groups.
