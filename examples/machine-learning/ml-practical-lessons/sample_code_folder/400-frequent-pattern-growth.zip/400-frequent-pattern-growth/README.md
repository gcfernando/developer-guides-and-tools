# Frequent Pattern Growth

**Practice**

Find common item pairs by organizing recurring items in a tree.

## ▶️ Run it

From the extracted lesson folder, run the two commands below. You only need to install its packages once.

```bash
python -m pip install -r requirements.txt
python lesson.py
```

## ✅ Expected result

Look for `fpgrowth [(('bread', 'milk'), 0.6)]` in the output excerpt below. Match it to the supplied CSV before changing any values.

```text
fpgrowth [(('bread', 'milk'), 0.6)]
Milk to bread confidence: 0.75
```

[See the full example output](expected-output.txt).

If the result differs on your first run, restore the original CSVs, run from the extracted lesson folder, and read the first error message if Python stops.

## 🧪 Try one change

Add or change a basket in sample.csv. Use | between items. The printed support is the share of baskets that contain the item set.

[Open the Python script](lesson.py) · [Open sample.csv](sample.csv)

## What the code does

1. Read the baskets. A vertical bar separates the items in each basket.
2. Compare the printed output with the original values.

## 📋 Sample data

| items |
| --- |
| milk\|bread |
| milk\|bread\|eggs |
| bread |
| milk\|bread |
| milk\|apples |
