# Feature Selection

**Practice** · Shared code with lesson 171

Choose useful input columns, then see how the choice affects predictions.

## ▶️ Run it

From the extracted lesson folder, run the two commands below. You only need to install its packages once.

```bash
python -m pip install -r requirements.txt
python lesson.py
```

## ✅ Expected result

Look for `ANOVA selected: ['minutes']` in the output excerpt below. Match it to the supplied CSV before changing any values.

```text
ANOVA selected: ['minutes']
Held-out labels: [0, 1]
Chi-square selected: ['minutes']
```

[See the full example output](expected-output.txt).

If the result differs on your first run, restore the original CSVs, run from the extracted lesson folder, and read the first error message if Python stops.

## 🧪 Try one change

Try changing id from 0 to 2 in sample.csv. Compare the new output.

[Open the Python script](lesson.py) · [Open sample.csv](sample.csv)

## What the code does

1. Read the CSV and check its inputs, including id, minutes, duplicate_minutes.
2. Give each method the same practice data so you can compare the results.

## 📋 Sample data

| id | minutes | duplicate_minutes | keyword | review |
| --- | --- | --- | --- | --- |
| 0 | 2 | 2 | 0 | 0 |
| 1 | 18 | 18 | 1 | 1 |
| 2 | 3 | 3 | 0 | 0 |
| 3 | 20 | 20 | 1 | 1 |
| 4 | 4 | 4 | 1 | 0 |
| 5 | 23 | 23 | 0 | 1 |
| 6 | 5 | 5 | 0 | 0 |
| 7 | 24 | 24 | 1 | 1 |
