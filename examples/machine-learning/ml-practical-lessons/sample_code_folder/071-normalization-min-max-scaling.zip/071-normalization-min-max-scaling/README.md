# Normalization (Min-Max Scaling)

**Core**

Scale known distances, then see what happens when training covers 1–50 km and someone enters 90 km.

## ▶️ Run it

From the extracted lesson folder, run the two commands below. You only need to install its packages once.

```bash
python -m pip install -r requirements.txt
python lesson.py
```

## ✅ Expected result

On the short example, find **27.5 minutes** for the new 5 km, 2 kg parcel. In the saved model exercise, find **1.8163** for 90 km.

```text
New deliveries and their predicted minutes
distance_km  weight_kg  scaled_distance  scaled_weight  predicted_minutes
5          2             0.50           0.33               27.5
```

[See the full example output](expected-output.txt).

If the result differs on your first run, restore the original CSVs, run from the extracted lesson folder, and read the first error message if Python stops.

## 🧪 Try one change

Change 90 to 45 in range_requests.csv. Run only test_range_model.py. The app should offer an estimate.

[Open the Python script](lesson.py) · [Open sample.csv](sample.csv) · [Open new_inputs.csv](new_inputs.csv)

## What the code does

1. Read the delivery log. Each row has a distance, a weight and an actual time.
2. Take the first four trips for training. Save the last two to check the model.
3. Find the smallest and largest training values for each input, then scale the training rows.
4. Teach the model using the scaled distance and weight. Leave the answers in minutes.
5. Check the model against the measured delivery times.
6. Reuse the fitted scaler for the new trips. Print the raw inputs, scaled inputs and predicted minutes together.

## 📋 Sample data

| distance_km | weight_kg | delivery_minutes |
| --- | --- | --- |
| 2 | 1 | 19 |
| 4 | 3 | 30 |
| 6 | 2 | 29 |
| 8 | 4 | 40 |
| 10 | 1 | 33 |
| 12 | 3 | 44 |

## 📩 Supplied new inputs

| distance_km | weight_kg |
| --- | --- |
| 5 | 2 |
| 10 | 3 |
| 12 | 4 |

## Expected result for the supplied fresh inputs

| Distance (km) | Weight (kg) | Scaled distance | Scaled weight | Predicted minutes |
| ---: | ---: | ---: | ---: | ---: |
| 5 | 2 | 0.50 | 0.33 | 27.5 |
| 10 | 3 | 1.33 | 0.67 | 39.0 |
| 12 | 4 | 1.67 | 1.00 | 46.0 |

The first four deliveries teach the scaler that the smallest training distance is 2 km and the largest is 8 km. A fresh distance above 8 km becomes greater than 1. The model receives the scaled distance and weight before making its prediction.

## 🚚 What if the app receives 90 km?

The files below use a second training example, with distances from **1 to 50 km**.

1. Run `python train_range_model.py` once. It reads [range_training.csv](range_training.csv), checks the result with [range_check.csv](range_check.csv), and saves the fitted scaler and model together.
2. Open [range_requests.csv](range_requests.csv). Leave the 90 km row in place for the first run.
3. Run `python test_range_model.py`. It loads the saved model and shows the scaled distance, demo prediction and app response for each row.
4. Replace 90 with 45 or 105 and run only the test script again. Try entering `unknown` to see the input validation message.

| Entered distance (km) | Scaled distance | Demo prediction (min) | In-range-only app |
| ---: | ---: | ---: | --- |
| 1 | 0.0000 | 12.0 | Shows 12.0 min |
| 25 | 0.4898 | 60.0 | Shows 60.0 min |
| 50 | 1.0000 | 110.0 | Shows 110.0 min |
| 90 | 1.8163 | 190.0 | Shows an outside-range message |

For 90 km the saved scaler still uses 1 and 50, so it calculates `(90 − 1) ÷ (50 − 1) ≈ 1.8163`. The demo prediction extends the fitted line into a range the model has never seen. If you plan to support long routes, collect measured long trips for training and keep some separate to check how the model does.

## 📊 Read the visual

![The solid line goes from 1 km at 0 to 50 km at 1. The dashed extension marks 90 km at 1.8163.](min-max-outside-training-range.png)

**👀 Read the visual.** Follow 90 km up to the orange diamond. It is above 1 because 90 is above the fitted maximum of 50.

**👉 What to do.** Check whether the app should return an estimate for a distance outside its training range.
